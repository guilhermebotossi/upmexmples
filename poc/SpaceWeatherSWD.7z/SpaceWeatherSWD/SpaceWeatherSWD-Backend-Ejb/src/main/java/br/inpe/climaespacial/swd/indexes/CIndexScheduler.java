package br.inpe.climaespacial.swd.indexes;

import br.inpe.climaespacial.swd.indexes.c.services.CIndexService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;
import javax.ejb.AccessTimeout;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

@Startup
@Singleton
public class CIndexScheduler {

    @Inject
    private CIndexService cIndexService;

    @AccessTimeout(value = 5, unit = TimeUnit.MINUTES)
    //@Schedule(hour = "*", persistent = false)
    @Schedule(hour = "*", minute="*", persistent = false)
    public void cIndexCalculate() {
        Logger log = Logger.getLogger(CIndexScheduler.class.getName());
        log.info("Inicio do calculo do indice C");
        cIndexService.calculate();
        log.info("Fim do calculo do indice C");
    }
}
