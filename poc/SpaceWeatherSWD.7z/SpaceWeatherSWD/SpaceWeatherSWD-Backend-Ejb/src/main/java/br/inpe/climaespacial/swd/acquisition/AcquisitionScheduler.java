package br.inpe.climaespacial.swd.acquisition;

import java.util.concurrent.TimeUnit;

import javax.ejb.AccessTimeout;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

import br.inpe.climaespacial.swd.acquisition.services.DataAquisition;

@Singleton
@Startup
public class AcquisitionScheduler {

    @Inject
    private DataAquisition dataAquisition;

    @AccessTimeout(unit = TimeUnit.MINUTES, value = 2)
    @Schedule(hour = "*", minute = "*/1", second = "0", persistent = false)
    public void getData() {
        dataAquisition.acquire();
    }
}
