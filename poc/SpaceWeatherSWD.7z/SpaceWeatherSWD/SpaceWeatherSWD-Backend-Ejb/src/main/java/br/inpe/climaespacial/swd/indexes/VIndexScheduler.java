package br.inpe.climaespacial.swd.indexes;

import br.inpe.climaespacial.swd.indexes.v.services.VIndexService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;
import javax.ejb.AccessTimeout;
import javax.ejb.Singleton;
import javax.ejb.Startup;

@Startup
@Singleton
public class VIndexScheduler {

    //@Inject
    private VIndexService vIndexService;

    @AccessTimeout(value = 5, unit = TimeUnit.MINUTES)
    //@Schedule(hour = "*", persistent = false)
    public void vIndexCalculate() {
        Logger log = Logger.getLogger(VIndexScheduler.class.getName());
        log.info("Inicio do calculo do indice V");
        vIndexService.calculate();
        log.info("Fim do calculo do indice V");
    }
}
