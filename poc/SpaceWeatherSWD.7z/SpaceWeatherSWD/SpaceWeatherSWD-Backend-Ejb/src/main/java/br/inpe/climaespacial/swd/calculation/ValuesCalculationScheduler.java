package br.inpe.climaespacial.swd.calculation;

import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

import br.inpe.climaespacial.swd.calculation.services.ValuesCalculation;
import java.util.concurrent.TimeUnit;
import javax.ejb.AccessTimeout;

@Singleton
@Startup
public class ValuesCalculationScheduler {

    @Inject
    private ValuesCalculation valuesCalculation;

    @AccessTimeout(unit = TimeUnit.MINUTES, value = 2)
    //@Schedule(hour = "*", minute = "*/1", persistent = false)
    public void calculate() {
        valuesCalculation.calculate();
    }
}
