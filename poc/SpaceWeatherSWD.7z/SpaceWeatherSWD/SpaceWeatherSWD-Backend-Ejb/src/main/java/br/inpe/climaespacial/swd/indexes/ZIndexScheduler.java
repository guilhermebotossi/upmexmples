package br.inpe.climaespacial.swd.indexes;

import br.inpe.climaespacial.swd.indexes.z.services.ZIndexService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;
import javax.ejb.AccessTimeout;
import javax.ejb.Singleton;
import javax.ejb.Startup;

@Startup
@Singleton
public class ZIndexScheduler {

    //@Inject
    private ZIndexService zIndexService;

    @AccessTimeout(value = 5, unit = TimeUnit.MINUTES)
    //@Schedule(hour = "*", persistent = false)
    public void zIndexCalculate() {
        Logger log = Logger.getLogger(ZIndexScheduler.class.getName());
        log.info("Inicio do calculo do indice Z");
        zIndexService.calculate();
        log.info("Fim do calculo do indice Z");
    }
}
