package br.inpe.climaespacial.swd.average;

import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import javax.ejb.AccessTimeout;
import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

@Singleton
@Startup
public class HourlyAverageScheduler {
	
	@Inject
	private Average average;
        
        /* TODO: verificar a time adequado do schedule */
	
	@AccessTimeout(value = 5 , unit = TimeUnit.MINUTES)
	//@Schedule(hour = "*", minute = "*/1", persistent = false)
	public void hourlyAverageCalculate() {
		Logger log = Logger.getLogger(HourlyAverageScheduler.class.getName());
		log.info("Inicio do calculo da media Horaria");
		average.calculate();
		log.info("Fim do calculo da media Horaria");
	}
	
	

}
