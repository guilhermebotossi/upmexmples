package br.inpe.climaespacial.swd.values.bt.repositories;


import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

import javax.inject.Inject;
import javax.persistence.EntityManager;

import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import org.jglue.cdiunit.InRequestScope;
import org.junit.Test;
import org.junit.runner.RunWith;

import br.inpe.climaespacial.swd.acquisition.entities.MagEntity;
import br.inpe.climaespacial.swd.acquisition.home.DefaultIntervalValidator;
import br.inpe.climaespacial.swd.acquisition.home.FactoryProducer;
import br.inpe.climaespacial.swd.commons.factories.DefaultListFactory;
import br.inpe.climaespacial.swd.test.BaseIntegrationTest;
import br.inpe.climaespacial.swd.test.EntityManagerFactoryProducer;
import br.inpe.climaespacial.swd.test.EntityManagerProducer;
import br.inpe.climaespacial.swd.values.bt.dtos.BT;
import br.inpe.climaespacial.swd.values.bt.factories.DefaultBTFactory;
import br.inpe.climaespacial.swd.values.bt.mappers.DefaultBTMapper;

@RunWith(CdiRunner.class)
@AdditionalClasses({
    EntityManagerFactoryProducer.class,
    EntityManagerProducer.class,
    FactoryProducer.class,
    DefaultListFactory.class,
    DefaultIntervalValidator.class,
    DefaultBTRepository.class,
    DefaultBTMapper.class,
    DefaultBTFactory.class
})
public class BTRepositoryIntegrationTest extends BaseIntegrationTest  {
	
	private final ZonedDateTime initialDateTime = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
	private final ZonedDateTime finalDateTime = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");
	
	@Inject
	private EntityManager entityManager;
	
	@Inject
	private BTRepository btRepository;
	
	@Test
	@InRequestScope
	public void list_called_succeeds() {
		MagEntity me = new MagEntity();
		me.setId(UUID.randomUUID());
		ZonedDateTime now = ZonedDateTime.now();
		me.setCreationDate(now);
		me.setModificationDate(now);
		ZonedDateTime zdt = ZonedDateTime.parse("2017-01-01T12:30:00z[UTC]");
		me.setTimeTag(zdt);
		Double value = 2.0;
		me.setBt(value);
		entityManager.persist(me);
		
		List<BT> bl = btRepository.list(initialDateTime, finalDateTime);
		
		assertNotNull(bl);
		assertThat(bl, is(not(empty())));
		BT bt = bl.get(0);
		assertEquals(zdt, bt.getTimeTag());
		assertEquals(value, bt.getBT());
		
	}
}
