package br.inpe.climaespacial.swd.indexes.b.repositories;

import br.inpe.climaespacial.swd.commons.factories.DefaultListFactory;
import br.inpe.climaespacial.swd.indexes.b.dtos.BIndex;
import br.inpe.climaespacial.swd.indexes.b.entities.BIndexEntity;
import br.inpe.climaespacial.swd.indexes.b.factories.DefaultBIndexFactory;
import br.inpe.climaespacial.swd.indexes.b.mappers.DefaultBIndexMapper;
import br.inpe.climaespacial.swd.test.BaseIntegrationTest;
import br.inpe.climaespacial.swd.test.EntityManagerFactoryProducer;
import br.inpe.climaespacial.swd.test.EntityManagerProducer;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import org.jglue.cdiunit.InRequestScope;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(CdiRunner.class)
@AdditionalClasses({
    DefaultBIndexReaderRepository.class,
    EntityManagerFactoryProducer.class,
    EntityManagerProducer.class,
    DefaultBIndexMapper.class,
    DefaultBIndexFactory.class,
    DefaultListFactory.class
})
public class BIndexReaderRepositoryIntegrationTest extends BaseIntegrationTest {

    private static final double VALUE = 1.0;

    @Inject
    private EntityManager entityManager;

    @Inject
    private BIndexReaderRepository bIndexReaderRepository;

    @InRequestScope
    @Test
    public void getLastCalculatedHour_called_returnsNull() {
        ZonedDateTime nhtbc = bIndexReaderRepository.getNextHourToBeCalculated();

        assertNull(nhtbc);
    }

    @InRequestScope
    @Test
    public void getLastCalculatedHour_called_returnsLastTimeTag() {
        BIndexEntity bi1 = new BIndexEntity();
        bi1.setId(UUID.randomUUID());
        ZonedDateTime zdt1 = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        bi1.setCreationDate(zdt1);
        bi1.setModificationDate(zdt1);
        bi1.setTimeTag(zdt1);
        bi1.setPostValue(VALUE);
        entityManager.persist(bi1);

        BIndexEntity bi2 = new BIndexEntity();
        bi2.setId(UUID.randomUUID());
        ZonedDateTime zdt2 = ZonedDateTime.parse("2016-01-01T12:00:00z[UTC]");
        bi2.setCreationDate(zdt2);
        bi2.setModificationDate(zdt2);
        bi2.setTimeTag(zdt2);
        bi2.setPostValue(VALUE);
        entityManager.persist(bi2);

        ZonedDateTime nhtbc = bIndexReaderRepository.getNextHourToBeCalculated();

        assertNotNull(nhtbc);
        assertEquals(zdt1.plusHours(1), nhtbc);
    }

    @InRequestScope
    @Test
    public void listByPeriod_called_returnsListEmpty() {

        ZonedDateTime ffn = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nfn = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");

        List<BIndex> bil = bIndexReaderRepository.listByPeriod(ffn, nfn);

        assertNotNull(bil);
        assertEquals(0, bil.size());
    }

    @InRequestScope
    @Test
    public void listByPeriod_calledWithDurationSmallerThan2Days_returnsList() {

        BIndexEntity bi1 = new BIndexEntity();
        bi1.setId(UUID.randomUUID());
        ZonedDateTime zdt1 = ZonedDateTime.parse("2017-01-02T12:00:00z[UTC]");
        bi1.setCreationDate(zdt1);
        bi1.setModificationDate(zdt1);
        bi1.setTimeTag(zdt1);
        bi1.setPreValue(VALUE);
        bi1.setPostValue(VALUE);
        entityManager.persist(bi1);

        BIndexEntity bi2 = new BIndexEntity();
        bi2.setId(UUID.randomUUID());
        ZonedDateTime zdt2 = ZonedDateTime.parse("2017-01-02T13:00:00z[UTC]");
        bi2.setCreationDate(zdt2);
        bi2.setModificationDate(zdt2);
        bi2.setTimeTag(zdt2);
        bi2.setPreValue(VALUE);
        bi2.setPostValue(VALUE);
        entityManager.persist(bi2);

        BIndexEntity bi3 = new BIndexEntity();
        bi3.setId(UUID.randomUUID());
        ZonedDateTime zdt3 = ZonedDateTime.parse("2017-01-04T13:00:00z[UTC]");
        bi3.setCreationDate(zdt3);
        bi3.setModificationDate(zdt3);
        bi3.setTimeTag(zdt3);
        bi3.setPreValue(VALUE);
        bi3.setPostValue(VALUE);
        entityManager.persist(bi3);

        ZonedDateTime ffn = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nfn = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");

        List<BIndex> bil = bIndexReaderRepository.listByPeriod(ffn, nfn);

        assertNotNull(bil);
        assertEquals(2, bil.size());
        assertEquals(bil.get(0).getTimeTag(), zdt1);
        assertEquals(bil.get(1).getTimeTag(), zdt2);
    }

    @InRequestScope
    @Test
    public void listByPeriod_calledWithDurationBiggerThan2Days_returnsList() {

        BIndexEntity bi1 = new BIndexEntity();
        bi1.setId(UUID.randomUUID());
        ZonedDateTime zdt1 = ZonedDateTime.parse("2017-01-02T12:00:00z[UTC]");
        bi1.setCreationDate(zdt1);
        bi1.setModificationDate(zdt1);
        bi1.setTimeTag(zdt1);
        bi1.setPreValue(VALUE);
        bi1.setPostValue(VALUE);
        entityManager.persist(bi1);

        BIndexEntity bi2 = new BIndexEntity();
        bi2.setId(UUID.randomUUID());
        ZonedDateTime zdt2 = ZonedDateTime.parse("2017-01-02T13:00:00z[UTC]");
        bi2.setCreationDate(zdt2);
        bi2.setModificationDate(zdt2);
        bi2.setTimeTag(zdt2);
        bi2.setPreValue(VALUE + 1);
        bi2.setPostValue(VALUE + 1);
        entityManager.persist(bi2);

        BIndexEntity bi3 = new BIndexEntity();
        bi3.setId(UUID.randomUUID());
        ZonedDateTime zdt3 = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");
        bi3.setCreationDate(zdt3);
        bi3.setModificationDate(zdt3);
        bi3.setTimeTag(zdt3);
        bi3.setPreValue(VALUE + 2);
        bi3.setPostValue(VALUE + 2);
        entityManager.persist(bi3);

        BIndexEntity bi4 = new BIndexEntity();
        bi4.setId(UUID.randomUUID());
        ZonedDateTime zdt4 = ZonedDateTime.parse("2017-01-03T13:00:00z[UTC]");
        bi4.setCreationDate(zdt4);
        bi4.setModificationDate(zdt4);
        bi4.setTimeTag(zdt4);
        bi4.setPreValue(VALUE + 3);
        bi4.setPostValue(VALUE + 3);
        entityManager.persist(bi4);
        
        BIndexEntity bi5 = new BIndexEntity();
        bi5.setId(UUID.randomUUID());
        ZonedDateTime zdt5 = ZonedDateTime.parse("2017-01-06T13:00:00z[UTC]");
        bi5.setCreationDate(zdt5);
        bi5.setModificationDate(zdt5);
        bi5.setTimeTag(zdt5);
        bi5.setPreValue(VALUE + 4);
        bi5.setPostValue(VALUE + 4);
        entityManager.persist(bi5);

        ZonedDateTime ffn = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nfn = ZonedDateTime.parse("2017-01-05T12:00:00z[UTC]");

        List<BIndex> bil = bIndexReaderRepository.listByPeriod(ffn, nfn);

        assertNotNull(bil);
        assertEquals(2, bil.size());
        assertEquals(zdt2, bil.get(0).getTimeTag());
        assertEquals(zdt4, bil.get(1).getTimeTag());
    }

}
