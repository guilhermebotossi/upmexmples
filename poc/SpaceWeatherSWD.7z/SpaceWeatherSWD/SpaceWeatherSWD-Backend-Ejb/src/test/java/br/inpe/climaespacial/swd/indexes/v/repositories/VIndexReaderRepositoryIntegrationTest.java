package br.inpe.climaespacial.swd.indexes.v.repositories;

import br.inpe.climaespacial.swd.commons.factories.DefaultListFactory;
import br.inpe.climaespacial.swd.indexes.v.dtos.VIndex;
import br.inpe.climaespacial.swd.indexes.v.entities.VIndexEntity;
import br.inpe.climaespacial.swd.indexes.v.factories.DefaultVIndexFactory;
import br.inpe.climaespacial.swd.indexes.v.mappers.DefaultVIndexMapper;
import br.inpe.climaespacial.swd.test.BaseIntegrationTest;
import br.inpe.climaespacial.swd.test.EntityManagerFactoryProducer;
import br.inpe.climaespacial.swd.test.EntityManagerProducer;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import org.jglue.cdiunit.InRequestScope;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(CdiRunner.class)
@AdditionalClasses({
    DefaultVIndexReaderRepository.class,
    EntityManagerFactoryProducer.class,
    EntityManagerProducer.class,
    DefaultVIndexMapper.class,
    DefaultVIndexFactory.class,
    DefaultListFactory.class
})
public class VIndexReaderRepositoryIntegrationTest extends BaseIntegrationTest {

    private static final double VALUE = 1.0;

    @Inject
    private EntityManager entityManager;

    @Inject
    private VIndexReaderRepository vIndexReaderRepository;

    @InRequestScope
    @Test
    public void getLastCalculatedHour_called_returnsNull() {
        ZonedDateTime lch = vIndexReaderRepository.getNextHourToBeCalculated();

        assertNull(lch);
    }

    @InRequestScope
    @Test
    public void getLastCalculatedHour_called_returnsLastTimeTag() {
        VIndexEntity vi1 = new VIndexEntity();
        vi1.setId(UUID.randomUUID());
        ZonedDateTime zdt1 = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        vi1.setCreationDate(zdt1);
        vi1.setModificationDate(zdt1);
        vi1.setTimeTag(zdt1);
        vi1.setValue(VALUE);
        entityManager.persist(vi1);

        VIndexEntity vi2 = new VIndexEntity();
        vi2.setId(UUID.randomUUID());
        ZonedDateTime zdt2 = ZonedDateTime.parse("2016-01-01T12:00:00z[UTC]");
        vi2.setCreationDate(zdt2);
        vi2.setModificationDate(zdt2);
        vi2.setTimeTag(zdt2);
        vi2.setValue(VALUE);
        entityManager.persist(vi2);

        ZonedDateTime lch = vIndexReaderRepository.getNextHourToBeCalculated();

        assertNotNull(lch);
        assertEquals(zdt1.plusHours(1), lch);
    }

    @InRequestScope
    @Test
    public void listByPeriod_called_returnsListEmpty() {

        ZonedDateTime ffn = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nfn = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");

        List<VIndex> vil = vIndexReaderRepository.listByPeriod(ffn, nfn);

        assertNotNull(vil);
        assertEquals(0, vil.size());
    }

    @InRequestScope
    @Test
    public void listByPeriod_called_returnsList() {

        VIndexEntity vi1 = new VIndexEntity();
        vi1.setId(UUID.randomUUID());
        ZonedDateTime zdt1 = ZonedDateTime.parse("2017-01-02T12:00:00z[UTC]");
        vi1.setCreationDate(zdt1);
        vi1.setModificationDate(zdt1);
        vi1.setTimeTag(zdt1);
        vi1.setValue(VALUE);
        entityManager.persist(vi1);

        VIndexEntity vi2 = new VIndexEntity();
        vi2.setId(UUID.randomUUID());
        ZonedDateTime zdt2 = ZonedDateTime.parse("2017-01-02T13:00:00z[UTC]");
        vi2.setCreationDate(zdt2);
        vi2.setModificationDate(zdt2);
        vi2.setTimeTag(zdt2);
        vi1.setValue(VALUE);
        entityManager.persist(vi2);

        VIndexEntity vi3 = new VIndexEntity();
        vi3.setId(UUID.randomUUID());
        ZonedDateTime zdt3 = ZonedDateTime.parse("2017-01-04T13:00:00z[UTC]");
        vi3.setCreationDate(zdt3);
        vi3.setModificationDate(zdt3);
        vi3.setTimeTag(zdt3);
        vi1.setValue(VALUE);
        entityManager.persist(vi3);

        ZonedDateTime ffn = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nfn = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");

        List<VIndex> vil = vIndexReaderRepository.listByPeriod(ffn, nfn);

        assertNotNull(vil);
        assertEquals(2, vil.size());
        assertEquals(vil.get(0).getTimeTag(), zdt1);
        assertEquals(vil.get(1).getTimeTag(), zdt2);
    }

}
