
package br.inpe.climaespacial.swd.indexes.z.repositories;

import br.inpe.climaespacial.swd.commons.factories.DefaultListFactory;
import br.inpe.climaespacial.swd.indexes.z.dtos.ZIndex;
import br.inpe.climaespacial.swd.indexes.z.entities.ZIndexEntity;
import br.inpe.climaespacial.swd.indexes.z.factories.DefaultZIndexFactory;
import br.inpe.climaespacial.swd.indexes.z.mappers.DefaultZIndexMapper;
import br.inpe.climaespacial.swd.test.BaseIntegrationTest;
import br.inpe.climaespacial.swd.test.EntityManagerFactoryProducer;
import br.inpe.climaespacial.swd.test.EntityManagerProducer;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import org.jglue.cdiunit.InRequestScope;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(CdiRunner.class)
@AdditionalClasses({
    DefaultZIndexReaderRepository.class,
    EntityManagerFactoryProducer.class,
    EntityManagerProducer.class,
    DefaultZIndexMapper.class,
    DefaultZIndexFactory.class,
    DefaultListFactory.class
})
public class ZIndexReaderRepositoryIntegrationTest extends BaseIntegrationTest {
    
    private static final double VALUE = 1.0;
    
    @Inject
    private EntityManager entityManager;
    
    @Inject
    private ZIndexReaderRepository zIndexReaderRepository;
    
    @InRequestScope
    @Test
    public void getLastCalculatedHour_called_returnsNull() {
        ZonedDateTime lch = zIndexReaderRepository.getNextHourToBeCalculated();

        assertNull(lch);
    }
    
    @InRequestScope
    @Test
    public void getLastCalculatedHour_called_returnsLastTimeTag() {
        ZIndexEntity zi1 = new ZIndexEntity();
        zi1.setId(UUID.randomUUID());
        ZonedDateTime zdt1 = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");        
        zi1.setCreationDate(zdt1);
        zi1.setModificationDate(zdt1);
        zi1.setTimeTag(zdt1);
        zi1.setPreValue(VALUE);
        zi1.setPostValue(VALUE);
        entityManager.persist(zi1);
        
        ZIndexEntity zi2 = new ZIndexEntity();
        zi2.setId(UUID.randomUUID());
        ZonedDateTime zdt2 = ZonedDateTime.parse("2016-01-01T12:00:00z[UTC]");
        zi2.setCreationDate(zdt2);
        zi2.setModificationDate(zdt2);
        zi2.setTimeTag(zdt2);
        zi1.setPreValue(VALUE);
        zi1.setPostValue(VALUE);
        entityManager.persist(zi2);
        
        ZonedDateTime lch = zIndexReaderRepository.getNextHourToBeCalculated();

        assertNotNull(lch);
        assertEquals(zdt1.plusHours(1), lch);        
    }
    
    @InRequestScope
    @Test
    public void listByPeriod_called_returnsListEmpty() {

        ZonedDateTime ffn = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nfn = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");

        List<ZIndex> zil = zIndexReaderRepository.listByPeriod(ffn, nfn);

        assertNotNull(zil);
        assertEquals(0, zil.size());
    }

    @InRequestScope
    @Test
    public void listByPeriod_called_returnsList() {

        ZIndexEntity zi1 = new ZIndexEntity();
        zi1.setId(UUID.randomUUID());
        ZonedDateTime zdt1 = ZonedDateTime.parse("2017-01-02T12:00:00z[UTC]");
        zi1.setCreationDate(zdt1);
        zi1.setModificationDate(zdt1);
        zi1.setTimeTag(zdt1);
        zi1.setPreValue(VALUE);
        zi1.setPostValue(VALUE);
        entityManager.persist(zi1);

        ZIndexEntity zi2 = new ZIndexEntity();
        zi2.setId(UUID.randomUUID());
        ZonedDateTime zdt2 = ZonedDateTime.parse("2017-01-02T13:00:00z[UTC]");
        zi2.setCreationDate(zdt2);
        zi2.setModificationDate(zdt2);
        zi2.setTimeTag(zdt2);
        zi1.setPreValue(VALUE);
        zi1.setPostValue(VALUE);
        entityManager.persist(zi2);

        ZIndexEntity zi3 = new ZIndexEntity();
        zi3.setId(UUID.randomUUID());
        ZonedDateTime zdt3 = ZonedDateTime.parse("2017-01-04T13:00:00z[UTC]");
        zi3.setCreationDate(zdt3);
        zi3.setModificationDate(zdt3);
        zi3.setTimeTag(zdt3);
        zi1.setPreValue(VALUE);
        zi1.setPostValue(VALUE);
        entityManager.persist(zi3);

        ZonedDateTime ffn = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nfn = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");

        List<ZIndex> zil = zIndexReaderRepository.listByPeriod(ffn, nfn);

        assertNotNull(zil);
        assertEquals(2, zil.size());
        assertEquals(zil.get(0).getTimeTag(), zdt1);
        assertEquals(zil.get(1).getTimeTag(), zdt2);
    }
    

}
