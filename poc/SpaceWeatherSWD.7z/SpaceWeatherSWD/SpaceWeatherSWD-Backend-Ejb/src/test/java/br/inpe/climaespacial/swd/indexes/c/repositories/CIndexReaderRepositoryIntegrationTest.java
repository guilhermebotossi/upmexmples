package br.inpe.climaespacial.swd.indexes.c.repositories;

import br.inpe.climaespacial.swd.commons.factories.DefaultListFactory;
import br.inpe.climaespacial.swd.indexes.c.dtos.CIndex;
import br.inpe.climaespacial.swd.indexes.c.entities.CIndexEntity;
import br.inpe.climaespacial.swd.indexes.c.factories.DefaultCIndexFactory;
import br.inpe.climaespacial.swd.indexes.c.mappers.DefaultCIndexMapper;
import br.inpe.climaespacial.swd.test.BaseIntegrationTest;
import br.inpe.climaespacial.swd.test.EntityManagerFactoryProducer;
import br.inpe.climaespacial.swd.test.EntityManagerProducer;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import org.jglue.cdiunit.InRequestScope;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(CdiRunner.class)
@AdditionalClasses({
    DefaultCIndexReaderRepository.class,
    EntityManagerFactoryProducer.class,
    EntityManagerProducer.class,
    DefaultCIndexMapper.class,
    DefaultCIndexFactory.class,
    DefaultListFactory.class           
})
public class CIndexReaderRepositoryIntegrationTest extends BaseIntegrationTest {

    private static final double VALUE = 1.0;

    @Inject
    private EntityManager entityManager;

    @Inject
    private CIndexReaderRepository cIndexReaderRepository;

    @InRequestScope
    @Test
    public void getLastCalculatedHour_called_returnsNull() {
        ZonedDateTime nhtbc = cIndexReaderRepository.getNextHourToBeCalculated();

        assertNull(nhtbc);
    }

    @InRequestScope
    @Test
    public void getLastCalculatedHour_called_returnsLastTimeTag() {
        CIndexEntity ci1 = new CIndexEntity();
        ci1.setId(UUID.randomUUID());
        ZonedDateTime zdt1 = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ci1.setCreationDate(zdt1);
        ci1.setModificationDate(zdt1);
        ci1.setTimeTag(zdt1);
        ci1.setPreValue(VALUE);
        ci1.setPostValue(VALUE);
        entityManager.persist(ci1);

        CIndexEntity ci2 = new CIndexEntity();
        ci2.setId(UUID.randomUUID());
        ZonedDateTime zdt2 = ZonedDateTime.parse("2016-01-01T12:00:00z[UTC]");
        ci2.setCreationDate(zdt2);
        ci2.setModificationDate(zdt2);
        ci2.setTimeTag(zdt2);
        ci1.setPreValue(VALUE);
        ci1.setPostValue(VALUE);
        entityManager.persist(ci2);

        ZonedDateTime nhtbc = cIndexReaderRepository.getNextHourToBeCalculated();

        assertNotNull(nhtbc);
        assertEquals(zdt1.plusHours(1), nhtbc);
    }

    @InRequestScope
    @Test
    public void listByPeriod_called_returnsListEmpty() {

        ZonedDateTime ffn = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nfn = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");

        List<CIndex> cil = cIndexReaderRepository.listByPeriod(ffn, nfn);

        assertNotNull(cil);
        assertEquals(0, cil.size());
    }

    @InRequestScope
    @Test
    public void listByPeriod_called_returnsList() {

        CIndexEntity ci1 = new CIndexEntity();
        ci1.setId(UUID.randomUUID());
        ZonedDateTime zdt1 = ZonedDateTime.parse("2017-01-02T12:00:00z[UTC]");
        ci1.setCreationDate(zdt1);
        ci1.setModificationDate(zdt1);
        ci1.setTimeTag(zdt1);
        ci1.setPreValue(VALUE);
        ci1.setPostValue(VALUE);
        entityManager.persist(ci1);

        CIndexEntity ci2 = new CIndexEntity();
        ci2.setId(UUID.randomUUID());
        ZonedDateTime zdt2 = ZonedDateTime.parse("2017-01-02T13:00:00z[UTC]");
        ci2.setCreationDate(zdt2);
        ci2.setModificationDate(zdt2);
        ci2.setTimeTag(zdt2);
        ci1.setPreValue(VALUE);
        ci1.setPostValue(VALUE);
        entityManager.persist(ci2);

        CIndexEntity ci3 = new CIndexEntity();
        ci3.setId(UUID.randomUUID());
        ZonedDateTime zdt3 = ZonedDateTime.parse("2017-01-04T13:00:00z[UTC]");
        ci3.setCreationDate(zdt3);
        ci3.setModificationDate(zdt3);
        ci3.setTimeTag(zdt3);
        ci1.setPreValue(VALUE);
        ci1.setPostValue(VALUE);
        entityManager.persist(ci3);

        ZonedDateTime ffn = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nfn = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");

        List<CIndex> cil = cIndexReaderRepository.listByPeriod(ffn, nfn);

        assertNotNull(cil);
        assertEquals(2, cil.size());
        assertEquals(cil.get(0).getTimeTag(), zdt1);
        assertEquals(cil.get(1).getTimeTag(), zdt2);
    }

}
