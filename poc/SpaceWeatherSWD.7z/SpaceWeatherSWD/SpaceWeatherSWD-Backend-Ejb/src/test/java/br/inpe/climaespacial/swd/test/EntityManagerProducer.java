package br.inpe.climaespacial.swd.test;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Disposes;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

public class EntityManagerProducer {

	@Inject
	private EntityManagerFactory entityManagerFactory;

	@Produces
	@RequestScoped
	public EntityManager create() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		return entityManager;
	}

	public void dispose(@Disposes EntityManager entityManager) {
		entityManager.getTransaction().rollback();
		entityManager.close();
	}
}
