package br.inpe.climaespacial.swd.commons.services;

public class DefaultTestService implements TestService {

}
