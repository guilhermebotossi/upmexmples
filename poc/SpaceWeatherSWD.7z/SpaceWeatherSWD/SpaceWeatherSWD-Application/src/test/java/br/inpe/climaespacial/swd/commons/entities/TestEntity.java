package br.inpe.climaespacial.swd.commons.entities;

import javax.enterprise.context.Dependent;

@Dependent
public class TestEntity extends BaseEntity {

}
