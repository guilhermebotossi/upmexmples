package br.inpe.climaespacial.swd.calculation.services;

import br.inpe.climaespacial.swd.calculation.TestHelper;
import br.inpe.climaespacial.swd.calculation.dtos.MagPlasma;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;

@RunWith(Theories.class)
public class RmpValueCalculatorTest {

	@DataPoints
	public static String[][] pairs = TestHelper.getPairs();
	private RmpValueCalculator rmpValueCalculator;
	
	@Before
	public void before() {
		rmpValueCalculator = new DefaultRmpValueCalculator();
	}

	@Test
	public void calculate_calledWithInvalidArgument_throws() {
		RuntimeException re = null;

		try {
			rmpValueCalculator.calculate(null, 0.0);
		} catch (RuntimeException e) {
			re = e;
		}

		assertNotNull(re);
		assertEquals("Parâmetro \"magPlasma\" null/empty.", re.getMessage());
	}
	
	@Test
	public void calculate_calledWithBzGsmNull_returnsNull() {
		MagPlasma mp = new MagPlasma();
		mp.setBzGsm(null);
		
		Double rmp = rmpValueCalculator.calculate(mp, 0.0);
		
		assertNull(rmp);
	}
	
	@Test
	public void calculate_calledWithDprNull_returnsNull() {
		MagPlasma mp = new MagPlasma();
		mp.setBzGsm(1.0);
		
		Double rmp = rmpValueCalculator.calculate(mp, null);
		
		assertNull(rmp);
	}

	@Theory
	public void calculate_calledWithValidArgument_succeeds(String[] data) {
		MagPlasma mpp = new MagPlasma();
		mpp.setBzGsm(Double.valueOf(data[4]).doubleValue());

		double rmp = rmpValueCalculator.calculate(mpp, Double.valueOf(data[9]).doubleValue());

		assertEquals(Double.valueOf(data[10]).doubleValue(), rmp, 0.02);
	}
}
