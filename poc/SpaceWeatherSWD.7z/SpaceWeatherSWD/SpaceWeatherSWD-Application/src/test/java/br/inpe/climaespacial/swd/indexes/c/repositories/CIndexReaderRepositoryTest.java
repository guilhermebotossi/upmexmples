package br.inpe.climaespacial.swd.indexes.c.repositories;

import br.inpe.climaespacial.swd.indexes.c.entities.CIndexEntity;
import br.inpe.climaespacial.swd.indexes.c.dtos.CIndex;
import br.inpe.climaespacial.swd.commons.EmbraceMockito;
import br.inpe.climaespacial.swd.indexes.c.mappers.CIndexMapper;
import static br.inpe.climaespacial.swd.commons.EmbraceMockito.mockList;
import static br.inpe.climaespacial.swd.commons.EmbraceMockito.mockTypedQuery;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.List;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(CdiRunner.class)
@AdditionalClasses(DefaultCIndexReaderRepository.class)
public class CIndexReaderRepositoryTest {

    private static final String QUERY = "SELECT MAX(cie.timeTag) FROM CIndexEntity cie";
    
    private static final String QUERY_LIST = "SELECT cie FROM CIndexEntity cie WHERE cie.timeTag BETWEEN :farthestFromNow AND :nearestFromNow ORDER BY cie.timeTag";

    @Produces
    @Mock
    private EntityManager entityManager;
    
    @Produces
    @Mock
    private CIndexMapper cIndexMapper;

    @Inject
    private CIndexReaderRepository cIndexReaderRepository;

    @Test
    public void getLastCalculatedHour_called_returnsNull() {

        TypedQuery<ZonedDateTime> tq = EmbraceMockito.mockTypedQuery(ZonedDateTime.class);
        when(entityManager.createQuery(QUERY, ZonedDateTime.class)).thenReturn(tq);
        
        ZonedDateTime zdt = null;        
        List<ZonedDateTime> zdtl = Arrays.asList(zdt); 
        when(tq.getResultList()).thenReturn(zdtl);

        ZonedDateTime lch = cIndexReaderRepository.getNextHourToBeCalculated();

        assertNull(lch);
    }

    @Test
    public void getLastCalculatedHour_called_returnsLastTimeTag() {
        
        TypedQuery<ZonedDateTime> tq = EmbraceMockito.mockTypedQuery(ZonedDateTime.class);
        when(entityManager.createQuery(QUERY, ZonedDateTime.class)).thenReturn(tq);
        
        ZonedDateTime zdt = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");        
        List<ZonedDateTime> zdtl = Arrays.asList(zdt);        
        when(tq.getResultList()).thenReturn(zdtl);        

        ZonedDateTime lch = cIndexReaderRepository.getNextHourToBeCalculated();

        assertNotNull(lch);
        assertEquals(zdt.plusHours(1), lch);
    }
    
      @Test
    public void listByPeriod_called_returnsListEmpty() {

        TypedQuery<CIndexEntity> tq = mockTypedQuery(CIndexEntity.class);
        when(entityManager.createQuery(QUERY_LIST, CIndexEntity.class)).thenReturn(tq);

        List<CIndexEntity> ciel = mockList(CIndexEntity.class);
        when(tq.getResultList()).thenReturn(ciel);

        List<CIndex> expectedCil = mockList(CIndex.class);
        when(cIndexMapper.map(ciel)).thenReturn(expectedCil);

        ZonedDateTime ffn = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nfn = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");

        List<CIndex> cil = cIndexReaderRepository.listByPeriod(ffn, nfn);

        verify(tq, times(1)).setParameter("farthestFromNow", ffn);
        verify(tq, times(1)).setParameter("nearestFromNow", nfn);
        verify(cIndexMapper, times(1)).map(ciel);
        assertNotNull(cil);
        assertSame(expectedCil, cil);
        assertEquals(0, cil.size());
    }

    @Test
    public void listByPeriod_called_returnsListOfCIndexFromPeriod() {

        TypedQuery<CIndexEntity> tq = mockTypedQuery(CIndexEntity.class);
        when(entityManager.createQuery(QUERY_LIST, CIndexEntity.class)).thenReturn(tq);

        List<CIndexEntity> ciel = Arrays.asList(mock(CIndexEntity.class), mock(CIndexEntity.class));
        when(tq.getResultList()).thenReturn(ciel);

        List<CIndex> expectedCil = Arrays.asList(mock(CIndex.class), mock(CIndex.class));
        when(cIndexMapper.map(ciel)).thenReturn(expectedCil);

        ZonedDateTime ffn = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nfn = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");

        List<CIndex> cil = cIndexReaderRepository.listByPeriod(ffn, nfn);

        verify(tq, times(1)).setParameter("farthestFromNow", ffn);
        verify(tq, times(1)).setParameter("nearestFromNow", nfn);
        verify(cIndexMapper, times(1)).map(ciel);
        assertNotNull(cil);
        assertSame(expectedCil, cil);
        assertEquals(2, cil.size());        
    }

}
