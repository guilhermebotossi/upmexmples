package br.inpe.climaespacial.swd.commons.factories;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import javax.inject.Inject;

import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import org.junit.Test;
import org.junit.runner.RunWith;

import br.inpe.climaespacial.swd.commons.services.DefaultTestService;
import br.inpe.climaespacial.swd.commons.services.TestService;

@RunWith(CdiRunner.class)
@AdditionalClasses({ DefaultTestServiceFactory.class, DefaultTestService.class })
public class FactoryTest {

	@Inject
	private TestServiceFactory testServiceFactory;

	@Test
	public void create_called_returnsInstance() {
		TestService testService = testServiceFactory.create();

		assertNotNull(testService);
		assertThat(testService, instanceOf(TestService.class));
	}
}
