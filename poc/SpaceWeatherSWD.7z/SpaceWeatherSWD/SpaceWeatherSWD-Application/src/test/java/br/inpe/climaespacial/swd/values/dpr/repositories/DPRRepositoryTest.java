package br.inpe.climaespacial.swd.values.dpr.repositories;

import static br.inpe.climaespacial.swd.commons.EmbraceMockito.mockList;
import static br.inpe.climaespacial.swd.commons.EmbraceMockito.mockTypedQuery;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.ZonedDateTime;
import java.util.List;

import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;

import br.inpe.climaespacial.swd.acquisition.home.IntervalValidator;
import br.inpe.climaespacial.swd.values.dpr.dtos.DPR;
import br.inpe.climaespacial.swd.values.dpr.entities.DPREntity;
import br.inpe.climaespacial.swd.values.dpr.mappers.DPRMapper;

@RunWith(CdiRunner.class)
@AdditionalClasses({DefaultDPRRepository.class})
public class DPRRepositoryTest {
	
	private final ZonedDateTime initialDateTime = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
	private final ZonedDateTime finalDateTime = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");
	private static final int MAX_NUMBER_OF_DAYS = 3;
	private static final String SQL = "SELECT NEW br.inpe.climaespacial.swd.values.dpr.entities.DPREntity(me.timeTag, me.dpr) "
			+ "FROM MagEntity me "
			+ "WHERE "
			+ "me.timeTag >= :initialDateTime and "
			+ "me.timeTag <= :finalDateTime";
	
	@Mock
	@Produces
	private EntityManager entityManager;
	
	@Mock
	@Produces
	private IntervalValidator intervalValidator;
	
	@Mock
	@Produces
	private DPRMapper dprMapper;
	
	@Inject
	private DPRRepository bTRepository;
	
	@Test
	public void list_calledWithInitialTimeNull_throws(){
		RuntimeException re = null;
		
		try {
			bTRepository.list(null, null);
		} catch(RuntimeException e) {
			re = e;
		}
		
		assertNotNull(re);
		assertEquals("Parametro \"initialDateTime\" null", re.getMessage());
	}
	
	@Test
	public void list_calledWithFinalTimeNull_throws(){
		RuntimeException re = null;
		
		try {
			bTRepository.list(initialDateTime, null);
		} catch(RuntimeException e) {
			re = e;
		}
		
		assertNotNull(re);
		assertEquals("Parametro \"finalDateTime\" null", re.getMessage()); 
	}
	
	@Test
	public void list_calledWithValidDates_succedds(){
		TypedQuery<DPREntity> tq = mockTypedQuery(DPREntity.class);
		List<DPREntity> bel = mockList(DPREntity.class);
		List<DPR> bl1 = mockList(DPR.class);
		when(entityManager.createQuery(SQL, DPREntity.class)).thenReturn(tq);
		when(tq.getResultList()).thenReturn(bel);
		when(dprMapper.map(bel)).thenReturn(bl1);
		
		List<DPR> bl2 = bTRepository.list(initialDateTime, finalDateTime);
		
		verify(intervalValidator).validate(initialDateTime, finalDateTime, MAX_NUMBER_OF_DAYS);
		verify(entityManager).createQuery(SQL, DPREntity.class);
		verify(tq).setParameter("initialDateTime", initialDateTime);
		verify(tq).setParameter("finalDateTime", finalDateTime);
		verify(tq).getResultList();
		verify(dprMapper).map(bel);
		assertNotNull(bl2);
		assertSame(bl1, bl2); 
	}
	

}
