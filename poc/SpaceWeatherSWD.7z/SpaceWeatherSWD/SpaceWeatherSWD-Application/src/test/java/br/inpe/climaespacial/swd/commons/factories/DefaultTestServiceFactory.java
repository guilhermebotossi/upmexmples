package br.inpe.climaespacial.swd.commons.factories;

import br.inpe.climaespacial.swd.commons.services.TestService;

public class DefaultTestServiceFactory extends DefaultFactory<TestService> implements TestServiceFactory {

	public DefaultTestServiceFactory() {
		super(TestService.class);
	}
}
