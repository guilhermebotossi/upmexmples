package br.inpe.climaespacial.swd.values.bz.factories;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.ZonedDateTime;

import javax.inject.Inject;

import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import org.junit.Test;
import org.junit.runner.RunWith;

import br.inpe.climaespacial.swd.acquisition.home.FactoryProducer;
import br.inpe.climaespacial.swd.values.bz.dtos.BZ;

@RunWith(CdiRunner.class)
@AdditionalClasses({FactoryProducer.class,
					DefaultBZFactory.class})
public class BZFactoryTest {
	
	@Inject
	private BZFactory bzFactory;
	
	@Test
	public void create_called_succeeds() {
		BZ bz = bzFactory.create(ZonedDateTime.parse("2017-01-01T12:30:00z[UTC]"), 2.0); 
		assertNotNull(bz);
		assertEquals(BZ.class, bz.getClass());
		
		
	}

}
