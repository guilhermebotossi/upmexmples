package br.inpe.climaespacial.swd.acquisition.home;

import javax.inject.Inject;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(CdiRunner.class)
@AdditionalClasses({
    DefaultIndexEntryFactory.class
})
public class IndexEntryFactoryTest {

    @Inject
    private IndexEntryFactory indexEntryFactory;

    @Test
    public void create_called_returnsIndexData() {

        IndexEntry ie = indexEntryFactory.create();

        assertNotNull(ie);
        assertEquals(IndexEntry.class, ie.getClass());
    }

}
