package br.inpe.climaespacial.swd.commons.factories;

import br.inpe.climaespacial.swd.commons.entities.TestEntity;

public class DefaultTestEntityFactory extends DefaultEntityFactory<TestEntity> implements TestEntityFactory {
    
    public DefaultTestEntityFactory() {
        super(TestEntity.class);
    }
}
