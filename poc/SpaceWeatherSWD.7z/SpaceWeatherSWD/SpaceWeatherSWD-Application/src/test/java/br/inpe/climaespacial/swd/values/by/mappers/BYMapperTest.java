package br.inpe.climaespacial.swd.values.by.mappers;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.List;

import javax.enterprise.inject.Produces;
import javax.inject.Inject;

import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;

import br.inpe.climaespacial.swd.commons.factories.DefaultListFactory;
import br.inpe.climaespacial.swd.values.by.dtos.BY;
import br.inpe.climaespacial.swd.values.by.entities.BYEntity;
import br.inpe.climaespacial.swd.values.by.factories.BYFactory;

@RunWith(CdiRunner.class)
@AdditionalClasses({DefaultBYMapper.class,
					DefaultListFactory.class
	})
public class BYMapperTest {
	
    @Produces
    @Mock
    private BYFactory byFactory;
	
	@Inject
	private BYMapper byMapper;

	@Test
	public void map_calledWithNull_throws() {
        RuntimeException re = null;

        try {
        	byMapper.map(null);
        } catch (RuntimeException e) {
            re = e;
        }

        assertNotNull(re);
        assertEquals("Parâmetro \"byEntityList\" null.", re.getMessage());
	}
	
	@Test
	public void map_called_succeeds() {
		ZonedDateTime zdt = ZonedDateTime.parse("2017-01-01T12:30:00z[UTC]");
		Double value = 2.0;
		
		BYEntity bye = new BYEntity(zdt, value);
		BY by1 = new BY();
		by1.setTimeTag(zdt);
		by1.setBY(value);
		List<BYEntity> byel = Arrays.asList(bye);
		
		when(byFactory.create(zdt, value)).thenReturn(by1);
		
		List<BY> byl = byMapper.map(byel);
		
		verify(byFactory).create(zdt, value); 
		assertNotNull(byl);
		assertThat(byl, is(not(empty())));
		assertEquals(byel.size(), byl.size());
		BY by2 = byl.get(0);
		assertEquals(zdt, by2.getTimeTag());
		assertEquals(value, by2.getBY());
	}
}
