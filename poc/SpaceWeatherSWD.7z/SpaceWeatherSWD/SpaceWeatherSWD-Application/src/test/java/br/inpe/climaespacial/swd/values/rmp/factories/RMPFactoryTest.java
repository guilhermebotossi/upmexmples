package br.inpe.climaespacial.swd.values.rmp.factories;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.ZonedDateTime;

import javax.inject.Inject;

import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import org.junit.Test;
import org.junit.runner.RunWith;

import br.inpe.climaespacial.swd.acquisition.home.FactoryProducer;
import br.inpe.climaespacial.swd.values.rmp.dtos.RMP;

@RunWith(CdiRunner.class)
@AdditionalClasses({FactoryProducer.class,
					DefaultRMPFactory.class})
public class RMPFactoryTest {
	
	@Inject
	private RMPFactory rmpFactory;
	
	@Test
	public void create_called_succeeds() {
		RMP rmp = rmpFactory.create(ZonedDateTime.parse("2017-01-01T12:30:00z[UTC]"), 2.0); 
		assertNotNull(rmp);
		assertEquals(RMP.class, rmp.getClass());
		
		
	}

}
