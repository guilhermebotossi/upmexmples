package br.inpe.climaespacial.swd.values.by.average.repositories;

import static br.inpe.climaespacial.swd.commons.EmbraceMockito.mockList;
import static br.inpe.climaespacial.swd.commons.EmbraceMockito.mockTypedQuery;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.ZonedDateTime;
import java.util.List;

import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;

import br.inpe.climaespacial.swd.acquisition.home.IntervalValidator;
import br.inpe.climaespacial.swd.values.by.average.dtos.AverageBY;
import br.inpe.climaespacial.swd.values.by.average.entities.AverageBYEntity;
import br.inpe.climaespacial.swd.values.by.average.mappers.AverageBYMapper;

@RunWith(CdiRunner.class)
@AdditionalClasses({DefaultAverageBYRepository.class})
public class AverageBYRepositoryTest {
	
	private final ZonedDateTime initialDateTime = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
	private final ZonedDateTime finalDateTime = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");
	private static final int MAX_NUMBER_OF_DAYS = 3;
	private static final String SQL = "SELECT NEW br.inpe.climaespacial.swd.values.averageBY.entities.AverageBYEntity(me.timeTag, me.averageBY) "
			+ "FROM MagEntity me "
			+ "WHERE "
			+ "me.timeTag >= :initialDateTime and "
			+ "me.timeTag <= :finalDateTime";
	
	@Mock
	@Produces
	private EntityManager entityManager;
	
	@Mock
	@Produces
	private IntervalValidator intervalValidator;
	
	@Mock
	@Produces
	private AverageBYMapper averageBYMapper;
	
	@Inject
	private AverageBYRepository bTRepository;
	
	@Test
	public void list_calledWithInitialTimeNull_throws(){
		RuntimeException re = null;
		
		try {
			bTRepository.list(null, null);
		} catch(RuntimeException e) {
			re = e;
		}
		
		assertNotNull(re);
		assertEquals("Parametro \"initialDateTime\" null", re.getMessage());
	}
	
	@Test
	public void list_calledWithFinalTimeNull_throws(){
		RuntimeException re = null;
		
		try {
			bTRepository.list(initialDateTime, null);
		} catch(RuntimeException e) {
			re = e;
		}
		
		assertNotNull(re);
		assertEquals("Parametro \"finalDateTime\" null", re.getMessage()); 
	}
	
	@Test
	public void list_calledWithValidDates_succedds(){
		TypedQuery<AverageBYEntity> tq = mockTypedQuery(AverageBYEntity.class);
		List<AverageBYEntity> bel = mockList(AverageBYEntity.class);
		List<AverageBY> bl1 = mockList(AverageBY.class);
		when(entityManager.createQuery(SQL, AverageBYEntity.class)).thenReturn(tq);
		when(tq.getResultList()).thenReturn(bel);
		when(averageBYMapper.map(bel)).thenReturn(bl1);
		
		List<AverageBY> bl2 = bTRepository.list(initialDateTime, finalDateTime);
		
		verify(intervalValidator).validate(initialDateTime, finalDateTime, MAX_NUMBER_OF_DAYS);
		verify(entityManager).createQuery(SQL, AverageBYEntity.class);
		verify(tq).setParameter("initialDateTime", initialDateTime);
		verify(tq).setParameter("finalDateTime", finalDateTime);
		verify(tq).getResultList();
		verify(averageBYMapper).map(bel);
		assertNotNull(bl2);
		assertSame(bl1, bl2); 
	}
	

}
