package br.inpe.climaespacial.swd.commons.factories;

import br.inpe.climaespacial.swd.commons.services.TestService;

public interface TestServiceFactory extends Factory<TestService> {

}
