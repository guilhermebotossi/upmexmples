package br.inpe.climaespacial.swd.indexes.b.repositories;

import static br.inpe.climaespacial.swd.commons.EmbraceMockito.mockList;
import static br.inpe.climaespacial.swd.commons.EmbraceMockito.mockTypedQuery;
import br.inpe.climaespacial.swd.indexes.b.dtos.BIndex;
import br.inpe.climaespacial.swd.indexes.b.entities.BIndexEntity;
import br.inpe.climaespacial.swd.indexes.b.mappers.BIndexMapper;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.List;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(CdiRunner.class)
@AdditionalClasses(DefaultBIndexReaderRepository.class)
public class BIndexReaderRepositoryTest {

    private static final String QUERY = "SELECT MAX(bie.timeTag) FROM BIndexEntity bie";

    private static final String QUERY_LIST = "SELECT bie FROM BIndexEntity bie WHERE bie.timeTag BETWEEN :farthestFromNow AND :nearestFromNow ORDER BY bie.timeTag";

    @Produces
    @Mock
    private EntityManager entityManager;

    @Produces
    @Mock
    private BIndexMapper bIndexMapper;

    @Inject
    private BIndexReaderRepository bIndexReaderRepository;

    @Test
    public void getLastCalculatedHour_called_returnsNull() {

        TypedQuery<ZonedDateTime> tq = mockTypedQuery(ZonedDateTime.class);
        when(entityManager.createQuery(QUERY, ZonedDateTime.class)).thenReturn(tq);

        ZonedDateTime zdt = null;
        List<ZonedDateTime> zdtl = Arrays.asList(zdt);
        when(tq.getResultList()).thenReturn(zdtl);

        ZonedDateTime nhtbc = bIndexReaderRepository.getNextHourToBeCalculated();

        assertNull(nhtbc);
    }

    @Test
    public void getLastCalculatedHour_called_returnsLastTimeTag() {

        TypedQuery<ZonedDateTime> tq = mockTypedQuery(ZonedDateTime.class);
        when(entityManager.createQuery(QUERY, ZonedDateTime.class)).thenReturn(tq);

        ZonedDateTime zdt = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        List<ZonedDateTime> zdtl = Arrays.asList(zdt);
        when(tq.getResultList()).thenReturn(zdtl);

        ZonedDateTime nhtbc = bIndexReaderRepository.getNextHourToBeCalculated();

        assertNotNull(nhtbc);
        assertEquals(zdt.plusHours(1), nhtbc);
    }

    @Test
    public void listByPeriod_called_returnsListEmpty() {

        TypedQuery<BIndexEntity> tq = mockTypedQuery(BIndexEntity.class);
        when(entityManager.createQuery(QUERY_LIST, BIndexEntity.class)).thenReturn(tq);

        List<BIndexEntity> biel = mockList(BIndexEntity.class);
        when(tq.getResultList()).thenReturn(biel);

        List<BIndex> expectedBil = mockList(BIndex.class);
        when(bIndexMapper.map(biel)).thenReturn(expectedBil);

        ZonedDateTime ffn = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nfn = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");

        List<BIndex> bil = bIndexReaderRepository.listByPeriod(ffn, nfn);

        verify(tq, times(1)).setParameter("farthestFromNow", ffn);
        verify(tq, times(1)).setParameter("nearestFromNow", nfn);
        verify(bIndexMapper, times(1)).map(biel);
        assertNotNull(bil);
        assertSame(expectedBil, bil);
        assertEquals(0, bil.size());
    }

    @Test
    public void listByPeriod_called_returnsListOfBIndexFromPeriod() {

        TypedQuery<BIndexEntity> tq = mockTypedQuery(BIndexEntity.class);
        when(entityManager.createQuery(QUERY_LIST, BIndexEntity.class)).thenReturn(tq);

        List<BIndexEntity> biel = Arrays.asList(mock(BIndexEntity.class), mock(BIndexEntity.class));
        when(tq.getResultList()).thenReturn(biel);

        List<BIndex> expectedBil = Arrays.asList(mock(BIndex.class), mock(BIndex.class));
        when(bIndexMapper.map(biel)).thenReturn(expectedBil);

        ZonedDateTime ffn = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nfn = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");

        List<BIndex> bil = bIndexReaderRepository.listByPeriod(ffn, nfn);

        verify(tq, times(1)).setParameter("farthestFromNow", ffn);
        verify(tq, times(1)).setParameter("nearestFromNow", nfn);
        verify(bIndexMapper, times(1)).map(biel);
        assertNotNull(bil);
        assertSame(expectedBil, bil);
        assertEquals(2, bil.size());        
    }

}
