package br.inpe.climaespacial.swd.hello.factories;

import br.inpe.climaespacial.swd.hello.dtos.Hello;

import javax.inject.Inject;

import static org.hamcrest.CoreMatchers.instanceOf;

import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;

import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

@RunWith(CdiRunner.class)
@AdditionalClasses({DefaultHelloFactory.class, Hello.class})
public class HelloFactoryTest {

    @Inject
    private HelloFactory helloFactory;

    @Test
    public void create_called_returnsHello() {

        Hello h = helloFactory.create();

        assertNotNull(h);
        assertThat(h, instanceOf(Hello.class));
    }
}
