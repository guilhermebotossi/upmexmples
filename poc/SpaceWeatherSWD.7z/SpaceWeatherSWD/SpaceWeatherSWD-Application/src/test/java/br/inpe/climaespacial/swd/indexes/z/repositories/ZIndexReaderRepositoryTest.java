package br.inpe.climaespacial.swd.indexes.z.repositories;

import br.inpe.climaespacial.swd.commons.EmbraceMockito;
import static br.inpe.climaespacial.swd.commons.EmbraceMockito.mockList;
import static br.inpe.climaespacial.swd.commons.EmbraceMockito.mockTypedQuery;
import br.inpe.climaespacial.swd.indexes.z.dtos.ZIndex;
import br.inpe.climaespacial.swd.indexes.z.entities.ZIndexEntity;
import br.inpe.climaespacial.swd.indexes.z.mappers.ZIndexMapper;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.List;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(CdiRunner.class)
@AdditionalClasses(DefaultZIndexReaderRepository.class)
public class ZIndexReaderRepositoryTest {

    private static final String QUERY = "SELECT MAX(zie.timeTag) FROM ZIndexEntity zie";

    private static final String QUERY_LIST = "SELECT zie FROM ZIndexEntity zie WHERE zie.timeTag BETWEEN :farthestFromNow AND :nearestFromNow ORDER BY zie.timeTag";

    @Produces
    @Mock
    private EntityManager entityManager;

    @Inject
    private ZIndexReaderRepository zIndexReaderRepository;

    @Produces
    @Mock
    private ZIndexMapper zIndexMapper;

    @Test
    public void getLastCalculatedHour_called_returnsNull() {

        TypedQuery<ZonedDateTime> tq = EmbraceMockito.mockTypedQuery(ZonedDateTime.class);
        when(entityManager.createQuery(QUERY, ZonedDateTime.class)).thenReturn(tq);

        ZonedDateTime zdt = null;
        List<ZonedDateTime> zdtl = Arrays.asList(zdt);
        when(tq.getResultList()).thenReturn(zdtl);

        ZonedDateTime lch = zIndexReaderRepository.getNextHourToBeCalculated();

        assertNull(lch);
    }

    @Test
    public void getLastCalculatedHour_called_returnsLastTimeTag() {

        TypedQuery<ZonedDateTime> tq = EmbraceMockito.mockTypedQuery(ZonedDateTime.class);
        when(entityManager.createQuery(QUERY, ZonedDateTime.class)).thenReturn(tq);

        ZonedDateTime zdt = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        List<ZonedDateTime> zdtl = Arrays.asList(zdt);
        when(tq.getResultList()).thenReturn(zdtl);

        ZonedDateTime lch = zIndexReaderRepository.getNextHourToBeCalculated();

        assertNotNull(lch);
        assertEquals(zdt.plusHours(1), lch);
    }

    @Test
    public void listByPeriod_called_returnsListEmpty() {

        TypedQuery<ZIndexEntity> tq = mockTypedQuery(ZIndexEntity.class);
        when(entityManager.createQuery(QUERY_LIST, ZIndexEntity.class)).thenReturn(tq);

        List<ZIndexEntity> ziel = mockList(ZIndexEntity.class);
        when(tq.getResultList()).thenReturn(ziel);

        List<ZIndex> expectedZil = mockList(ZIndex.class);
        when(zIndexMapper.map(ziel)).thenReturn(expectedZil);

        ZonedDateTime ffn = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nfn = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");

        List<ZIndex> zil = zIndexReaderRepository.listByPeriod(ffn, nfn);

        verify(tq, times(1)).setParameter("farthestFromNow", ffn);
        verify(tq, times(1)).setParameter("nearestFromNow", nfn);
        verify(zIndexMapper, times(1)).map(ziel);
        assertNotNull(zil);
        assertSame(expectedZil, zil);
        assertEquals(0, zil.size());
    }

    @Test
    public void listByPeriod_called_returnsListOfCIndexFromPeriod() {

        TypedQuery<ZIndexEntity> tq = mockTypedQuery(ZIndexEntity.class);
        when(entityManager.createQuery(QUERY_LIST, ZIndexEntity.class)).thenReturn(tq);

        List<ZIndexEntity> ziel = Arrays.asList(mock(ZIndexEntity.class), mock(ZIndexEntity.class));
        when(tq.getResultList()).thenReturn(ziel);

        List<ZIndex> expectedZil = Arrays.asList(mock(ZIndex.class), mock(ZIndex.class));
        when(zIndexMapper.map(ziel)).thenReturn(expectedZil);

        ZonedDateTime ffn = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nfn = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");

        List<ZIndex> zil = zIndexReaderRepository.listByPeriod(ffn, nfn);

        verify(tq, times(1)).setParameter("farthestFromNow", ffn);
        verify(tq, times(1)).setParameter("nearestFromNow", nfn);
        verify(zIndexMapper, times(1)).map(ziel);
        assertNotNull(zil);
        assertSame(expectedZil, zil);
        assertEquals(2, zil.size());
    }

}
