package br.inpe.climaespacial.swd.indexes.b.factories;

import br.inpe.climaespacial.swd.average.dtos.HourlyAverage;
import javax.inject.Inject;
import static org.hamcrest.CoreMatchers.instanceOf;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(CdiRunner.class)
@AdditionalClasses(DefaultHourlyAverageFactory.class)
public class HourlyAverageFactoryTest {

    @Inject
    private HourlyAverageFactory hourlyAverageFactory;

    @Test
    public void create_called_returnsInstance() {
        HourlyAverage ha = hourlyAverageFactory.create();

        assertNotNull(ha);
        assertThat(ha, instanceOf(HourlyAverage.class));
    }
}
