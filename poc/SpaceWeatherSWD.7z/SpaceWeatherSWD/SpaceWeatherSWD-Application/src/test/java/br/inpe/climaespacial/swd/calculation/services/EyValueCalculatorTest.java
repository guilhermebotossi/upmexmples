package br.inpe.climaespacial.swd.calculation.services;

import br.inpe.climaespacial.swd.calculation.TestHelper;
import br.inpe.climaespacial.swd.calculation.dtos.MagPlasma;
import org.jglue.cdiunit.AdditionalClasses;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;

@RunWith(Theories.class)
@AdditionalClasses(DefaultEyValueCalculator.class)
public class EyValueCalculatorTest {

	private EyValueCalculator eyValueCalculator;

	@DataPoints
	public static String[][] pairs = TestHelper.getPairs();

	@Before
	public void beforeTest() {
		eyValueCalculator = new DefaultEyValueCalculator();
	}

	@Test
	public void calculate_calledWithNullArgument_throws() {
		RuntimeException re = null;

		try {
			eyValueCalculator.calculate(null);
		} catch (RuntimeException e) {
			re = e;
		}

		assertNotNull(re);
		assertEquals("Parâmetro \"magPlasma\" null/empty.", re.getMessage());
	}
	
	@Test
	public void calculate_withSpeedNull_returnsNull() {
		MagPlasma mp = new MagPlasma();
		mp.setSpeed(null);
		mp.setBzGsm(1D);
		
		Double calculate = eyValueCalculator.calculate(mp);
		
		assertNull(calculate);
	}
	
	@Test
	public void calculate_withBzGsmNull_returnsNull() {
		MagPlasma mp = new MagPlasma();
		mp.setSpeed(2D);
		mp.setBzGsm(null);
		
		Double calculate = eyValueCalculator.calculate(mp);
		
		assertNull(calculate);
	}

	@Theory
	public void calculate_calledWithValidArgument_succeeds(String[] data) {
		MagPlasma mp = new MagPlasma();
		mp.setSpeed(Double.valueOf(data[7]).doubleValue());
		mp.setBzGsm(Double.valueOf(data[4]).doubleValue());

		double ey = eyValueCalculator.calculate(mp);

		assertEquals(Double.valueOf(data[8]).doubleValue(), ey, 0.00);
	}
}