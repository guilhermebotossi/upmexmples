package br.inpe.climaespacial.swd.commons.interceptors;

public interface ThrowableSubject {

    String throwsWhenCalled();

}
