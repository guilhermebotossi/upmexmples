package br.inpe.climaespacial.swd.acquisition.home;

import java.time.ZonedDateTime;
import javax.inject.Inject;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(CdiRunner.class)
@AdditionalClasses(DefaultIntervalValidator.class)
public class IntervalValidatorTest {
    
    private static final int PERIOD_SIZE = 31;
    
    @Inject
    private IntervalValidator intervalValidator;

    @Test
    public void validate_calledWithFarthestFromNowNull_throws() {
        RuntimeException re = null;

        ZonedDateTime farthestFromNow = null;
        ZonedDateTime nearestFromNow = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");

        try {
            intervalValidator.validate(farthestFromNow, nearestFromNow, PERIOD_SIZE);
        } catch (RuntimeException r) {
            re = r;
        }

        assertNotNull(re);
        assertEquals("Parametro \"farthestFromNow\" null", re.getMessage());
    }    
    
    @Test
    public void validate_calledWithNearestFromNowNull_throws() {
        RuntimeException re = null;

        ZonedDateTime farthestFromNow = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nearestFromNow = null;

        try {
            intervalValidator.validate(farthestFromNow, nearestFromNow, PERIOD_SIZE);
        } catch (RuntimeException r) {
            re = r;
        }

        assertNotNull(re);
        assertEquals("Parametro \"nearestFromNow\" null", re.getMessage());
    }
    
    @Test
    public void validate_calledWithFarthestFromNowAfterThanNearestFromNowNull_throws() {
        RuntimeException re = null;

        ZonedDateTime farthestFromNow = ZonedDateTime.parse("2017-01-02T12:00:00z[UTC]");
        ZonedDateTime nearestFromNow = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");

        try {
            intervalValidator.validate(farthestFromNow, nearestFromNow, PERIOD_SIZE);
        } catch (RuntimeException r) {
            re = r;
        }

        assertNotNull(re);        
        assertEquals("Parametro \"farthestFromNow\" cannot be after than \"nearestFromNow\"", re.getMessage());
    }
    
    @Test
    public void validate_calledWithPeriodSizeOverLimit_throws() {
        RuntimeException re = null;

        ZonedDateTime farthestFromNow = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nearestFromNow = ZonedDateTime.parse("2017-03-01T12:00:00z[UTC]");

        try {
            intervalValidator.validate(farthestFromNow, nearestFromNow, PERIOD_SIZE);
        } catch (RuntimeException r) {
            re = r;
        }

        assertNotNull(re);        
        assertEquals("Period size exceeded", re.getMessage());
    }

}
