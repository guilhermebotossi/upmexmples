package br.inpe.climaespacial.swd.acquisition.mappers;

import br.inpe.climaespacial.swd.acquisition.dtos.Mag;
import br.inpe.climaespacial.swd.acquisition.factories.MagFactory;
import br.inpe.climaespacial.swd.commons.factories.ListFactory;
import br.inpe.climaespacial.swd.commons.mappers.DateTimeMapper;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(CdiRunner.class)
@AdditionalClasses({
    DefaultMagMapper.class
})
public class MagMapperTest {

    private static final String PARAMETRO_CONTENT_NULL_EMPTY = "Parâmetro \"content\" null/empty.";

    private String json = "[[\"time_tag\",\"bx_gsm\",\"by_gsm\",\"bz_gsm\",\"lon_gsm\",\"lat_gsm\",\"bt\"],[\"2017-03-08 13:02:00.000\",\"4.31\",\"-3.52\",\"-0.60\",\"320.74\",\"-6.15\",\"5.61\"],[\"2017-03-08 13:03:00.000\",\"4.35\",\"-3.50\",\"-0.38\",\"321.19\",\"-3.88\",\"5.60\"]]";

    private String jsonContainingNulls = "[[\"time_tag\",\"bx_gsm\",\"by_gsm\",\"bz_gsm\",\"lon_gsm\",\"lat_gsm\",\"bt\"],[\"2017-03-08 13:02:00.000\",\"4.31\",\"-3.52\",\"-0.60\",null,null,\"5.61\"],[\"2017-03-08 13:03:00.000\",\"4.35\",\"-3.50\",\"-0.38\",\"321.19\",null,\"5.60\"]]";

    @Produces
    @Mock
    private ListFactory<Mag> magListFactory;

    @Produces
    @Mock
    private DateTimeMapper dateTimeMapper;

    @Produces
    @Mock
    private MagFactory magFactory;

    @Inject
    private MagMapper magMapper;

    private double delta = 0.001;

    @Test
    public void map_calledWithNullString_throws() {
        RuntimeException re = null;

        try {
            magMapper.map(null);
        } catch (RuntimeException e) {
            re = e;
        }

        assertNotNull(re);
        assertEquals(PARAMETRO_CONTENT_NULL_EMPTY, re.getMessage());
    }

    @Test
    public void map_calledWithAnEmptyString_throws() {
        RuntimeException re = null;

        try {
            magMapper.map("");
        } catch (RuntimeException e) {
            re = e;
        }

        assertNotNull(re);
        assertEquals(PARAMETRO_CONTENT_NULL_EMPTY, re.getMessage());
    }

    @Test
    public void map_calledWithInvalidFormatContent_throws() {
        RuntimeException re = null;

        try {
            magMapper.map("aaaaaa;5555");
        } catch (RuntimeException e) {
            re = e;
        }

        assertNotNull(re);
        assertEquals("Parametro \"content\" formato invalido", re.getMessage());
    }

    @Test
    public void map_calledWithValidArguments_succeeds() {
        when(magListFactory.create()).thenReturn(new ArrayList<>());

        ZonedDateTime tt = ZonedDateTime.parse("2017-03-08T13:02Z[UTC]");

        String dt = "2017-03-08 13:02:00.000";

        when(magFactory.create()).thenAnswer(a -> new Mag());
        when(dateTimeMapper.map(dt)).thenReturn(tt);

        List<Mag> ml = magMapper.map(json);
        assertNotNull(ml);
        assertEquals(2, ml.size());

        Mag m = ml.get(0);

        verify(magListFactory, times(1)).create();
        verify(dateTimeMapper, times(1)).map(dt);

        assertEquals(tt, m.getTimeTag());
        assertEquals(4.31, m.getBxGsm(), delta);
        assertEquals(-3.52, m.getByGsm(), delta);
        assertEquals(-0.60, m.getBzGsm(), delta);
        assertEquals(320.74, m.getLonGsm(), delta);
        assertEquals(-6.15, m.getLatGsm(), delta);
        assertEquals(5.61, m.getBt(), delta);
    }

    @Test
    public void map_calledWithValidArgumentsContainingNullLatLong_succeeds() {
        when(magListFactory.create()).thenReturn(new ArrayList<>());

        ZonedDateTime tt = ZonedDateTime.parse("2017-03-08T13:02Z[UTC]");

        String dt = "2017-03-08 13:02:00.000";

        when(magFactory.create()).thenAnswer(a -> new Mag());
        when(dateTimeMapper.map(dt)).thenReturn(tt);

        List<Mag> ml = magMapper.map(jsonContainingNulls);
        assertNotNull(ml);
        assertEquals(2, ml.size());

        Mag m = ml.get(0);

        verify(magListFactory, times(1)).create();
        verify(dateTimeMapper, times(1)).map(dt);
        verify(magFactory, times(2)).create();

        assertEquals(tt, m.getTimeTag());
        assertEquals(4.31, m.getBxGsm(), delta);
        assertEquals(-3.52, m.getByGsm(), delta);
        assertEquals(-0.60, m.getBzGsm(), delta);
        assertNull(m.getLonGsm());
        assertNull(m.getLatGsm());
        assertEquals(5.61, m.getBt(), delta);
    }
}
