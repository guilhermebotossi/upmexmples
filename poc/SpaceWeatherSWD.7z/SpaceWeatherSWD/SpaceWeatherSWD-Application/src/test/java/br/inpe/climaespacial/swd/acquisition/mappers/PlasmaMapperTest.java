package br.inpe.climaespacial.swd.acquisition.mappers;

import br.inpe.climaespacial.swd.acquisition.dtos.Plasma;
import br.inpe.climaespacial.swd.acquisition.factories.PlasmaFactory;
import br.inpe.climaespacial.swd.commons.mappers.DateTimeMapper;
import java.time.ZonedDateTime;
import java.util.List;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(CdiRunner.class)
@AdditionalClasses(DefaultPlasmaMapper.class)
public class PlasmaMapperTest {

	private static final String PARÂMETRO_CONTENT_NULL_EMPTY = "Parâmetro \"content\" null/empty.";

	private static final String JSON_FINE = "[[\"time_tag\",\"density\",\"speed\",\"temperature\"],[\"2017-03-08 13:02:00.000\",\"5.44\",\"528.5\",\"246572\"],[\"2017-03-08 13:03:00.000\",\"5.49\",\"529.3\",\"246319\"]]";

	@Produces
	@Mock
	private DateTimeMapper dateTimeMapper;

	@Inject
	private PlasmaMapper plasmaMapper;
        
        @Produces
	@Mock
        private PlasmaFactory plasmaFactory;

	@Test
	public void map_calledWithNullString_throws() {
		RuntimeException re = null;

		try {
			plasmaMapper.map(null);
		} catch (RuntimeException e) {
			re = e;
		}

		assertNotNull(re);
		assertEquals(PARÂMETRO_CONTENT_NULL_EMPTY, re.getMessage());
	}

	@Test
	public void map_calledWithEmptyString_throws() {
		RuntimeException re = null;

		try {
			plasmaMapper.map("");
		} catch (RuntimeException e) {
			re = e;
		}

		assertNotNull(re);
		assertEquals(PARÂMETRO_CONTENT_NULL_EMPTY, re.getMessage());
	}

	@Test
	public void map_calledWithInvalidFormatArgument_throws() {
		RuntimeException re = null;

		try {
			plasmaMapper.map("ajdfdnad;555");
		} catch (RuntimeException e) {
			re = e;
		}

		assertNotNull(re);
		assertEquals("Parametro \"content\" formato invalido", re.getMessage());
	}

	@Test
	public void map_calledWithValidFormatArgument_succeeds() {
		ZonedDateTime tt = ZonedDateTime.parse("2017-03-08T13:02Z[UTC]");

		String dt = "2017-03-08 13:02:00.000";
                
                when(plasmaFactory.create()).thenAnswer(a -> new Plasma());
		when(dateTimeMapper.map(dt)).thenReturn(tt);

		List<Plasma> pl = plasmaMapper.map(JSON_FINE);

		verify(dateTimeMapper, times(1)).map(dt);
                verify(plasmaFactory, times(2)).create();
		
		assertNotNull(pl);
		assertEquals(2, pl.size());

		Plasma p = pl.get(0);

		assertEquals(p.getTimeTag(), tt);
		double delta = 0.001;
		assertEquals(5.44, p.getDensity(), delta);
		assertEquals(528.5, p.getSpeed(), delta);
		assertEquals(246572, p.getTemperature(), delta);
	}
}