package br.inpe.climaespacial.swd.indexes.z.services;

import br.inpe.climaespacial.swd.average.dtos.HourlyAverage;
import br.inpe.climaespacial.swd.calculation.TestHelper;
import br.inpe.climaespacial.swd.indexes.z.dtos.ZIndex;
import java.time.ZonedDateTime;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;

@RunWith(Theories.class)
public class ZIndexCalculatorTest {

    private ZIndexCalculator zIndexCalculator;

    @DataPoints
    public static Object[] data = TestHelper.getDataEvery3Hours();

    @Before
    public void before() {
        zIndexCalculator = new DefaultZIndexCalculator();
    }

    @Test
    public void calculate_calledWithNullArgument_throws() {
        RuntimeException re = null;

        try {
            zIndexCalculator.calculate(null);
        } catch (RuntimeException e) {
            re = e;
        }

        assertNotNull(re);
        assertEquals("Parametro \"hourlyAverageList\" null/empty.", re.getMessage());
    }

    @Test
    public void calculate_calledWithEmptyList_throws() {
        List<HourlyAverage> hal = new ArrayList<>();
        RuntimeException re = null;
        try {
            zIndexCalculator.calculate(hal);
        } catch (RuntimeException e) {
            re = e;
        }

        assertNotNull(re);
        assertEquals("Parametro \"hourlyAverageList\" null/empty.", re.getMessage());
    }

    @Test
    public void calculate_calledWithValidArgumentButNullTimeTag_throws() {
        List<HourlyAverage> hal = new ArrayList<>();
        hal.add(new HourlyAverage());
        RuntimeException re = null;
        try {
            zIndexCalculator.calculate(hal);
        } catch (RuntimeException e) {
            re = e;
        }

        assertNotNull(re);
        assertEquals("Propriedade \"hourlyAverage.timeTag\" null.", re.getMessage());
    }

    @Test
    public void calculate_calledWithValidArgumentButNullBt_succeds() {
        List<HourlyAverage> hal = new ArrayList<>();
        HourlyAverage ha = new HourlyAverage();
        ZonedDateTime now = ZonedDateTime.now();
        ha.setTimeTag(now);
        ha.setBzGsm(null);
        hal.add(ha);

        ZIndex zIndex = zIndexCalculator.calculate(hal);

        assertNotNull(zIndex);
        assertNotNull(zIndex.getTimeTag());
        assertEquals(now, zIndex.getTimeTag());
        assertNull(zIndex.getPreValue());
        assertNull(zIndex.getPostValue());
    }

    @Theory
    public void calculate_calledWithValidArgument_succeds(SimpleEntry<List<HourlyAverage>, String[]> se) {
        List<HourlyAverage> hal = se.getKey();
        String[] v = se.getValue();
        ZonedDateTime timeTag = getTimeTag(hal);

        ZIndex zIndex = zIndexCalculator.calculate(hal);

        Double pre_bz = toDoubleIfNotNull(v[3]);
        Double pos_bz = toDoubleIfNotNull(v[4]);

        assertNotNull(zIndex);
        assertNotNull(zIndex.getTimeTag());
        assertEquals(timeTag, zIndex.getTimeTag());
        assertEquals(pre_bz, zIndex.getPreValue(), 0.01);
        assertEquals(pos_bz, zIndex.getPostValue(), 0.01);
    }

    private ZonedDateTime getTimeTag(List<HourlyAverage> hourlyAverageList) {
        int size = hourlyAverageList.size();

        return hourlyAverageList.get(size - 1).getTimeTag();
    }

    private Double toDoubleIfNotNull(String value) {
        return value != null ? Double.valueOf(value) : null;
    }
}
