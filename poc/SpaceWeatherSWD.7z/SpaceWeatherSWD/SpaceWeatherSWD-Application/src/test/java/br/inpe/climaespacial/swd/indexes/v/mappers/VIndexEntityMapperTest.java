package br.inpe.climaespacial.swd.indexes.v.mappers;

import br.inpe.climaespacial.swd.indexes.v.dtos.VIndex;
import br.inpe.climaespacial.swd.indexes.v.entities.VIndexEntity;
import br.inpe.climaespacial.swd.indexes.v.factories.VIndexEntityFactory;
import java.time.ZonedDateTime;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import static org.mockito.Mockito.when;

@RunWith(CdiRunner.class)
@AdditionalClasses({DefaultVIndexEntityMapper.class})
public class VIndexEntityMapperTest {
	
	@Mock
	@Produces
	private VIndexEntityFactory vIndexEntityFactory;
	
	@Inject
	private VIndexEntityMapper vIndexEntityMapper;
	
    @Test
    public void map_calledWithNullArgument_throwsRuntimeException() {
    	RuntimeException re = null;
    	
    	try {
    		vIndexEntityMapper.map(null);
    	} catch(RuntimeException e) {
    		re = e; 
    	} 
    	 
    	assertNotNull(re);
        assertEquals("Parâmetro \"vIndex\" null/empty.", re.getMessage());
    }

    
    @Test
    public void map_called_returnsCIndex() {
    	VIndex vi = new VIndex();
    	ZonedDateTime timeTag = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
    	vi.setTimeTag(timeTag);
    	vi.setValue(5.0);
    	VIndexEntity cie1 = new VIndexEntity();
    	
    	when(vIndexEntityFactory.create()).thenReturn(cie1);
    	
    	VIndexEntity cie2 = vIndexEntityMapper.map(vi); 
    	
    	assertNotNull(cie2);
    	assertEquals(vi.getTimeTag(), cie2.getTimeTag());
    	assertEquals(vi.getValue(), cie2.getValue());
    	
    	
    }
}
