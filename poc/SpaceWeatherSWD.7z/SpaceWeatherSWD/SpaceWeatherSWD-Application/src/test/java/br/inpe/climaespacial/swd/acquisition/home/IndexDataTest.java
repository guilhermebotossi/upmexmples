package br.inpe.climaespacial.swd.acquisition.home;

import static br.inpe.climaespacial.swd.commons.EmbraceMockito.mockList;
import java.util.List;
import javax.inject.Inject;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import static org.junit.Assert.assertSame;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(CdiRunner.class)
@AdditionalClasses(IndexData.class)
public class IndexDataTest {

    @Inject
    private IndexData indexData;

    @Test
    public void bEntrysTest() {
        List<IndexEntry> iel = mockList(IndexEntry.class);

        indexData.setbEntrys(iel);

        assertSame(iel, indexData.getbEntrys());
    }

    @Test
    public void cEntrysTest() {
        List<IndexEntry> iel = mockList(IndexEntry.class);

        indexData.setcEntrys(iel);

        assertSame(iel, indexData.getcEntrys());
    }

    @Test
    public void vEntrysTest() {
        List<IndexEntry> iel = mockList(IndexEntry.class);

        indexData.setvEntrys(iel);

        assertSame(iel, indexData.getvEntrys());
    }

    @Test
    public void zEntrysTest() {
        List<IndexEntry> iel = mockList(IndexEntry.class);

        indexData.setzEntrys(iel);

        assertSame(iel, indexData.getzEntrys());
    }

}
