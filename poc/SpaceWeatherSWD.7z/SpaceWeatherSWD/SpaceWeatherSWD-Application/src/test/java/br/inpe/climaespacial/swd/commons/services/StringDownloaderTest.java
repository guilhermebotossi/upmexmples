package br.inpe.climaespacial.swd.commons.services;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.io.IOException;

import javax.enterprise.inject.Produces;
import javax.inject.Inject;

import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;

import br.inpe.climaespacial.swd.commons.Downloader;
import br.inpe.climaespacial.swd.commons.StringDownloader;
import br.inpe.climaespacial.swd.commons.adapters.DownloadAdapter;

@RunWith(CdiRunner.class)
@AdditionalClasses(StringDownloader.class)
public class StringDownloaderTest {

	@Produces
	@Mock
	private DownloadAdapter downloadAdapter;

	@Inject
	private Downloader download;

	@Test
	public void download_whenfail_throws() throws IOException {
		IOException expectedre = new IOException();

		doThrow(expectedre).when(downloadAdapter).download(any(String.class));

		RuntimeException re = null;
		try {
			download.download("teste");
		} catch (RuntimeException e) {
			re = e;
		}
		assertNotNull(re);
		assertEquals("Erro ao efetuar download.", re.getMessage());
	}

	@Test
	public void download_calledwithvalidurl_succeeds() throws IOException {
		String value = "teste";

		when(downloadAdapter.download(any(String.class))).thenReturn(value);

		String actual = download.download(value);

		assertNotNull(actual);
		assertEquals(value, actual);
	}
}
