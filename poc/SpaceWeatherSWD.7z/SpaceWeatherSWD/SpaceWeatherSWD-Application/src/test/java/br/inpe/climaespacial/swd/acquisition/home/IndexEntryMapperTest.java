package br.inpe.climaespacial.swd.acquisition.home;

import br.inpe.climaespacial.swd.commons.factories.ListFactory;
import br.inpe.climaespacial.swd.indexes.b.dtos.BIndex;
import br.inpe.climaespacial.swd.indexes.c.dtos.CIndex;
import br.inpe.climaespacial.swd.indexes.v.dtos.VIndex;
import br.inpe.climaespacial.swd.indexes.z.dtos.ZIndex;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import static org.mockito.Mockito.when;

@RunWith(CdiRunner.class)
@AdditionalClasses({
    DefaultIndexEntryMapper.class
})
public class IndexEntryMapperTest {
    
    private static final double DELTA = 0.001;

    private static final double VALUE = 1.0;

    @Produces
    @Mock
    private ListFactory<IndexEntry> indexEntryListFactory; 
    
    @Produces
    @Mock
    private IndexEntryFactory indexEntryFactory;
    
    @Inject
    private IndexEntryMapper indexEntryMapper;

    @Test
    public void mapB_called_returnIndexEntryListOfB() {                
        
        ZonedDateTime timeTag = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        
        BIndex bi1 = new BIndex();        
        bi1.setTimeTag(timeTag);
        bi1.setPostValue(VALUE);
        
        BIndex bi2 = new BIndex();
        bi2.setTimeTag(timeTag);
        bi2.setPostValue(VALUE);
        
        when(indexEntryListFactory.create()).thenReturn(new ArrayList<>());
        when(indexEntryFactory.create()).thenReturn(new IndexEntry());
        
        List<BIndex> bIndexList = Arrays.asList(bi1, bi2);        
        
        List<IndexEntry> biel = indexEntryMapper.mapB(bIndexList);
        
        assertNotNull(biel);
        assertEquals(2, biel.size());
        
        IndexEntry ie1 = biel.get(0);
        assertEquals(bi1.getTimeTag(), ie1.getTimeTag());       
        assertEquals(bi1.getPostValue(), ie1.getValue(), DELTA);       
        
        IndexEntry ie2 = biel.get(1);
        assertEquals(bi2.getTimeTag(), ie2.getTimeTag());       
        assertEquals(bi2.getPostValue(), ie2.getValue(), DELTA);
    }
    
    @Test
    public void mapB_called_returnIndexEntryListOfC() {                
        
        ZonedDateTime timeTag = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        
        CIndex ci1 = new CIndex();        
        ci1.setTimeTag(timeTag);
        ci1.setPostValue(VALUE);
        
        CIndex ci2 = new CIndex();
        ci2.setTimeTag(timeTag);
        ci2.setPostValue(VALUE);
        
        when(indexEntryListFactory.create()).thenReturn(new ArrayList<>());
        when(indexEntryFactory.create()).thenReturn(new IndexEntry());
        
        List<CIndex> cIndexList = Arrays.asList(ci1, ci2);        
        
        List<IndexEntry> ciel = indexEntryMapper.mapC(cIndexList);
        
        assertNotNull(ciel);
        assertEquals(2, ciel.size());
        
        IndexEntry ie1 = ciel.get(0);
        assertEquals(ci1.getTimeTag(), ie1.getTimeTag());       
        assertEquals(ci1.getPostValue(), ie1.getValue(), DELTA);       
        
        IndexEntry ie2 = ciel.get(1);
        assertEquals(ci2.getTimeTag(), ie2.getTimeTag());       
        assertEquals(ci2.getPostValue(), ie2.getValue(), DELTA);
    }
    
    @Test
    public void mapB_called_returnIndexEntryListOfV() {                
        
        ZonedDateTime timeTag = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        
        VIndex vi1 = new VIndex();        
        vi1.setTimeTag(timeTag);
        vi1.setValue(VALUE);
        
        VIndex vi2 = new VIndex();
        vi2.setTimeTag(timeTag);
        vi2.setValue(VALUE);
        
        when(indexEntryListFactory.create()).thenReturn(new ArrayList<>());
        when(indexEntryFactory.create()).thenReturn(new IndexEntry());
        
        List<VIndex> vIndexList = Arrays.asList(vi1, vi2);        
        
        List<IndexEntry> viel = indexEntryMapper.mapV(vIndexList);
        
        assertNotNull(viel);
        assertEquals(2, viel.size());
        
        IndexEntry ie1 = viel.get(0);
        assertEquals(vi1.getTimeTag(), ie1.getTimeTag());       
        assertEquals(vi1.getValue(), ie1.getValue(), DELTA);       
        
        IndexEntry ie2 = viel.get(1);
        assertEquals(vi2.getTimeTag(), ie2.getTimeTag());       
        assertEquals(vi2.getValue(), ie2.getValue(), DELTA);
    }
    
    @Test
    public void mapB_called_returnIndexEntryListOfZ() {                
        
        ZonedDateTime timeTag = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        
        ZIndex zi1 = new ZIndex();        
        zi1.setTimeTag(timeTag);
        zi1.setPostValue(VALUE);
        
        ZIndex zi2 = new ZIndex();
        zi2.setTimeTag(timeTag);
        zi2.setPostValue(VALUE);
        
        when(indexEntryListFactory.create()).thenReturn(new ArrayList<>());
        when(indexEntryFactory.create()).thenReturn(new IndexEntry());
        
        List<ZIndex> zIndexList = Arrays.asList(zi1, zi2);        
        
        List<IndexEntry> ziel = indexEntryMapper.mapZ(zIndexList);
        
        assertNotNull(ziel);
        assertEquals(2, ziel.size());
        
        IndexEntry ie1 = ziel.get(0);
        assertEquals(zi1.getTimeTag(), ie1.getTimeTag());       
        assertEquals(zi1.getPostValue(), ie1.getValue(), DELTA);       
        
        IndexEntry ie2 = ziel.get(1);
        assertEquals(zi2.getTimeTag(), ie2.getTimeTag());       
        assertEquals(zi2.getPostValue(), ie2.getValue(), DELTA);
    }

}
