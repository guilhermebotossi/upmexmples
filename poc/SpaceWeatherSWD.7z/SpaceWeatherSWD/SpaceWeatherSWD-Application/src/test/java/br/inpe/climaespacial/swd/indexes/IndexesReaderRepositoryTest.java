package br.inpe.climaespacial.swd.indexes;

import static br.inpe.climaespacial.swd.commons.EmbraceMockito.mockTypedQuery;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;

import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

import org.mockito.Mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(CdiRunner.class)
@AdditionalClasses(DefaultIndexesReaderRepository.class)
public class IndexesReaderRepositoryTest {

    private static final String SQL = "SELECT NEW list(MAX(b.timeTag), "
            + "MAX(c.timeTag), MAX(v.timeTag), MAX(z.timeTag)) "
            + "FROM BIndexEntity b, CIndexEntity c, VIndexEntity v, ZIndexEntity z";

    @Produces
    @Mock
    private EntityManager entityManager;

    @Inject
    private IndexesReaderRepository indexesReaderRepository;

    @Test
    public void lastIndexesDate_called_returnLastAcquisitionDate() {

        ZonedDateTime la1 = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        List<ZonedDateTime> zdtl = Arrays.asList(la1);
        
        TypedQuery<List> tq = mockTypedQuery(List.class);
        when(tq.getSingleResult()).thenReturn(zdtl);
        when(entityManager.createQuery(SQL, List.class)).thenReturn(tq);
        
        
        ZonedDateTime la = indexesReaderRepository.lastIndexesDate();

        assertNotNull(la);
        assertSame(zdtl.get(0), la);
        verify(entityManager).createQuery(SQL, List.class);
        verify(tq).getSingleResult();
    }

    @Test
    public void lastIndexesDate_called_returnsNull() {
        List<ZonedDateTime> zdtl = new ArrayList<>();
        zdtl.add(null);
        
        TypedQuery<List> tq = mockTypedQuery(List.class);
        when(tq.getSingleResult()).thenReturn(zdtl);
        when(entityManager.createQuery(SQL, List.class)).thenReturn(tq);

        ZonedDateTime la = indexesReaderRepository.lastIndexesDate();

        assertNull(la);
        verify(entityManager).createQuery(SQL, List.class);
        verify(tq).getSingleResult();
    }

}
