package br.inpe.climaespacial.swd.calculation.services;

import br.inpe.climaespacial.swd.calculation.TestHelper;
import br.inpe.climaespacial.swd.calculation.dtos.MagPlasma;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;

@RunWith(Theories.class)
public class DprValueCalculatorTest {

    private DprValueCalculator dprValueCalculator;

    @Before
    public void beforeTest() {
        dprValueCalculator = new DefaultDprValueCalculator();
    }

    @DataPoints
    public static String[][] data = TestHelper.getPairs();

    @Test
    public void calculate_calledWithNullArgument_throws() {
        RuntimeException re = null;

        try {
            dprValueCalculator.calculate(null);
        } catch (RuntimeException e) {
            re = e;
        }

        assertNotNull(re);
        assertEquals("Parâmetro \"magPlasma\" null/empty.", re.getMessage());
    }
    
    @Test
    public void calculate_calledWithSpeedNull_returnsNull() {
    	MagPlasma mp = new MagPlasma();
    	mp.setSpeed(null);
    	mp.setDensity(3D);
    	
    	Double calculated = dprValueCalculator.calculate(mp);
    	
    	assertNull(calculated);
    }
    
    @Test
    public void calculate_calledWithDensityNull_returnsNull() {
    	MagPlasma mp = new MagPlasma();
    	mp.setSpeed(3D);
    	mp.setDensity(null);
    	
    	Double calculated = dprValueCalculator.calculate(mp);
    	
    	assertNull(calculated);
    }

    @Theory
    public void calculate_calledWithValidArgument_succeed(String[] data) {
        MagPlasma mpp = new MagPlasma();
        mpp.setSpeed(Double.valueOf(data[7]).doubleValue());
        mpp.setDensity(Double.valueOf(data[5]).doubleValue());

        double dpr = dprValueCalculator.calculate(mpp);

        assertEquals(Double.valueOf(data[9]).doubleValue(), dpr, 0.00);
    }
}
