
package br.inpe.climaespacial.swd.commons.interceptors;

public interface ThrowableSubjectAdapter {
    
    String foo();
    
}
