package br.inpe.climaespacial.swd.calculation.factories;

import javax.inject.Inject;
import static org.hamcrest.CoreMatchers.instanceOf;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import static org.junit.Assert.assertThat;
import org.junit.Test;
import org.junit.runner.RunWith;

import br.inpe.climaespacial.swd.calculation.dtos.MagPlasmaCalculated;

@RunWith(CdiRunner.class)
@AdditionalClasses({ DefaultMagPlasmaCalculatedFactory.class, MagPlasmaCalculated.class})
public class MagPlasmaCalculatedFactoryTest {
	
	@Inject
	MagPlasmaCalculatedFactory magPlasmaCalculatedFactory;	
	
	@Test
	public void create_called_returnsMagPlasmaCalculated(){
		MagPlasmaCalculated mpc = magPlasmaCalculatedFactory.create();
		
		assertThat(mpc, instanceOf(MagPlasmaCalculated.class));
	}

}
