package br.inpe.climaespacial.swd.indexes.v.repositories;

import br.inpe.climaespacial.swd.commons.EmbraceMockito;
import static br.inpe.climaespacial.swd.commons.EmbraceMockito.mockList;
import static br.inpe.climaespacial.swd.commons.EmbraceMockito.mockTypedQuery;
import br.inpe.climaespacial.swd.indexes.v.dtos.VIndex;
import br.inpe.climaespacial.swd.indexes.v.entities.VIndexEntity;
import br.inpe.climaespacial.swd.indexes.v.mappers.VIndexMapper;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.List;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(CdiRunner.class)
@AdditionalClasses(DefaultVIndexReaderRepository.class)
public class VIndexReaderRepositoryTest {

    private static final String QUERY = "SELECT MAX(vie.timeTag) FROM VIndexEntity vie";
    
    private static final String QUERY_LIST = "SELECT vie FROM VIndexEntity vie WHERE vie.timeTag BETWEEN :farthestFromNow AND :nearestFromNow ORDER BY vie.timeTag";

    @Produces
    @Mock
    private EntityManager entityManager;
    
    @Produces
    @Mock
    private VIndexMapper vIndexMapper;

    @Inject
    private VIndexReaderRepository vIndexReaderRepository;

    @Test
    public void getLastCalculatedHour_called_returnsNull() {

        TypedQuery<ZonedDateTime> tq = EmbraceMockito.mockTypedQuery(ZonedDateTime.class);
        when(entityManager.createQuery(QUERY, ZonedDateTime.class)).thenReturn(tq);
        
        ZonedDateTime zdt = null;        
        List<ZonedDateTime> zdtl = Arrays.asList(zdt); 
        when(tq.getResultList()).thenReturn(zdtl);

        ZonedDateTime lch = vIndexReaderRepository.getNextHourToBeCalculated();

        assertNull(lch);
    }

    @Test
    public void getLastCalculatedHour_called_returnsLastTimeTag() {
        
        TypedQuery<ZonedDateTime> tq = EmbraceMockito.mockTypedQuery(ZonedDateTime.class);
        when(entityManager.createQuery(QUERY, ZonedDateTime.class)).thenReturn(tq);
        
        ZonedDateTime zdt = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");        
        List<ZonedDateTime> zdtl = Arrays.asList(zdt);        
        when(tq.getResultList()).thenReturn(zdtl);        

        ZonedDateTime lch = vIndexReaderRepository.getNextHourToBeCalculated();

        assertNotNull(lch);
        assertEquals(zdt.plusHours(1), lch);
    }
    
      @Test
    public void listByPeriod_called_returnsListEmpty() {

        TypedQuery<VIndexEntity> tq = mockTypedQuery(VIndexEntity.class);
        when(entityManager.createQuery(QUERY_LIST, VIndexEntity.class)).thenReturn(tq);

        List<VIndexEntity> viel = mockList(VIndexEntity.class);
        when(tq.getResultList()).thenReturn(viel);

        List<VIndex> expectedVil = mockList(VIndex.class);
        when(vIndexMapper.map(viel)).thenReturn(expectedVil);

        ZonedDateTime ffn = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nfn = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");

        List<VIndex> vil = vIndexReaderRepository.listByPeriod(ffn, nfn);

        verify(tq, times(1)).setParameter("farthestFromNow", ffn);
        verify(tq, times(1)).setParameter("nearestFromNow", nfn);
        verify(vIndexMapper, times(1)).map(viel);
        assertNotNull(vil);
        assertSame(expectedVil, vil);
        assertEquals(0, vil.size());
    }

    @Test
    public void listByPeriod_called_returnsListOfVIndexFromPeriod() {

        TypedQuery<VIndexEntity> tq = mockTypedQuery(VIndexEntity.class);
        when(entityManager.createQuery(QUERY_LIST, VIndexEntity.class)).thenReturn(tq);

        List<VIndexEntity> viel = Arrays.asList(mock(VIndexEntity.class), mock(VIndexEntity.class));
        when(tq.getResultList()).thenReturn(viel);

        List<VIndex> expectedVil = Arrays.asList(mock(VIndex.class), mock(VIndex.class));
        when(vIndexMapper.map(viel)).thenReturn(expectedVil);

        ZonedDateTime ffn = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
        ZonedDateTime nfn = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");

        List<VIndex> vil = vIndexReaderRepository.listByPeriod(ffn, nfn);

        verify(tq, times(1)).setParameter("farthestFromNow", ffn);
        verify(tq, times(1)).setParameter("nearestFromNow", nfn);
        verify(vIndexMapper, times(1)).map(viel);
        assertNotNull(vil);
        assertSame(expectedVil, vil);
        assertEquals(2, vil.size());        
    }

}
