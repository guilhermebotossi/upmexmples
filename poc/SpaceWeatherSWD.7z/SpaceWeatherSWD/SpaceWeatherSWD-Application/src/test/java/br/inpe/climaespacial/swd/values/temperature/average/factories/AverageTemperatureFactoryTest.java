package br.inpe.climaespacial.swd.values.temperature.average.factories;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.ZonedDateTime;

import javax.inject.Inject;

import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import org.junit.Test;
import org.junit.runner.RunWith;

import br.inpe.climaespacial.swd.acquisition.home.FactoryProducer;
import br.inpe.climaespacial.swd.values.temperature.average.dtos.AverageTemperature;

@RunWith(CdiRunner.class)
@AdditionalClasses({FactoryProducer.class,
					DefaultAverageTemperatureFactory.class})
public class AverageTemperatureFactoryTest {
	
	@Inject
	private AverageTemperatureFactory AverageTemperatureFactory;
	
	@Test
	public void create_called_succeeds() {
		AverageTemperature AverageTemperature = AverageTemperatureFactory.create(ZonedDateTime.parse("2017-01-01T12:30:00z[UTC]"), 2.0); 
		assertNotNull(AverageTemperature);
		assertEquals(AverageTemperature.class, AverageTemperature.getClass());
		
		
	}

}
