package br.inpe.climaespacial.swd.commons.factories;

import br.inpe.climaespacial.swd.commons.entities.TestEntity;

public interface TestEntityFactory extends EntityFactory<TestEntity> {

}
