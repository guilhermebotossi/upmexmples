package br.inpe.climaespacial.swd.values.by.factories;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.ZonedDateTime;

import javax.inject.Inject;

import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import org.junit.Test;
import org.junit.runner.RunWith;

import br.inpe.climaespacial.swd.acquisition.home.FactoryProducer;
import br.inpe.climaespacial.swd.values.by.dtos.BY;

@RunWith(CdiRunner.class)
@AdditionalClasses({FactoryProducer.class,
					DefaultBYFactory.class})
public class BYFactoryTest {
	
	@Inject
	private BYFactory byFactory;
	
	@Test
	public void create_called_succeeds() {
		BY by = byFactory.create(ZonedDateTime.parse("2017-01-01T12:30:00z[UTC]"), 2.0); 
		assertNotNull(by);
		assertEquals(BY.class, by.getClass());
		
		
	}

}
