package br.inpe.climaespacial.swd.values.factories;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import org.junit.Test;
import org.junit.runner.RunWith;

import br.inpe.climaespacial.swd.acquisition.home.FactoryProducer;
import br.inpe.climaespacial.swd.values.dtos.ValueEntry;
import br.inpe.climaespacial.swd.values.dtos.ValuesData;
import br.inpe.climaespacial.swd.values.enums.ValuesEnum;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.*;
import static org.junit.Assert.*;

@RunWith(CdiRunner.class)
@AdditionalClasses({ FactoryProducer.class, DefaultValuesDataFactory.class })
public class ValuesDataFactoryTest {

	@Inject
	private ValuesDataFactory valuesDataFactory;

	@Test
	public void create_calledWithNull_throws() {
		RuntimeException re = null;
		try {
			valuesDataFactory.create(null);
		} catch (RuntimeException e) {
			re = e;
		}

		assertNotNull(re);
		assertEquals("Parametro \"valuesMap\" null/empty.", re.getMessage());
	}

	@Test
	public void create_calledWithEmptyMap_throws() {
		RuntimeException re = null;
		try {
			valuesDataFactory.create(new HashMap<ValuesEnum, List<ValueEntry>>());
		} catch (RuntimeException e) {
			re = e;
		}

		assertNotNull(re);
		assertEquals("Parametro \"valuesMap\" null/empty.", re.getMessage());
	}

	@Test
	public void create_calledWithPartialKeys_throws() {
		RuntimeException re = null;
		try {
			Map<ValuesEnum, List<ValueEntry>> map = new HashMap<ValuesEnum, List<ValueEntry>>();
			map.put(VALUE1, new ArrayList<ValueEntry>());
			map.put(VALUE2, new ArrayList<ValueEntry>());
			map.put(VALUE3, new ArrayList<ValueEntry>());
			valuesDataFactory.create(map);
		} catch (RuntimeException e) {
			re = e;
		}

		assertNotNull(re);
		assertEquals("Parametro \"valuesMap\" deve possuir todas as entradas do Enum ValuesEnum.", re.getMessage());
	}

	@Test
	public void create_calledWithAllKeysButNullValue_throws() {
		RuntimeException re = null;
		try {
			Map<ValuesEnum, List<ValueEntry>> map = new HashMap<ValuesEnum, List<ValueEntry>>();
			map.put(VALUE1, new ArrayList<ValueEntry>());
			map.put(VALUE2, new ArrayList<ValueEntry>());
			map.put(VALUE3, new ArrayList<ValueEntry>());
			map.put(VALUE4, new ArrayList<ValueEntry>());
			map.put(VALUE5, new ArrayList<ValueEntry>());
			map.put(VALUE6, new ArrayList<ValueEntry>());
			map.put(VALUE7, new ArrayList<ValueEntry>());
			map.put(VALUE8, new ArrayList<ValueEntry>());
			map.put(VALUE9, new ArrayList<ValueEntry>());
			map.put(VALUE1_AVERAGE, new ArrayList<ValueEntry>());
			map.put(VALUE2_AVERAGE, new ArrayList<ValueEntry>());
			map.put(VALUE3_AVERAGE, new ArrayList<ValueEntry>());
			map.put(VALUE4_AVERAGE, null);
			map.put(VALUE5_AVERAGE, new ArrayList<ValueEntry>());
			map.put(VALUE6_AVERAGE, new ArrayList<ValueEntry>());
			map.put(VALUE7_AVERAGE, new ArrayList<ValueEntry>());
			map.put(VALUE8_AVERAGE, new ArrayList<ValueEntry>());
			map.put(VALUE9_AVERAGE, new ArrayList<ValueEntry>());

			valuesDataFactory.create(map);
		} catch (RuntimeException e) {
			re = e;
		}

		assertNotNull(re);
		assertEquals("Parametro \"valuesMap[" + ValuesEnum.VALUE4_AVERAGE.toString() + "]\" inexistente ou null.",
				re.getMessage());
	}

	@Test
	public void create_calledWithAllKeys_throws() {
		Map<ValuesEnum, List<ValueEntry>> map = new HashMap<ValuesEnum, List<ValueEntry>>();
		map.put(VALUE1, new ArrayList<ValueEntry>());
		map.put(VALUE2, new ArrayList<ValueEntry>());
		map.put(VALUE3, new ArrayList<ValueEntry>());
		map.put(VALUE4, new ArrayList<ValueEntry>());
		map.put(VALUE5, new ArrayList<ValueEntry>());
		map.put(VALUE6, new ArrayList<ValueEntry>());
		map.put(VALUE7, new ArrayList<ValueEntry>());
		map.put(VALUE8, new ArrayList<ValueEntry>());
		map.put(VALUE9, new ArrayList<ValueEntry>());
		map.put(VALUE1_AVERAGE, new ArrayList<ValueEntry>());
		map.put(VALUE2_AVERAGE, new ArrayList<ValueEntry>());
		map.put(VALUE3_AVERAGE, new ArrayList<ValueEntry>());
		map.put(VALUE4_AVERAGE, new ArrayList<ValueEntry>());
		map.put(VALUE5_AVERAGE, new ArrayList<ValueEntry>());
		map.put(VALUE6_AVERAGE, new ArrayList<ValueEntry>());
		map.put(VALUE7_AVERAGE, new ArrayList<ValueEntry>());
		map.put(VALUE8_AVERAGE, new ArrayList<ValueEntry>());
		map.put(VALUE9_AVERAGE, new ArrayList<ValueEntry>());

		ValuesData vd = valuesDataFactory.create(map);
		
		assertNotNull(vd);
		
		assertNotNull(vd.getValue1List());
		assertSame(map.get(VALUE1), vd.getValue1List());
		assertNotNull(vd.getValue2List());
		assertSame(map.get(VALUE2), vd.getValue2List());
		assertNotNull(vd.getValue3List());
		assertSame(map.get(VALUE3), vd.getValue3List());
		assertNotNull(vd.getValue4List());
		assertSame(map.get(VALUE4), vd.getValue4List());
		assertNotNull(vd.getValue5List());
		assertSame(map.get(VALUE5), vd.getValue5List());
		assertNotNull(vd.getValue6List());
		assertSame(map.get(VALUE6), vd.getValue6List());
		assertNotNull(vd.getValue7List());
		assertSame(map.get(VALUE7), vd.getValue7List());
		assertNotNull(vd.getValue8List());
		assertSame(map.get(VALUE8), vd.getValue8List());
		assertNotNull(vd.getValue9List());
		assertSame(map.get(VALUE9), vd.getValue9List());
		
		
		assertNotNull(vd.getValue1AverageList());
		assertSame(map.get(VALUE1_AVERAGE), vd.getValue1AverageList());
		assertNotNull(vd.getValue2AverageList());
		assertSame(map.get(VALUE2_AVERAGE), vd.getValue2AverageList());
		assertNotNull(vd.getValue3AverageList());
		assertSame(map.get(VALUE3_AVERAGE), vd.getValue3AverageList());
		assertNotNull(vd.getValue4AverageList());
		assertSame(map.get(VALUE4_AVERAGE), vd.getValue4AverageList());
		assertNotNull(vd.getValue5AverageList());
		assertSame(map.get(VALUE5_AVERAGE), vd.getValue5AverageList());
		assertNotNull(vd.getValue6AverageList());
		assertSame(map.get(VALUE6_AVERAGE), vd.getValue6AverageList());
		assertNotNull(vd.getValue7AverageList());
		assertSame(map.get(VALUE7_AVERAGE), vd.getValue7AverageList());
		assertNotNull(vd.getValue8AverageList());
		assertSame(map.get(VALUE8_AVERAGE), vd.getValue8AverageList());
		assertNotNull(vd.getValue9AverageList());
		assertSame(map.get(VALUE9_AVERAGE), vd.getValue9AverageList());
		

	}
}
