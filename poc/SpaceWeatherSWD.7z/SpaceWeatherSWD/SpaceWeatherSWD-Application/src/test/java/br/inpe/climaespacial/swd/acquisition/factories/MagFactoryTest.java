
package br.inpe.climaespacial.swd.acquisition.factories;

import br.inpe.climaespacial.swd.acquisition.dtos.Mag;
import javax.inject.Inject;
import static org.hamcrest.CoreMatchers.instanceOf;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import static org.junit.Assert.assertThat;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(CdiRunner.class)
@AdditionalClasses({
    DefaultMagFactory.class, 
    Mag.class
})
public class MagFactoryTest {
    
    @Inject
    private MagFactory magFactory;
    
    @Test
    public void create_called_returnsMag() {        
        Mag m = magFactory.create();
        
        assertThat(m, instanceOf(Mag.class));        
    }

}
