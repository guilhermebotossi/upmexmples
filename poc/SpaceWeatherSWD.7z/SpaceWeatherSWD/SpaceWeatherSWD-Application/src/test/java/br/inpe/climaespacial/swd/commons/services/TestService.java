package br.inpe.climaespacial.swd.commons.services;

public interface TestService {

}
