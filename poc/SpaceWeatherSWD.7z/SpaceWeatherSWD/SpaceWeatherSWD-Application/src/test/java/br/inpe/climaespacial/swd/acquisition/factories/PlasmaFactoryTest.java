
package br.inpe.climaespacial.swd.acquisition.factories;

import br.inpe.climaespacial.swd.acquisition.dtos.Plasma;
import javax.inject.Inject;
import static org.hamcrest.CoreMatchers.instanceOf;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import static org.junit.Assert.assertThat;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(CdiRunner.class)
@AdditionalClasses({
    DefaultPlasmaFactory.class, 
    Plasma.class
})
public class PlasmaFactoryTest {
    
    @Inject
    private PlasmaFactory plasmaFactory;
    
    @Test
    public void create_called_returnsPlasma() {        
        Plasma p = plasmaFactory.create();
        
        assertThat(p, instanceOf(Plasma.class));        
    }

}
