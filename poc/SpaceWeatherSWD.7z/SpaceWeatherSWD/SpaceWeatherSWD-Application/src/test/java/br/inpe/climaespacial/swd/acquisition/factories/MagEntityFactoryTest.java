package br.inpe.climaespacial.swd.acquisition.factories;

import br.inpe.climaespacial.swd.acquisition.entities.MagEntity;
import br.inpe.climaespacial.swd.acquisition.providers.DateTimeProvider;
import br.inpe.climaespacial.swd.commons.providers.UUIDProvider;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import static org.hamcrest.CoreMatchers.instanceOf;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import static org.junit.Assert.assertThat;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;

@RunWith(CdiRunner.class)
@AdditionalClasses({DefaultMagEntityFactory.class, MagEntity.class})
public class MagEntityFactoryTest {

    @Produces
    @Mock
    private UUIDProvider uuidProvider;
    
    @Produces
    @Mock
    private DateTimeProvider dateTimeProvider;
    
    @Inject
    private MagEntityFactory magEntityFactory;
    
    @Test
    public void create_called_returnsMagEntity() {        
        MagEntity me = magEntityFactory.create();
        
        assertThat(me, instanceOf(MagEntity.class));
    }
}
