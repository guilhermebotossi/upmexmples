package br.inpe.climaespacial.swd.values.bx.factories;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.time.ZonedDateTime;

import javax.inject.Inject;

import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import org.junit.Test;
import org.junit.runner.RunWith;

import br.inpe.climaespacial.swd.acquisition.home.FactoryProducer;
import br.inpe.climaespacial.swd.values.bx.dtos.BX;

@RunWith(CdiRunner.class)
@AdditionalClasses({FactoryProducer.class,
					DefaultBXFactory.class})
public class BXFactoryTest {
	
	@Inject
	private BXFactory bxFactory;
	
	@Test
	public void create_called_succeeds() {
		BX bx = bxFactory.create(ZonedDateTime.parse("2017-01-01T12:30:00z[UTC]"), 2.0); 
		assertNotNull(bx);
		assertEquals(BX.class, bx.getClass());
		
		
	}

}
