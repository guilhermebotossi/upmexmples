package br.inpe.climaespacial.swd.acquisition.home;

import static br.inpe.climaespacial.swd.commons.EmbraceMockito.mockList;
import java.util.List;
import javax.inject.Inject;
import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(CdiRunner.class)
@AdditionalClasses({
    FactoryProducer.class,
    DefaultIndexDataFactory.class
})
public class IndexDataFactoryTest {

    @Inject
    private IndexDataFactory indexDataFactory;

    @Test
    public void create_called_returnsIndexData() {
        
        List<IndexEntry> bIndexEntryList = mockList(IndexEntry.class);
        List<IndexEntry> cIndexEntryList = mockList(IndexEntry.class);
        List<IndexEntry> vIndexEntryList = mockList(IndexEntry.class);
        List<IndexEntry> zIndexEntryList = mockList(IndexEntry.class);
        
        IndexData id = indexDataFactory.create(bIndexEntryList, cIndexEntryList, vIndexEntryList, zIndexEntryList);
        
        assertNotNull(id);
        assertEquals(IndexData.class, id.getClass());
        assertSame(bIndexEntryList, id.getbEntrys());
        assertSame(cIndexEntryList, id.getcEntrys());
        assertSame(vIndexEntryList, id.getvEntrys());
        assertSame(zIndexEntryList, id.getzEntrys());
    }       

}
