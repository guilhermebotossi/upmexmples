package br.inpe.climaespacial.swd.values.services;

import static br.inpe.climaespacial.swd.commons.EmbraceMockito.mockList;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.VALUE1;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.VALUE1_AVERAGE;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.VALUE2;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.VALUE2_AVERAGE;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.VALUE3;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.VALUE3_AVERAGE;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.VALUE4;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.VALUE4_AVERAGE;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.VALUE5;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.VALUE5_AVERAGE;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.VALUE6;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.VALUE6_AVERAGE;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.VALUE7;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.VALUE7_AVERAGE;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.VALUE8;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.VALUE8_AVERAGE;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.VALUE9;
import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.VALUE9_AVERAGE;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertSame;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.enterprise.inject.Produces;
import javax.inject.Inject;

import org.jglue.cdiunit.AdditionalClasses;
import org.jglue.cdiunit.CdiRunner;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;

import br.inpe.climaespacial.swd.acquisition.home.IntervalValidator;
import br.inpe.climaespacial.swd.values.bt.dtos.BT;
import br.inpe.climaespacial.swd.values.bt.repositories.BTRepository;
import br.inpe.climaespacial.swd.values.dtos.Value1Average;
import br.inpe.climaespacial.swd.values.dtos.Value2;
import br.inpe.climaespacial.swd.values.dtos.Value2Average;
import br.inpe.climaespacial.swd.values.dtos.Value3;
import br.inpe.climaespacial.swd.values.dtos.Value3Average;
import br.inpe.climaespacial.swd.values.dtos.Value4;
import br.inpe.climaespacial.swd.values.dtos.Value4Average;
import br.inpe.climaespacial.swd.values.dtos.Value5;
import br.inpe.climaespacial.swd.values.dtos.Value5Average;
import br.inpe.climaespacial.swd.values.dtos.Value6;
import br.inpe.climaespacial.swd.values.dtos.Value6Average;
import br.inpe.climaespacial.swd.values.dtos.Value7;
import br.inpe.climaespacial.swd.values.dtos.Value7Average;
import br.inpe.climaespacial.swd.values.dtos.Value8;
import br.inpe.climaespacial.swd.values.dtos.Value8Average;
import br.inpe.climaespacial.swd.values.dtos.Value9;
import br.inpe.climaespacial.swd.values.dtos.Value9Average;
import br.inpe.climaespacial.swd.values.dtos.ValueEntry;
import br.inpe.climaespacial.swd.values.dtos.ValuesData;
import br.inpe.climaespacial.swd.values.enums.ValuesEnum;
import br.inpe.climaespacial.swd.values.factories.ValuesDataFactory;
import br.inpe.climaespacial.swd.values.mappers.ValuesEntryMapper;
import br.inpe.climaespacial.swd.values.repositories.Value1AverageRepository;
import br.inpe.climaespacial.swd.values.repositories.Value2AverageRepository;
import br.inpe.climaespacial.swd.values.repositories.Value2Repository;
import br.inpe.climaespacial.swd.values.repositories.Value3AverageRepository;
import br.inpe.climaespacial.swd.values.repositories.Value3Repository;
import br.inpe.climaespacial.swd.values.repositories.Value4AverageRepository;
import br.inpe.climaespacial.swd.values.repositories.Value4Repository;
import br.inpe.climaespacial.swd.values.repositories.Value5AverageRepository;
import br.inpe.climaespacial.swd.values.repositories.Value5Repository;
import br.inpe.climaespacial.swd.values.repositories.Value6AverageRepository;
import br.inpe.climaespacial.swd.values.repositories.Value6Repository;
import br.inpe.climaespacial.swd.values.repositories.Value7AverageRepository;
import br.inpe.climaespacial.swd.values.repositories.Value7Repository;
import br.inpe.climaespacial.swd.values.repositories.Value8AverageRepository;
import br.inpe.climaespacial.swd.values.repositories.Value8Repository;
import br.inpe.climaespacial.swd.values.repositories.Value9AverageRepository;
import br.inpe.climaespacial.swd.values.repositories.Value9Repository;

@RunWith(CdiRunner.class)
@AdditionalClasses(DefaultValuesService.class)
public class ValuesServiceTest {
	
	private static final int MAX_NUMBER_OF_DAYS = 3;
	private final ZonedDateTime idt = ZonedDateTime.parse("2017-01-01T12:00:00z[UTC]");
	private final ZonedDateTime fdt = ZonedDateTime.parse("2017-01-03T12:00:00z[UTC]");
	
	@Mock
	@Produces
	private IntervalValidator intervalValidator;
	
	@Mock
	@Produces
	private BTRepository bTRepository;
	
	@Mock
	@Produces
	private Value1AverageRepository value1AverageRepository;
	
	@Mock
	@Produces
	private Value2Repository value2Repository;
	
	@Mock
	@Produces
	private Value2AverageRepository value2AverageRepository;
	
	@Mock
	@Produces
	private Value3Repository value3Repository;
	
	@Mock
	@Produces
	private Value3AverageRepository value3AverageRepository;
	
	@Mock
	@Produces
	private Value4Repository value4Repository;
	
	@Mock
	@Produces
	private Value4AverageRepository value4AverageRepository;
	
	@Mock
	@Produces
	private Value5Repository value5Repository;
	
	@Mock
	@Produces
	private Value5AverageRepository value5AverageRepository;
	
	@Mock
	@Produces
	private Value6Repository value6Repository;
	
	@Mock
	@Produces
	private Value6AverageRepository value6AverageRepository;
	
	@Mock
	@Produces
	private Value7Repository value7Repository;
	
	@Mock
	@Produces
	private Value7AverageRepository value7AverageRepository;
	
	@Mock
	@Produces
	private Value8Repository value8Repository;
	
	@Mock
	@Produces
	private Value8AverageRepository value8AverageRepository;
	
	@Mock
	@Produces
	private Value9Repository value9Repository;
	
	@Mock
	@Produces
	private Value9AverageRepository value9AverageRepository;
	
	@Mock
	@Produces
	private ValuesEntryMapper valuesEntryMapper; 
	
	@Mock
	@Produces
	private ValuesDataFactory valuesDataFactory;
	
	@Inject
	private ValuesService valuesService; 
	
	@Test
	public void getValuesData_called_succeeds() {
		List<BT> v1l = mockList(BT.class);
		when(bTRepository.list(idt, fdt)).thenReturn(v1l);
		List<ValueEntry> ve1l = mockList(ValueEntry.class);
		when(valuesEntryMapper.mapValue1(v1l)).thenReturn(ve1l);
		List<Value1Average> v1al = mockList(Value1Average.class);
		when(value1AverageRepository.list(idt, fdt)).thenReturn(v1al);
		List<ValueEntry> ve1al = mockList(ValueEntry.class);
		when(valuesEntryMapper.mapValue1Average(v1al)).thenReturn(ve1al);
		
		
		List<Value2> v2l = mockList(Value2.class);
		when(value2Repository.list(idt, fdt)).thenReturn(v2l);
		List<ValueEntry> ve2l = mockList(ValueEntry.class);
		when(valuesEntryMapper.mapValue2(v2l)).thenReturn(ve2l);
		List<Value2Average> v2al = mockList(Value2Average.class);
		when(value2AverageRepository.list(idt, fdt)).thenReturn(v2al);
		List<ValueEntry> ve2al = mockList(ValueEntry.class);
		when(valuesEntryMapper.mapValue2Average(v2al)).thenReturn(ve2al); 
		
		List<Value3> v3l = mockList(Value3.class);
		when(value3Repository.list(idt, fdt)).thenReturn(v3l);
		List<ValueEntry> ve3l = mockList(ValueEntry.class);
		when(valuesEntryMapper.mapValue3(v3l)).thenReturn(ve3l);
		List<Value3Average> v3al = mockList(Value3Average.class);
		when(value3AverageRepository.list(idt, fdt)).thenReturn(v3al);
		List<ValueEntry> ve3al = mockList(ValueEntry.class);
		when(valuesEntryMapper.mapValue3Average(v3al)).thenReturn(ve3al); 
		
		List<Value4> v4l = mockList(Value4.class);
		when(value4Repository.list(idt, fdt)).thenReturn(v4l);
		List<ValueEntry> ve4l = mockList(ValueEntry.class);
		when(valuesEntryMapper.mapValue4(v4l)).thenReturn(ve4l);
		List<Value4Average> v4al = mockList(Value4Average.class);
		when(value4AverageRepository.list(idt, fdt)).thenReturn(v4al);
		List<ValueEntry> ve4al = mockList(ValueEntry.class);
		when(valuesEntryMapper.mapValue4Average(v4al)).thenReturn(ve4al); 

		List<Value5> v5l = mockList(Value5.class);
		when(value5Repository.list(idt, fdt)).thenReturn(v5l);
		List<ValueEntry> ve5l = mockList(ValueEntry.class);
		when(valuesEntryMapper.mapValue5(v5l)).thenReturn(ve5l);
		List<Value5Average> v5al = mockList(Value5Average.class);
		when(value5AverageRepository.list(idt, fdt)).thenReturn(v5al);
		List<ValueEntry> ve5al = mockList(ValueEntry.class);
		when(valuesEntryMapper.mapValue5Average(v5al)).thenReturn(ve5al); 

		List<Value6> v6l = mockList(Value6.class);
		when(value6Repository.list(idt, fdt)).thenReturn(v6l);
		List<ValueEntry> ve6l = mockList(ValueEntry.class);
		when(valuesEntryMapper.mapValue6(v6l)).thenReturn(ve6l);
		List<Value6Average> v6al = mockList(Value6Average.class);
		when(value6AverageRepository.list(idt, fdt)).thenReturn(v6al);
		List<ValueEntry> ve6al = mockList(ValueEntry.class);
		when(valuesEntryMapper.mapValue6Average(v6al)).thenReturn(ve6al); 

		List<Value7> v7l = mockList(Value7.class);
		when(value7Repository.list(idt, fdt)).thenReturn(v7l);
		List<ValueEntry> ve7l = mockList(ValueEntry.class);
		when(valuesEntryMapper.mapValue7(v7l)).thenReturn(ve7l);
		List<Value7Average> v7al = mockList(Value7Average.class);
		when(value7AverageRepository.list(idt, fdt)).thenReturn(v7al);
		List<ValueEntry> ve7al = mockList(ValueEntry.class);
		when(valuesEntryMapper.mapValue7Average(v7al)).thenReturn(ve7al); 

		List<Value8> v8l = mockList(Value8.class);
		when(value8Repository.list(idt, fdt)).thenReturn(v8l);
		List<ValueEntry> ve8l = mockList(ValueEntry.class);
		when(valuesEntryMapper.mapValue8(v8l)).thenReturn(ve8l);
		List<Value8Average> v8al = mockList(Value8Average.class);
		when(value8AverageRepository.list(idt, fdt)).thenReturn(v8al);
		List<ValueEntry> ve8al = mockList(ValueEntry.class);
		when(valuesEntryMapper.mapValue8Average(v8al)).thenReturn(ve8al);

		List<Value9> v9l = mockList(Value9.class);
		when(value9Repository.list(idt, fdt)).thenReturn(v9l);
		List<ValueEntry> ve9l = mockList(ValueEntry.class);
		when(valuesEntryMapper.mapValue9(v9l)).thenReturn(ve9l);
		List<Value9Average> v9al = mockList(Value9Average.class);
		when(value9AverageRepository.list(idt, fdt)).thenReturn(v9al);
		List<ValueEntry> ve9al = mockList(ValueEntry.class);
		when(valuesEntryMapper.mapValue9Average(v9al)).thenReturn(ve9al); 
		
		ValuesData vd1 = new ValuesData();
		vd1.setValue1List(ve1l);
		vd1.setValue1AverageList(ve1al);
		
		vd1.setValue2List(ve2l);
		vd1.setValue2AverageList(ve2al); 
		
		vd1.setValue3List(ve3l);
		vd1.setValue3AverageList(ve3al);

		vd1.setValue4List(ve4l);
		vd1.setValue4AverageList(ve4al);

		vd1.setValue5List(ve5l);
		vd1.setValue5AverageList(ve5al);

		vd1.setValue6List(ve6l);
		vd1.setValue6AverageList(ve6al);

		vd1.setValue7List(ve7l);
		vd1.setValue7AverageList(ve7al);

		vd1.setValue8List(ve8l);
		vd1.setValue8AverageList(ve8al);

		vd1.setValue9List(ve9l);
		vd1.setValue9AverageList(ve9al);
		
		Map<ValuesEnum, List<ValueEntry>> vmap = new HashMap<>();
		vmap.put(VALUE1, ve1l);
		vmap.put(VALUE1_AVERAGE, ve1al);
		vmap.put(VALUE2, ve2l);
		vmap.put(VALUE2_AVERAGE, ve2al);
		vmap.put(VALUE3, ve3l);
		vmap.put(VALUE3_AVERAGE, ve3al);
		vmap.put(VALUE4, ve4l);
		vmap.put(VALUE4_AVERAGE, ve4al);
		vmap.put(VALUE5, ve5l);
		vmap.put(VALUE5_AVERAGE, ve5al);
		vmap.put(VALUE6, ve6l);
		vmap.put(VALUE6_AVERAGE, ve6al);
		vmap.put(VALUE7, ve7l);
		vmap.put(VALUE7_AVERAGE, ve7al);
		vmap.put(VALUE8, ve8l);
		vmap.put(VALUE8_AVERAGE, ve8al);
		vmap.put(VALUE9, ve9l);
		vmap.put(VALUE9_AVERAGE, ve9al);
		
		when(valuesDataFactory.create(vmap)).thenReturn(vd1);
		
		
		ValuesData vd2 = valuesService.getValuesData(idt, fdt);
		
		assertNotNull(vd2);
		assertSame(vd1, vd2);
		
		assertNotNull(vd2.getValue1List());
		assertSame(ve1l, vd2.getValue1List());
		
		assertNotNull(vd2.getValue2List());
		assertSame(ve2l, vd2.getValue2List());
		
		assertNotNull(vd2.getValue3List());
		assertSame(ve3l, vd2.getValue3List());
		
		assertNotNull(vd2.getValue4List());
		assertSame(ve4l, vd2.getValue4List());

		assertNotNull(vd2.getValue5List());
		assertSame(ve5l, vd2.getValue5List());

		assertNotNull(vd2.getValue6List());
		assertSame(ve6l, vd2.getValue6List());

		assertNotNull(vd2.getValue7List());
		assertSame(ve7l, vd2.getValue7List());

		assertNotNull(vd2.getValue8List());
		assertSame(ve8l, vd2.getValue8List());

		assertNotNull(vd2.getValue9List());
		assertSame(ve9l, vd2.getValue9List());
		
		assertNotNull(vd2.getValue1AverageList());
		assertSame(ve1al, vd2.getValue1AverageList());
		
		assertNotNull(vd2.getValue2AverageList());
		assertSame(ve2al, vd2.getValue2AverageList());

		assertNotNull(vd1.getValue3AverageList());
		assertSame(ve3al, vd2.getValue3AverageList());

		assertNotNull(vd2.getValue4AverageList());
		assertSame(ve4al, vd2.getValue4AverageList());

		assertNotNull(vd2.getValue5AverageList());
		assertSame(ve5al, vd2.getValue5AverageList());

		assertNotNull(vd2.getValue6AverageList());
		assertSame(ve6al, vd2.getValue6AverageList());

		assertNotNull(vd2.getValue7AverageList());
		assertSame(ve7al, vd2.getValue7AverageList());

		assertNotNull(vd2.getValue8AverageList());
		assertSame(ve8al, vd2.getValue8AverageList());

		assertNotNull(vd2.getValue9AverageList());
		assertSame(ve9al, vd2.getValue9AverageList());
		
		verify(intervalValidator).validate(idt, fdt, MAX_NUMBER_OF_DAYS);
		
		verify(bTRepository).list(idt, fdt);
		verify(valuesEntryMapper).mapValue1(v1l);
		verify(value1AverageRepository).list(idt, fdt);
		verify(valuesEntryMapper).mapValue1Average(v1al);
		
		verify(value2Repository).list(idt, fdt);
		verify(valuesEntryMapper).mapValue2(v2l);
		verify(value2AverageRepository).list(idt, fdt);
		verify(valuesEntryMapper).mapValue2Average(v2al);
		
		verify(value3Repository).list(idt, fdt);
		verify(valuesEntryMapper).mapValue3(v3l);
		verify(value3AverageRepository).list(idt, fdt);
		verify(valuesEntryMapper).mapValue3Average(v3al);

		verify(value4Repository).list(idt, fdt);
		verify(valuesEntryMapper).mapValue4(v4l);
		verify(value4AverageRepository).list(idt, fdt);
		verify(valuesEntryMapper).mapValue4Average(v4al);

		verify(value5Repository).list(idt, fdt);
		verify(valuesEntryMapper).mapValue5(v5l);
		verify(value5AverageRepository).list(idt, fdt);
		verify(valuesEntryMapper).mapValue5Average(v5al);

		verify(value6Repository).list(idt, fdt);
		verify(valuesEntryMapper).mapValue6(v6l);
		verify(value6AverageRepository).list(idt, fdt);
		verify(valuesEntryMapper).mapValue6Average(v6al);

		verify(value7Repository).list(idt, fdt);
		verify(valuesEntryMapper).mapValue7(v7l);
		verify(value7AverageRepository).list(idt, fdt);
		verify(valuesEntryMapper).mapValue7Average(v7al);

		verify(value8Repository).list(idt, fdt);
		verify(valuesEntryMapper).mapValue8(v8l);
		verify(value8AverageRepository).list(idt, fdt);
		verify(valuesEntryMapper).mapValue8Average(v8al);

		verify(value9Repository).list(idt, fdt);
		verify(valuesEntryMapper).mapValue9(v9l);
		verify(value9AverageRepository).list(idt, fdt);
		verify(valuesEntryMapper).mapValue9Average(v9al);
		
		
		verify(valuesDataFactory).create(vmap);
	}


}
