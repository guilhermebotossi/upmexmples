
package br.inpe.climaespacial.swd.acquisition.factories;

import br.inpe.climaespacial.swd.acquisition.dtos.Plasma;
import br.inpe.climaespacial.swd.commons.factories.DefaultFactory;
import javax.enterprise.context.Dependent;

@Dependent
public class DefaultPlasmaFactory extends DefaultFactory<Plasma> implements PlasmaFactory {
    
    public DefaultPlasmaFactory() {
        super(Plasma.class);
    }

}
