package br.inpe.climaespacial.swd.indexes.c.factories;

import br.inpe.climaespacial.swd.indexes.c.entities.CIndexEntity;
import br.inpe.climaespacial.swd.commons.factories.EntityFactory;

public interface CIndexEntityFactory extends EntityFactory<CIndexEntity> {


}
