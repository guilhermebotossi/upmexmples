package br.inpe.climaespacial.swd.indexes.v.services;

import br.inpe.climaespacial.swd.indexes.v.dtos.VIndex;
import br.inpe.climaespacial.swd.average.dtos.HourlyAverage;
import java.util.List;
import javax.enterprise.context.Dependent;

/* TODO para implementar */

@Dependent
public class DefaultVIndexCalculator implements VIndexCalculator {

    @Override
    public VIndex calculate(List<HourlyAverage> hourlyAverageList) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
