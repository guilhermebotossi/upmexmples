
package br.inpe.climaespacial.swd.acquisition.home;

import java.util.List;
import javax.enterprise.context.Dependent;

// TODO: Change entrys to entries
@Dependent
public class IndexData {
    
    private List<IndexEntry> bEntrys;   
    private List<IndexEntry> cEntrys;    
    private List<IndexEntry> vEntrys;
    private List<IndexEntry> zEntrys;

    public List<IndexEntry> getbEntrys() {
        return bEntrys;
    }

    public void setbEntrys(List<IndexEntry> bEntrys) {
        this.bEntrys = bEntrys;
    }

    public List<IndexEntry> getcEntrys() {
        return cEntrys;
    }

    public void setcEntrys(List<IndexEntry> cEntrys) {
        this.cEntrys = cEntrys;
    }

    public List<IndexEntry> getvEntrys() {
        return vEntrys;
    }

    public void setvEntrys(List<IndexEntry> vEntrys) {
        this.vEntrys = vEntrys;
    }

    public List<IndexEntry> getzEntrys() {
        return zEntrys;
    }

    public void setzEntrys(List<IndexEntry> zEntrys) {
        this.zEntrys = zEntrys;
    }
    
}
