package br.inpe.climaespacial.swd.indexes.v.services;

import br.inpe.climaespacial.swd.average.dtos.HourlyAverage;
import br.inpe.climaespacial.swd.indexes.v.dtos.VIndex;
import br.inpe.climaespacial.swd.indexes.v.repositories.VIndexHourlyAverageReaderRepository;
import br.inpe.climaespacial.swd.indexes.v.repositories.VIndexWriterRepository;
import java.util.List;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;

@Dependent
public class DefaultVIndexService implements VIndexService {

    @Inject
    private VIndexHourlyAverageReaderRepository vIndexHourlyAverageReaderRepository;

    @Inject
    private VIndexCalculator vIndexCalculator;

    @Inject
    private VIndexWriterRepository vIndexWriterRepository;

    @Override
    public void calculate() {
        List<HourlyAverage> hal;
        while (!(hal = vIndexHourlyAverageReaderRepository.getHourlyAverages()).isEmpty()) {
            VIndex vi = vIndexCalculator.calculate(hal);
            vIndexWriterRepository.save(vi);
        }
    }
}
