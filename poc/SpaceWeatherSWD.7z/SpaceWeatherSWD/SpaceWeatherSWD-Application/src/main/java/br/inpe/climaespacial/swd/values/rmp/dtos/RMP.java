package br.inpe.climaespacial.swd.values.rmp.dtos;

import java.time.ZonedDateTime;

import javax.enterprise.context.Dependent;

@Dependent
public class RMP {
	
	private ZonedDateTime timeTag;
	private Double rmp;

	public ZonedDateTime getTimeTag() {
		return timeTag;
	}

	public void setTimeTag(ZonedDateTime timeTag) {
		this.timeTag = timeTag;
	}

	public Double getRMP() {
		return rmp;
	}

	public void setRMP(Double rmp) {
		this.rmp = rmp;
	}

}
