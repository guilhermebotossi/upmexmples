package br.inpe.climaespacial.swd.indexes.b.factories;

import br.inpe.climaespacial.swd.average.dtos.HourlyAverage;
import br.inpe.climaespacial.swd.commons.factories.Factory;

public interface HourlyAverageFactory extends Factory<HourlyAverage> {

}
