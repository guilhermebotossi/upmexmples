package br.inpe.climaespacial.swd.hello.services;

import br.inpe.climaespacial.swd.hello.dtos.Hello;

public interface HelloService {

	Hello hello();

}
