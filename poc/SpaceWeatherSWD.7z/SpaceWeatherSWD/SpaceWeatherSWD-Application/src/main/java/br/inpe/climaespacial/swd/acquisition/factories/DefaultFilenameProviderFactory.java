package br.inpe.climaespacial.swd.acquisition.factories;

import javax.enterprise.context.Dependent;

import br.inpe.climaespacial.swd.acquisition.providers.DateTimeProvider;
import br.inpe.climaespacial.swd.acquisition.providers.DefaultFilenameProvider;
import br.inpe.climaespacial.swd.acquisition.providers.FilenameProvider;
import br.inpe.climaespacial.swd.acquisition.repositories.LastRecordRepository;

@Dependent
public class DefaultFilenameProviderFactory implements FilenameProviderFactory {

	@Override
	public FilenameProvider create(LastRecordRepository lastRecordRepository, DateTimeProvider dateTimeProvider) {
		if (lastRecordRepository == null)
			throw new RuntimeException("Parâmetro \"lastRecordRepository\" null.");
		
		if (dateTimeProvider == null)
			throw new RuntimeException("Parâmetro \"dateTimeProvider\" null.");
		
		return new DefaultFilenameProvider(lastRecordRepository, dateTimeProvider);
	}

}
