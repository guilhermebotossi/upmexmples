package br.inpe.climaespacial.swd.values.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import br.inpe.climaespacial.swd.values.dtos.Value3;

public interface Value3Repository {

	List<Value3> list(ZonedDateTime idt, ZonedDateTime fdt);

}
