package br.inpe.climaespacial.swd.indexes.b.factories;

import br.inpe.climaespacial.swd.average.dtos.HourlyAverage;
import br.inpe.climaespacial.swd.commons.factories.DefaultFactory;
import javax.enterprise.context.Dependent;

@Dependent
public class DefaultHourlyAverageFactory extends DefaultFactory<HourlyAverage> implements HourlyAverageFactory {

    public DefaultHourlyAverageFactory() {
        super(HourlyAverage.class);
    }

}
