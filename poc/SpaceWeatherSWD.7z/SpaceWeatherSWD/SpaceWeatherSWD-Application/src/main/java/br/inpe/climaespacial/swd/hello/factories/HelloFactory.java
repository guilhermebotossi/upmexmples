package br.inpe.climaespacial.swd.hello.factories;

import br.inpe.climaespacial.swd.commons.factories.Factory;
import br.inpe.climaespacial.swd.hello.dtos.Hello;

public interface HelloFactory extends Factory<Hello> {
    
}
