package br.inpe.climaespacial.swd.indexes.v.services;

public interface VIndexService {
    
    void calculate();
    
}
