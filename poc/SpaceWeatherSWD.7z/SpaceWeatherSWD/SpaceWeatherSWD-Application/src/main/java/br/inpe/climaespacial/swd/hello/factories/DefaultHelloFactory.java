package br.inpe.climaespacial.swd.hello.factories;

import br.inpe.climaespacial.swd.commons.factories.DefaultFactory;
import br.inpe.climaespacial.swd.hello.dtos.Hello;
import javax.enterprise.context.Dependent;

@Dependent
public class DefaultHelloFactory extends DefaultFactory<Hello> implements HelloFactory {
	
		DefaultHelloFactory() {
			super(Hello.class);
		}

}
