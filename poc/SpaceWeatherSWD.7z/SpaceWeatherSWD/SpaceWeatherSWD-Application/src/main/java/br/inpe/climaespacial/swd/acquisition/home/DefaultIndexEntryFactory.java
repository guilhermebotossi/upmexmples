package br.inpe.climaespacial.swd.acquisition.home;

import br.inpe.climaespacial.swd.commons.factories.DefaultFactory;
import javax.enterprise.context.Dependent;

@Dependent
public class DefaultIndexEntryFactory extends DefaultFactory<IndexEntry> implements IndexEntryFactory {

    public DefaultIndexEntryFactory() {
        super(IndexEntry.class);
    }

}
