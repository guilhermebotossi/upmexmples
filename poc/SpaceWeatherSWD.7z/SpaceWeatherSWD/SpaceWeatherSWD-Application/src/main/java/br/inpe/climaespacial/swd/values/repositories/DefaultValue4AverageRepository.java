package br.inpe.climaespacial.swd.values.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import javax.enterprise.context.Dependent;

import br.inpe.climaespacial.swd.values.dtos.Value4Average;

@Dependent
public class DefaultValue4AverageRepository implements Value4AverageRepository {

	@Override
	public List<Value4Average> list(ZonedDateTime idt, ZonedDateTime fdt) {
		throw new RuntimeException("Not Yet Implemented");
	}

}
