package br.inpe.climaespacial.swd.indexes.z.services;

import br.inpe.climaespacial.swd.indexes.z.repositories.ZIndexWriterRepository;
import br.inpe.climaespacial.swd.indexes.z.dtos.ZIndex;
import br.inpe.climaespacial.swd.average.dtos.HourlyAverage;
import br.inpe.climaespacial.swd.indexes.z.repositories.ZIndexHourlyAverageReaderRepository;
import java.util.List;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;

@Dependent
public class DefaultZIndexService implements ZIndexService {

    @Inject
    private ZIndexHourlyAverageReaderRepository zIndexHourlyAverageReaderRepository;

    @Inject
    private ZIndexCalculator zIndexCalculator;

    @Inject
    private ZIndexWriterRepository zIndexWriterRepository;

    @Override
    public void calculate() {
        List<HourlyAverage> hal;
        while (!(hal = zIndexHourlyAverageReaderRepository.getHourlyAverages()).isEmpty()) {
            ZIndex zi = zIndexCalculator.calculate(hal);
            zIndexWriterRepository.save(zi);
        }
    }
}

