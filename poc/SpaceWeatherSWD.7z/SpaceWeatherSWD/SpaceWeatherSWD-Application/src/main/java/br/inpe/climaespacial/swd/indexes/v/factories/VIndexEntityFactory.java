package br.inpe.climaespacial.swd.indexes.v.factories;

import br.inpe.climaespacial.swd.indexes.v.entities.VIndexEntity;
import br.inpe.climaespacial.swd.commons.factories.EntityFactory;

public interface VIndexEntityFactory extends EntityFactory<VIndexEntity> {

}
