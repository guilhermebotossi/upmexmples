package br.inpe.climaespacial.swd.values.temperature.average.dtos;

import java.time.ZonedDateTime;

import javax.enterprise.context.Dependent;

@Dependent
public class AverageTemperature {
	
	private ZonedDateTime timeTag;
	private Double AverageTemperature;

	public ZonedDateTime getTimeTag() {
		return timeTag;
	}

	public void setTimeTag(ZonedDateTime timeTag) {
		this.timeTag = timeTag;
	}

	public Double getAverageTemperature() {
		return AverageTemperature;
	}

	public void setAverageTemperature(Double AverageTemperature) {
		this.AverageTemperature = AverageTemperature;
	}

}
