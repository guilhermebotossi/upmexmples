package br.inpe.climaespacial.swd.indexes.b.services;

import br.inpe.climaespacial.swd.indexes.b.repositories.BIndexHourlyAverageReaderRepository;
import br.inpe.climaespacial.swd.indexes.b.repositories.BIndexWriterRepository;
import br.inpe.climaespacial.swd.indexes.b.dtos.BIndex;
import br.inpe.climaespacial.swd.average.dtos.HourlyAverage;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;

@Dependent
public class DefaultBIndexService implements BIndexService {

    @Inject
    private BIndexHourlyAverageReaderRepository bIndexHourlyAverageReaderRepository;

    @Inject
    private BIndexCalculator bIndexCalculator;

    @Inject
    private BIndexWriterRepository bIndexWriterRepository;

    @Override
    public void calculate() {
        HourlyAverage ha;
        while ((ha = bIndexHourlyAverageReaderRepository.getHourlyAverage()) != null) {
            BIndex bi = bIndexCalculator.calculate(ha);
            bIndexWriterRepository.save(bi);
        }
    }
}
