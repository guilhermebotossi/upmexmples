package br.inpe.climaespacial.swd.values.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import br.inpe.climaespacial.swd.values.dtos.Value7Average;

public interface Value7AverageRepository {

	List<Value7Average> list(ZonedDateTime idt, ZonedDateTime fdt);

}
