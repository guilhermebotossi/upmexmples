package br.inpe.climaespacial.swd.indexes.c.repositories;

import br.inpe.climaespacial.swd.indexes.c.dtos.CIndex;
import br.inpe.climaespacial.swd.indexes.c.entities.CIndexEntity;
import br.inpe.climaespacial.swd.indexes.c.mappers.CIndexMapper;
import java.time.ZonedDateTime;
import java.util.List;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

@Dependent
public class DefaultCIndexReaderRepository implements CIndexReaderRepository {

    private static final String QUERY = "SELECT MAX(cie.timeTag) FROM CIndexEntity cie";
    
    private static final String QUERY_LIST = "SELECT cie FROM CIndexEntity cie WHERE cie.timeTag BETWEEN :farthestFromNow AND :nearestFromNow ORDER BY cie.timeTag";

    @Inject
    private EntityManager entityManager;
    
    @Inject
    private CIndexMapper cIndexMapper;

    @Override
    public ZonedDateTime getNextHourToBeCalculated() {
        TypedQuery<ZonedDateTime> tq = entityManager.createQuery(QUERY, ZonedDateTime.class);
        ZonedDateTime zdt = tq.getResultList().get(0);
        return zdt == null ? null : zdt.plusHours(1);
    }
    
    @Override
    public List<CIndex> listByPeriod(ZonedDateTime farthestFromNow, ZonedDateTime nearestFromNow) {
        TypedQuery<CIndexEntity> tq = entityManager.createQuery(QUERY_LIST, CIndexEntity.class);
        tq.setParameter("farthestFromNow", farthestFromNow);
        tq.setParameter("nearestFromNow", nearestFromNow);
        List<CIndexEntity> ciel = tq.getResultList();        
        return cIndexMapper.map(ciel);
    }

}
