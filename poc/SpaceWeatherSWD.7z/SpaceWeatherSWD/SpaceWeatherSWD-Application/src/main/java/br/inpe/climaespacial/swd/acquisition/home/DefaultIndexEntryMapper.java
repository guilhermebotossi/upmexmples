package br.inpe.climaespacial.swd.acquisition.home;

import br.inpe.climaespacial.swd.commons.factories.ListFactory;
import br.inpe.climaespacial.swd.indexes.b.dtos.BIndex;
import br.inpe.climaespacial.swd.indexes.c.dtos.CIndex;
import br.inpe.climaespacial.swd.indexes.v.dtos.VIndex;
import br.inpe.climaespacial.swd.indexes.z.dtos.ZIndex;
import java.util.List;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;

@Dependent
public class DefaultIndexEntryMapper implements IndexEntryMapper {
    
    @Inject
    private ListFactory<IndexEntry> indexEntryListFactory;
    
    @Inject
    private IndexEntryFactory indexEntryFactory;

    @Override
    public List<IndexEntry> mapB(List<BIndex> bIndexList) {
        List<IndexEntry> iel = indexEntryListFactory.create();
        bIndexList.forEach(bi -> {
            IndexEntry ie = indexEntryFactory.create();
            ie.setTimeTag(bi.getTimeTag());
            ie.setValue(bi.getPostValue());
            iel.add(ie);
        });
        return iel;
    }

    @Override
    public List<IndexEntry> mapC(List<CIndex> cIndexList) {
        List<IndexEntry> iel = indexEntryListFactory.create();
        cIndexList.forEach(ci -> {
            IndexEntry ie = indexEntryFactory.create();
            ie.setTimeTag(ci.getTimeTag());
            ie.setValue(ci.getPostValue());
            iel.add(ie);
        });
        return iel;
    }

    @Override
    public List<IndexEntry> mapV(List<VIndex> vIndexList) {
        List<IndexEntry> iel = indexEntryListFactory.create();
        vIndexList.forEach(vi -> {
            IndexEntry ie = indexEntryFactory.create();
            ie.setTimeTag(vi.getTimeTag());
            ie.setValue(vi.getValue());
            iel.add(ie);
        });
        return iel;
    }

    @Override
    public List<IndexEntry> mapZ(List<ZIndex> zIndexList) {
        List<IndexEntry> iel = indexEntryListFactory.create();
        zIndexList.forEach(zi -> {
            IndexEntry ie = indexEntryFactory.create();
            ie.setTimeTag(zi.getTimeTag());
            ie.setValue(zi.getPostValue());
            iel.add(ie);
        });
        return iel;
    }

}
