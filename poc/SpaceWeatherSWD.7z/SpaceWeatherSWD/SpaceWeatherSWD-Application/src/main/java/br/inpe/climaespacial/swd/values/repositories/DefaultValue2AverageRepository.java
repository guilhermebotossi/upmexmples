package br.inpe.climaespacial.swd.values.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import javax.enterprise.context.Dependent;

import br.inpe.climaespacial.swd.values.dtos.Value2Average;

@Dependent
public class DefaultValue2AverageRepository implements Value2AverageRepository {

	@Override
	public List<Value2Average> list(ZonedDateTime idt, ZonedDateTime fdt) {
		throw new RuntimeException("Not Yet Implemented");
	}

}
