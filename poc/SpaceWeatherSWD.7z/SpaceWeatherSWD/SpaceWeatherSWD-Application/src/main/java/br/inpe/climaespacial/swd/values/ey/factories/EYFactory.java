package br.inpe.climaespacial.swd.values.ey.factories;

import java.time.ZonedDateTime;

import br.inpe.climaespacial.swd.values.ey.dtos.EY;

public interface EYFactory {

	EY create(ZonedDateTime timeTag, Double ey);


}
