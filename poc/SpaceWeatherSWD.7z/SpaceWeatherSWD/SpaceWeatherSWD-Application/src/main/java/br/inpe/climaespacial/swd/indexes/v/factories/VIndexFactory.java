package br.inpe.climaespacial.swd.indexes.v.factories;

import br.inpe.climaespacial.swd.indexes.v.dtos.VIndex;
import br.inpe.climaespacial.swd.commons.factories.Factory;

public interface VIndexFactory  extends Factory<VIndex>{

}
