package br.inpe.climaespacial.swd.indexes.z.mappers;

import br.inpe.climaespacial.swd.indexes.z.entities.ZIndexEntity;
import br.inpe.climaespacial.swd.indexes.z.dtos.ZIndex;
import br.inpe.climaespacial.swd.indexes.z.factories.ZIndexEntityFactory;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;

@Dependent
public class DefaultZIndexEntityMapper implements ZIndexEntityMapper {
	
	@Inject
	private ZIndexEntityFactory zIndexEntityFactory;

	@Override
	public ZIndexEntity map(ZIndex zIndex) {
		if(zIndex == null) {
			throw new RuntimeException("Parâmetro \"zIndex\" null/empty.");
		}
		
		ZIndexEntity zie = zIndexEntityFactory.create();
		zie.setTimeTag(zIndex.getTimeTag());
		zie.setPreValue(zIndex.getPreValue());
		zie.setPostValue(zIndex.getPostValue());
		
		return zie;
	}

}
