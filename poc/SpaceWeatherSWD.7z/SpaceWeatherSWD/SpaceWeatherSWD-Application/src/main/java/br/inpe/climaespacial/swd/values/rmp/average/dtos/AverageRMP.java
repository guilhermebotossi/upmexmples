package br.inpe.climaespacial.swd.values.rmp.average.dtos;

import java.time.ZonedDateTime;

import javax.enterprise.context.Dependent;

@Dependent
public class AverageRMP {
	
	private ZonedDateTime timeTag;
	private Double averageRMP;

	public ZonedDateTime getTimeTag() {
		return timeTag;
	}

	public void setTimeTag(ZonedDateTime timeTag) {
		this.timeTag = timeTag;
	}

	public Double getAverageRMP() {
		return averageRMP;
	}

	public void setAverageRMP(Double averageRMP) {
		this.averageRMP = averageRMP;
	}

}
