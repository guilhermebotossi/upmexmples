package br.inpe.climaespacial.swd.values.temperature.factories;

import java.time.ZonedDateTime;

import br.inpe.climaespacial.swd.values.temperature.dtos.Temperature;

public interface TemperatureFactory {

	Temperature create(ZonedDateTime timeTag, Double temperature);


}
