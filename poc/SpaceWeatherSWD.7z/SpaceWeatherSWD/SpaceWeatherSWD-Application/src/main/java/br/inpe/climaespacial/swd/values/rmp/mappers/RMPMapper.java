package br.inpe.climaespacial.swd.values.rmp.mappers;

import java.util.List;

import br.inpe.climaespacial.swd.values.rmp.dtos.RMP;
import br.inpe.climaespacial.swd.values.rmp.entities.RMPEntity;

public interface RMPMapper {

	List<RMP> map(List<RMPEntity> rmpEntityList);

}
