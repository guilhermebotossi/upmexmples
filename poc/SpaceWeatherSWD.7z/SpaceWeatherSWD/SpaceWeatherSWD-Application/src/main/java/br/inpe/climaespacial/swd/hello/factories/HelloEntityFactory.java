package br.inpe.climaespacial.swd.hello.factories;

import br.inpe.climaespacial.swd.commons.factories.EntityFactory;
import br.inpe.climaespacial.swd.hello.entities.HelloEntity;

public interface HelloEntityFactory extends EntityFactory<HelloEntity> {

}
