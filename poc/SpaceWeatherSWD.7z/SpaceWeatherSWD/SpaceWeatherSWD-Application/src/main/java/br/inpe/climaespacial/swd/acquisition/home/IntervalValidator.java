
package br.inpe.climaespacial.swd.acquisition.home;

import java.time.ZonedDateTime;

public interface IntervalValidator {
    
    void validate(ZonedDateTime farthestFromNow, ZonedDateTime nearestFromNow, int periodSize);
    
}
