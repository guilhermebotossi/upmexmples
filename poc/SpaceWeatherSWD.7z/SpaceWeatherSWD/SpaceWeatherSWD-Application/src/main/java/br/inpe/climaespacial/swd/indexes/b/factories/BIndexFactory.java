package br.inpe.climaespacial.swd.indexes.b.factories;

import br.inpe.climaespacial.swd.commons.factories.Factory;
import br.inpe.climaespacial.swd.indexes.b.dtos.BIndex;

public interface BIndexFactory  extends Factory<BIndex>{

}
