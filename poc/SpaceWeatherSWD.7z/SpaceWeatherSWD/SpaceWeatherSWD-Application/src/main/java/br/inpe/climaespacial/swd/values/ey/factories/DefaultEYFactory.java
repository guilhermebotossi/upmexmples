package br.inpe.climaespacial.swd.values.ey.factories;

import java.time.ZonedDateTime;

import javax.enterprise.context.Dependent;

import br.inpe.climaespacial.swd.values.ey.dtos.EY;

@Dependent
public class DefaultEYFactory implements EYFactory {

	@Override
	public EY create(ZonedDateTime timeTag, Double value) {
		EY ey = new EY();
		ey.setTimeTag(timeTag);
		ey.setEY(value);
		return ey;
	}

}
