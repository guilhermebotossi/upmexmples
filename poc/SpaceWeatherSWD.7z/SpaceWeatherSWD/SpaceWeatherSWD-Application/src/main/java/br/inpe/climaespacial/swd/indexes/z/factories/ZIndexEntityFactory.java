package br.inpe.climaespacial.swd.indexes.z.factories;

import br.inpe.climaespacial.swd.commons.factories.EntityFactory;
import br.inpe.climaespacial.swd.indexes.z.entities.ZIndexEntity;

public interface ZIndexEntityFactory extends EntityFactory<ZIndexEntity>{


}
