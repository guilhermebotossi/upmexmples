package br.inpe.climaespacial.swd.acquisition.home;

import br.inpe.climaespacial.swd.commons.factories.DefaultFactory;
import br.inpe.climaespacial.swd.commons.factories.Factory;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import javax.enterprise.context.Dependent;
import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;

@Dependent
public class FactoryProducer {

    @Produces
    public <T> Factory<T> create(InjectionPoint injectionPoint) {
        try {
            Field f = (Field) injectionPoint.getMember();
            Type t = ((ParameterizedType) f.getGenericType()).getActualTypeArguments()[0];
            String tn = t.getTypeName();
            @SuppressWarnings("unchecked")
            Class<T> c = (Class<T>) Class.forName(tn);
            return new DefaultFactory<>(c);
        } catch (ClassNotFoundException ex) {
            throw new RuntimeException(ex);
        }
    }

}
