package br.inpe.climaespacial.swd.values.factories;

import java.util.List;
import java.util.Map;

import javax.enterprise.context.Dependent;
import javax.inject.Inject;

import br.inpe.climaespacial.swd.commons.factories.Factory;
import br.inpe.climaespacial.swd.values.dtos.ValueEntry;
import br.inpe.climaespacial.swd.values.dtos.ValuesData;
import br.inpe.climaespacial.swd.values.enums.ValuesEnum;

import static br.inpe.climaespacial.swd.values.enums.ValuesEnum.*;

@Dependent
public class DefaultValuesDataFactory implements ValuesDataFactory {

	@Inject
    private Factory<ValuesData> ValuesDataValuesData;
	
	@Override
	public ValuesData create(Map<ValuesEnum, List<ValueEntry>> valuesMap) {
		if (valuesMap == null || valuesMap.isEmpty()) {
			throw new RuntimeException("Parametro \"valuesMap\" null/empty.");
		}

		int size = ValuesEnum.values().length;

		if (valuesMap.size() < size) {
			throw new RuntimeException("Parametro \"valuesMap\" deve possuir todas as entradas do Enum ValuesEnum.");
		}

		for (ValuesEnum ve : ValuesEnum.values()) {
			if (!valuesMap.containsKey(ve) || valuesMap.get(ve) == null)
				throw new RuntimeException("Parametro \"valuesMap[" + ve + "]\" inexistente ou null.");

		}
		
		ValuesData vd = ValuesDataValuesData.create();
		
		vd.setValue1List(valuesMap.get(VALUE1));
		vd.setValue2List(valuesMap.get(VALUE2));
		vd.setValue3List(valuesMap.get(VALUE3));
		vd.setValue4List(valuesMap.get(VALUE4));
		vd.setValue5List(valuesMap.get(VALUE5));
		vd.setValue6List(valuesMap.get(VALUE6));
		vd.setValue7List(valuesMap.get(VALUE7));
		vd.setValue8List(valuesMap.get(VALUE8));
		vd.setValue9List(valuesMap.get(VALUE9));
		
		vd.setValue1AverageList(valuesMap.get(VALUE1_AVERAGE));
		vd.setValue2AverageList(valuesMap.get(VALUE2_AVERAGE));
		vd.setValue3AverageList(valuesMap.get(VALUE3_AVERAGE));
		vd.setValue4AverageList(valuesMap.get(VALUE4_AVERAGE));
		vd.setValue5AverageList(valuesMap.get(VALUE5_AVERAGE));
		vd.setValue6AverageList(valuesMap.get(VALUE6_AVERAGE));
		vd.setValue7AverageList(valuesMap.get(VALUE7_AVERAGE));
		vd.setValue8AverageList(valuesMap.get(VALUE8_AVERAGE));
		vd.setValue9AverageList(valuesMap.get(VALUE9_AVERAGE));
		
		return vd;
	}

}
