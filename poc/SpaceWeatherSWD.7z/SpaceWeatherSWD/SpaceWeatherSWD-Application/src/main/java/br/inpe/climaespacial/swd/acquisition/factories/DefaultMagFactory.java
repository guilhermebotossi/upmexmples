package br.inpe.climaespacial.swd.acquisition.factories;

import br.inpe.climaespacial.swd.acquisition.dtos.Mag;
import br.inpe.climaespacial.swd.commons.factories.DefaultFactory;
import javax.enterprise.context.Dependent;

@Dependent
public class DefaultMagFactory extends DefaultFactory<Mag> implements MagFactory {

    public DefaultMagFactory() {
        super(Mag.class);
    }

}
