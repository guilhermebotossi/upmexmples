package br.inpe.climaespacial.swd.values.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import br.inpe.climaespacial.swd.values.dtos.Value8Average;

public interface Value8AverageRepository {

	List<Value8Average> list(ZonedDateTime idt, ZonedDateTime fdt);

}
