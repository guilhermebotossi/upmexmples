package br.inpe.climaespacial.swd.values.rmp.average.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.inpe.climaespacial.swd.acquisition.home.IntervalValidator;
import br.inpe.climaespacial.swd.values.rmp.average.dtos.AverageRMP;
import br.inpe.climaespacial.swd.values.rmp.average.entities.AverageRMPEntity;
import br.inpe.climaespacial.swd.values.rmp.average.mappers.AverageRMPMapper;

@Dependent
public class DefaultAverageRMPRepository implements AverageRMPRepository {
	
	private static final int MAX_NUMBER_OF_DAYS = 3;
	
	@Inject
	private AverageRMPMapper averageRMPMapper;
	
	@Inject
	private EntityManager entityManager;

	@Inject
	private IntervalValidator intervalValidator;

	@Override
	public List<AverageRMP> list(ZonedDateTime initialDateTime, ZonedDateTime finalDateTime) {
		validate(initialDateTime, finalDateTime);
		
		TypedQuery<AverageRMPEntity> tq = entityManager.createQuery("SELECT NEW br.inpe.climaespacial.swd.values.averageRMP.entities.AverageRMPEntity(me.timeTag, me.averageRMP) "
			+ "FROM MagEntity me "
			+ "WHERE "
			+ "me.timeTag >= :initialDateTime and "
			+ "me.timeTag <= :finalDateTime", AverageRMPEntity.class);
		
		tq.setParameter("initialDateTime", initialDateTime);
		tq.setParameter("finalDateTime", finalDateTime);
		
		List<AverageRMPEntity> bel = tq.getResultList();
		
		return averageRMPMapper.map(bel);
	}

	private void validate(ZonedDateTime initialDateTime, ZonedDateTime finalDateTime) {
		if(initialDateTime == null) {
			throw new RuntimeException("Parametro \"initialDateTime\" null");
		}
		
		if(finalDateTime == null) {
			throw new RuntimeException("Parametro \"finalDateTime\" null");
		}
		
		intervalValidator.validate(initialDateTime, finalDateTime, MAX_NUMBER_OF_DAYS);
	}

}
