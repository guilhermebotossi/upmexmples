package br.inpe.climaespacial.swd.indexes.b.repositories;

import br.inpe.climaespacial.swd.indexes.b.entities.BIndexEntity;
import br.inpe.climaespacial.swd.indexes.b.dtos.BIndex;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import br.inpe.climaespacial.swd.indexes.b.mappers.BIndexEntityMapper;

@Dependent
public class DefaultBIndexWriterRepository implements BIndexWriterRepository {

    @Inject
    private EntityManager entityManager;
    
    @Inject 
    private BIndexEntityMapper bIndexEntityMapper;
	
    @Override
    public void save(BIndex bIndex) {
    	if(bIndex == null) {
    		throw new RuntimeException("Parâmetro \"bIndex\" null.");
    	}
    	
    	BIndexEntity bie = bIndexEntityMapper.map(bIndex);
    	
        entityManager.persist(bie);

        entityManager.flush();
    	
    }
    
}
