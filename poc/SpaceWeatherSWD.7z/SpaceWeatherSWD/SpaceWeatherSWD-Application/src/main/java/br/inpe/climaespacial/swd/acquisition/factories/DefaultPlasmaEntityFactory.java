package br.inpe.climaespacial.swd.acquisition.factories;

import javax.enterprise.context.Dependent;

import br.inpe.climaespacial.swd.acquisition.entities.PlasmaEntity;
import br.inpe.climaespacial.swd.calculation.factories.PlasmaEntityFactory;
import br.inpe.climaespacial.swd.commons.factories.DefaultEntityFactory;

@Dependent
public class DefaultPlasmaEntityFactory extends DefaultEntityFactory<PlasmaEntity> implements PlasmaEntityFactory {

	public DefaultPlasmaEntityFactory() {
		super(PlasmaEntity.class);
	}

}
