package br.inpe.climaespacial.swd.values.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import javax.enterprise.context.Dependent;

import br.inpe.climaespacial.swd.values.dtos.Value5;

@Dependent
public class DefaultValue5Repository implements Value5Repository {

	@Override
	public List<Value5> list(ZonedDateTime idt, ZonedDateTime fdt) {
		throw new RuntimeException("Not Yet Implemented");
	}

}
