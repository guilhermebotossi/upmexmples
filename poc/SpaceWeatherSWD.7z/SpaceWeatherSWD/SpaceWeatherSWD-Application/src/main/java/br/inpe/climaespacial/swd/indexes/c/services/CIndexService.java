package br.inpe.climaespacial.swd.indexes.c.services;

public interface CIndexService {

    void calculate();

}
