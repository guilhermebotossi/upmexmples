package br.inpe.climaespacial.swd.values.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import javax.enterprise.context.Dependent;

import br.inpe.climaespacial.swd.values.dtos.Value4;

@Dependent
public class DefaultValue4Repository implements Value4Repository {

	@Override
	public List<Value4> list(ZonedDateTime idt, ZonedDateTime fdt) {
		throw new RuntimeException("Not Yet Implemented");
	}

}
