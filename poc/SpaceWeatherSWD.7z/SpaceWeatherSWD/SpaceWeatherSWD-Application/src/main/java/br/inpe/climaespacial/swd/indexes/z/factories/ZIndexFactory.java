package br.inpe.climaespacial.swd.indexes.z.factories;

import br.inpe.climaespacial.swd.indexes.z.dtos.ZIndex;
import br.inpe.climaespacial.swd.commons.factories.Factory;

public interface ZIndexFactory  extends Factory<ZIndex>{

}
