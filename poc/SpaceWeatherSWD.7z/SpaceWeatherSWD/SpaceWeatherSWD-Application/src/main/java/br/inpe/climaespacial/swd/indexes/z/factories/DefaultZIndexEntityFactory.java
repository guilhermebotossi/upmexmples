package br.inpe.climaespacial.swd.indexes.z.factories;

import javax.enterprise.context.Dependent;

import br.inpe.climaespacial.swd.commons.factories.DefaultEntityFactory;
import br.inpe.climaespacial.swd.indexes.z.entities.ZIndexEntity;

@Dependent
public class DefaultZIndexEntityFactory extends DefaultEntityFactory<ZIndexEntity> implements ZIndexEntityFactory {

	public DefaultZIndexEntityFactory() {
		super(ZIndexEntity.class);
	}
	
}