package br.inpe.climaespacial.swd.indexes.c.factories;

import br.inpe.climaespacial.swd.commons.factories.DefaultFactory;
import br.inpe.climaespacial.swd.indexes.c.dtos.CIndex;
import javax.enterprise.context.Dependent;

@Dependent
public class DefaultCIndexFactory extends DefaultFactory<CIndex> implements CIndexFactory {

	public DefaultCIndexFactory() {
		super(CIndex.class);
	}
	
}