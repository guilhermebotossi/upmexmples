package br.inpe.climaespacial.swd.values.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import javax.enterprise.context.Dependent;

import br.inpe.climaespacial.swd.values.dtos.Value6Average;

@Dependent
public class DefaultValue6AverageRepository implements Value6AverageRepository {

	@Override
	public List<Value6Average> list(ZonedDateTime idt, ZonedDateTime fdt) {
		throw new RuntimeException("Not Yet Implemented");
	}

}
