package br.inpe.climaespacial.swd.indexes.z.services;

public interface ZIndexService {

    void calculate();

}
