package br.inpe.climaespacial.swd.acquisition.factories;

import javax.enterprise.context.Dependent;

import br.inpe.climaespacial.swd.acquisition.entities.MagEntity;
import br.inpe.climaespacial.swd.commons.factories.DefaultEntityFactory;

@Dependent
public class DefaultMagEntityFactory extends DefaultEntityFactory<MagEntity> implements MagEntityFactory {

	public DefaultMagEntityFactory() {
		super(MagEntity.class);
	}

}
