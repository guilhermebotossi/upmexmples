package br.inpe.climaespacial.swd.indexes.v.mappers;

import br.inpe.climaespacial.swd.indexes.v.factories.VIndexEntityFactory;
import br.inpe.climaespacial.swd.indexes.v.entities.VIndexEntity;
import br.inpe.climaespacial.swd.indexes.v.dtos.VIndex;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;

@Dependent
public class DefaultVIndexEntityMapper implements VIndexEntityMapper {
	
	@Inject
	private VIndexEntityFactory vIndexEntityFactory;

	@Override
	public VIndexEntity map(VIndex vIndex) {
		if(vIndex == null) {
			throw new RuntimeException("Parâmetro \"vIndex\" null/empty.");
		}
		
		VIndexEntity vie = vIndexEntityFactory.create();
		vie.setTimeTag(vIndex.getTimeTag());
		vie.setValue(vIndex.getValue());
		
		return vie;
	}

}
