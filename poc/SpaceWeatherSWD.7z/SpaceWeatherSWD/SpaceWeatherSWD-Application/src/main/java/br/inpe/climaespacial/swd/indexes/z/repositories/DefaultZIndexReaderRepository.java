package br.inpe.climaespacial.swd.indexes.z.repositories;

import br.inpe.climaespacial.swd.indexes.z.entities.ZIndexEntity;
import br.inpe.climaespacial.swd.indexes.z.mappers.ZIndexMapper;
import br.inpe.climaespacial.swd.indexes.z.dtos.ZIndex;
import java.time.ZonedDateTime;
import java.util.List;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

@Dependent
public class DefaultZIndexReaderRepository implements ZIndexReaderRepository {

    private static final String QUERY = "SELECT MAX(zie.timeTag) FROM ZIndexEntity zie";
    
    private static final String QUERY_LIST = "SELECT zie FROM ZIndexEntity zie WHERE zie.timeTag BETWEEN :farthestFromNow AND :nearestFromNow ORDER BY zie.timeTag";

    @Inject
    private EntityManager entityManager;
    
    @Inject
    private ZIndexMapper zIndexMapper;

    @Override
    public ZonedDateTime getNextHourToBeCalculated() {
        TypedQuery<ZonedDateTime> tq = entityManager.createQuery(QUERY, ZonedDateTime.class);
        ZonedDateTime zdt = tq.getResultList().get(0);
        return zdt == null ? null : zdt.plusHours(1);
    }

    @Override
    public List<ZIndex> listByPeriod(ZonedDateTime farthestFromNow, ZonedDateTime nearestFromNow) {
        TypedQuery<ZIndexEntity> tq = entityManager.createQuery(QUERY_LIST, ZIndexEntity.class);
        tq.setParameter("farthestFromNow", farthestFromNow);
        tq.setParameter("nearestFromNow", nearestFromNow);
        List<ZIndexEntity> ziel = tq.getResultList();        
        return zIndexMapper.map(ziel);
    }

}
