package br.inpe.climaespacial.swd.values.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import br.inpe.climaespacial.swd.values.dtos.Value5Average;

public interface Value5AverageRepository {

	List<Value5Average> list(ZonedDateTime idt, ZonedDateTime fdt);

}
