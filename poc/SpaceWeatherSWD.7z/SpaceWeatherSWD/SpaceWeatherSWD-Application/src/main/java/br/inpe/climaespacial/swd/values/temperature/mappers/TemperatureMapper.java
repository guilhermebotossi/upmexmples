package br.inpe.climaespacial.swd.values.temperature.mappers;

import java.util.List;

import br.inpe.climaespacial.swd.values.temperature.dtos.Temperature;
import br.inpe.climaespacial.swd.values.temperature.entities.TemperatureEntity;

public interface TemperatureMapper {

	List<Temperature> map(List<TemperatureEntity> temperatureEntityList);

}
