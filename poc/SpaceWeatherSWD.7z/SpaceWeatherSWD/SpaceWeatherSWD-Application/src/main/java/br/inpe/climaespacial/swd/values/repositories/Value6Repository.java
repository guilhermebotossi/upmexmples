package br.inpe.climaespacial.swd.values.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import br.inpe.climaespacial.swd.values.dtos.Value6;

public interface Value6Repository {

	List<Value6> list(ZonedDateTime idt, ZonedDateTime fdt);

}
