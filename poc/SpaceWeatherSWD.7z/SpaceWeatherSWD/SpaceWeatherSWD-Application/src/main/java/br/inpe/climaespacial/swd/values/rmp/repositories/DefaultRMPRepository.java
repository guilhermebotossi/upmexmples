package br.inpe.climaespacial.swd.values.rmp.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.inpe.climaespacial.swd.acquisition.home.IntervalValidator;
import br.inpe.climaespacial.swd.values.rmp.dtos.RMP;
import br.inpe.climaespacial.swd.values.rmp.entities.RMPEntity;
import br.inpe.climaespacial.swd.values.rmp.mappers.RMPMapper;

@Dependent
public class DefaultRMPRepository implements RMPRepository {
	
	private static final int MAX_NUMBER_OF_DAYS = 3;
	
	@Inject
	private RMPMapper rmpMapper;
	
	@Inject
	private EntityManager entityManager;

	@Inject
	private IntervalValidator intervalValidator;

	@Override
	public List<RMP> list(ZonedDateTime initialDateTime, ZonedDateTime finalDateTime) {
		validate(initialDateTime, finalDateTime);
		
		TypedQuery<RMPEntity> tq = entityManager.createQuery("SELECT NEW br.inpe.climaespacial.swd.values.rmp.entities.RMPEntity(me.timeTag, me.rmp) "
			+ "FROM MagEntity me "
			+ "WHERE "
			+ "me.timeTag >= :initialDateTime and "
			+ "me.timeTag <= :finalDateTime", RMPEntity.class);
		
		tq.setParameter("initialDateTime", initialDateTime);
		tq.setParameter("finalDateTime", finalDateTime);
		
		List<RMPEntity> bel = tq.getResultList();
		
		return rmpMapper.map(bel);
	}

	private void validate(ZonedDateTime initialDateTime, ZonedDateTime finalDateTime) {
		if(initialDateTime == null) {
			throw new RuntimeException("Parametro \"initialDateTime\" null");
		}
		
		if(finalDateTime == null) {
			throw new RuntimeException("Parametro \"finalDateTime\" null");
		}
		
		intervalValidator.validate(initialDateTime, finalDateTime, MAX_NUMBER_OF_DAYS);
	}

}
