package br.inpe.climaespacial.swd.indexes.v.mappers;

import br.inpe.climaespacial.swd.commons.factories.ListFactory;
import br.inpe.climaespacial.swd.indexes.v.dtos.VIndex;
import br.inpe.climaespacial.swd.indexes.v.entities.VIndexEntity;
import br.inpe.climaespacial.swd.indexes.v.factories.VIndexFactory;
import java.util.List;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;

@Dependent
public class DefaultVIndexMapper implements VIndexMapper {

    @Inject
    private ListFactory<VIndex> vIndexListFactory;

    @Inject
    private VIndexFactory vIndexFactory;

    @Override
    public List<VIndex> map(List<VIndexEntity> vIndexEntityList) {

        if (vIndexEntityList == null) {
            throw new RuntimeException("Parâmetro \"vIndexEntityList\" null.");
        }

        List<VIndex> vil = vIndexListFactory.create();

        vIndexEntityList.forEach(vie -> {
            VIndex vi = vIndexFactory.create();
            vi.setTimeTag(vie.getTimeTag());
            vi.setValue(vie.getValue());
            vil.add(vi);
        });

        return vil;
    }

}
