
package br.inpe.climaespacial.swd.acquisition.home;

import br.inpe.climaespacial.swd.commons.factories.Factory;

public interface IndexEntryFactory extends Factory<IndexEntry> {    
    
}
