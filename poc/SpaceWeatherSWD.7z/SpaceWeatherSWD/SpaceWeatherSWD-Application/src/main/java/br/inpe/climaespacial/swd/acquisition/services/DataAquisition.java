package br.inpe.climaespacial.swd.acquisition.services;

public interface DataAquisition {

	void acquire();

}
