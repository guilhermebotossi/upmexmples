package br.inpe.climaespacial.swd.values.ey.mappers;

import java.util.List;

import br.inpe.climaespacial.swd.values.ey.dtos.EY;
import br.inpe.climaespacial.swd.values.ey.entities.EYEntity;

public interface EYMapper {

	List<EY> map(List<EYEntity> eyEntityList);

}
