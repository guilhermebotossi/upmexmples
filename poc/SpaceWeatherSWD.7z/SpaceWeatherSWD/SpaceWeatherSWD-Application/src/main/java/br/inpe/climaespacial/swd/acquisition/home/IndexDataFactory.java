
package br.inpe.climaespacial.swd.acquisition.home;

import java.util.List;

public interface IndexDataFactory {
    
    IndexData create(List<IndexEntry> bIndexEntryList, List<IndexEntry> cIndexEntryList, List<IndexEntry> vIndexEntryList, List<IndexEntry> zIndexEntryList);
    
}
