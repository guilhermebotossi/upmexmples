package br.inpe.climaespacial.swd.indexes.b.services;

public interface BIndexService {

    void calculate();

}
