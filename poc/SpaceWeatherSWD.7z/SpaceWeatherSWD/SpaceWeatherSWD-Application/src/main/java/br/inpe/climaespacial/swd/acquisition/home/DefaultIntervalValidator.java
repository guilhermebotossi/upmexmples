package br.inpe.climaespacial.swd.acquisition.home;

import java.time.Duration;
import java.time.ZonedDateTime;
import javax.enterprise.context.Dependent;

@Dependent
public class DefaultIntervalValidator implements IntervalValidator {

    @Override
    public void validate(ZonedDateTime farthestFromNow, ZonedDateTime nearestFromNow, int periodSize) {

        if (farthestFromNow == null) {
            throw new RuntimeException("Parametro \"farthestFromNow\" null");
        }

        if (nearestFromNow == null) {
            throw new RuntimeException("Parametro \"nearestFromNow\" null");
        }

        if (farthestFromNow.isAfter(nearestFromNow)) {
            throw new RuntimeException("Parametro \"farthestFromNow\" cannot be after than \"nearestFromNow\"");
        }

        Duration d = Duration.between(farthestFromNow, nearestFromNow);

        if (d.toDays() > periodSize) {
            throw new RuntimeException("Period size exceeded");
        }

    }

}
