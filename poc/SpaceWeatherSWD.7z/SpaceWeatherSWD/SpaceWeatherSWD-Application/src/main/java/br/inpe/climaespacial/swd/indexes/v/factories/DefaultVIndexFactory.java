package br.inpe.climaespacial.swd.indexes.v.factories;

import br.inpe.climaespacial.swd.indexes.v.dtos.VIndex;
import br.inpe.climaespacial.swd.commons.factories.DefaultFactory;
import javax.enterprise.context.Dependent;

@Dependent
public class DefaultVIndexFactory extends DefaultFactory<VIndex> implements VIndexFactory {

    public DefaultVIndexFactory() {
        super(VIndex.class);
    }

}
