package br.inpe.climaespacial.swd.indexes.c.services;

import br.inpe.climaespacial.swd.average.dtos.HourlyAverage;
import br.inpe.climaespacial.swd.indexes.c.dtos.CIndex;
import br.inpe.climaespacial.swd.indexes.c.factories.CIndexFactory;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;

@Dependent
public class DefaultCIndexCalculator implements CIndexCalculator {

    private CIndexFactory cIndexFactory;
    
    //TODO CARLOS Verificar
    public DefaultCIndexCalculator() {
    }
    

    @Inject
    public DefaultCIndexCalculator(CIndexFactory cIndexFactory) {
        this.cIndexFactory = cIndexFactory;
    }

    @Override
    public CIndex calculate(HourlyAverage hourlyAverage) {
        if (hourlyAverage == null) {
            throw new RuntimeException("Parametro \"hourlyAverage\" null.");
        }

        if (hourlyAverage.getTimeTag() == null) {
            throw new RuntimeException("Propriedade \"hourlyAverage.timeTag\" null.");
        }
        CIndex ci = cIndexFactory.create();
        ci.setTimeTag(hourlyAverage.getTimeTag());
        Double cmp = null;

        if (hourlyAverage.getRmp() != null) {
            cmp = 10.6 - hourlyAverage.getRmp();
        }

        ci.setPreValue(cmp);

        if (cmp != null) {
            int[] icmin = {0, 1500, 2375, 3250, 4125, 5000, 10000};

            ci.setPostValue(0.0);
            for (int i = 0; i < icmin.length - 1; i++) {
                if (cmp >= icmin[i] && cmp < icmin[i + 1]) {
                    double indexC = (double) i + (cmp - icmin[i]) / (icmin[i + 1] - icmin[i]) * 1000D;;

                    ci.setPostValue(indexC);
                    break;
                }
            }
        }

        return ci;
    }

}
