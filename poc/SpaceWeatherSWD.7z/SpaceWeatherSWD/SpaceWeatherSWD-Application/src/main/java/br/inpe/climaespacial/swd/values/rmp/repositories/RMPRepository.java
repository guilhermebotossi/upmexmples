package br.inpe.climaespacial.swd.values.rmp.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import br.inpe.climaespacial.swd.values.rmp.dtos.RMP;

public interface RMPRepository {

	List<RMP> list(ZonedDateTime initialDateTime, ZonedDateTime finalDateTime);

}
