package br.inpe.climaespacial.swd.values.rmp.factories;

import java.time.ZonedDateTime;

import br.inpe.climaespacial.swd.values.rmp.dtos.RMP;

public interface RMPFactory {

	RMP create(ZonedDateTime timeTag, Double rmp);


}
