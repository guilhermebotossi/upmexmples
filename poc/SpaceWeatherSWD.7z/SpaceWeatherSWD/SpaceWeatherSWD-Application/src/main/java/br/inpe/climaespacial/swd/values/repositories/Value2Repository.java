package br.inpe.climaespacial.swd.values.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import br.inpe.climaespacial.swd.values.dtos.Value2;

public interface Value2Repository {

	List<Value2> list(ZonedDateTime idt, ZonedDateTime fdt);

}
