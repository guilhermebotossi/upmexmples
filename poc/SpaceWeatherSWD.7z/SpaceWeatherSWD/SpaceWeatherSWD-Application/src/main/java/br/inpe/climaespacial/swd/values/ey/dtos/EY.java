package br.inpe.climaespacial.swd.values.ey.dtos;

import java.time.ZonedDateTime;

import javax.enterprise.context.Dependent;

@Dependent
public class EY {
	
	private ZonedDateTime timeTag;
	private Double ey;

	public ZonedDateTime getTimeTag() {
		return timeTag;
	}

	public void setTimeTag(ZonedDateTime timeTag) {
		this.timeTag = timeTag;
	}

	public Double getEY() {
		return ey;
	}

	public void setEY(Double ey) {
		this.ey = ey;
	}

}
