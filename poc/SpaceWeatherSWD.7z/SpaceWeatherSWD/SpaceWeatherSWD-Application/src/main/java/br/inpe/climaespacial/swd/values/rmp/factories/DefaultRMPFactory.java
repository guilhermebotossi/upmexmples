package br.inpe.climaespacial.swd.values.rmp.factories;

import java.time.ZonedDateTime;

import javax.enterprise.context.Dependent;

import br.inpe.climaespacial.swd.values.rmp.dtos.RMP;

@Dependent
public class DefaultRMPFactory implements RMPFactory {

	@Override
	public RMP create(ZonedDateTime timeTag, Double value) {
		RMP rmp = new RMP();
		rmp.setTimeTag(timeTag);
		rmp.setRMP(value);
		return rmp;
	}

}
