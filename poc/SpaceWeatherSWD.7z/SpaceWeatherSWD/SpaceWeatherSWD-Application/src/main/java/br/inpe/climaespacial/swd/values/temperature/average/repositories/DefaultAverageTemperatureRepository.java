package br.inpe.climaespacial.swd.values.temperature.average.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.inpe.climaespacial.swd.acquisition.home.IntervalValidator;
import br.inpe.climaespacial.swd.values.temperature.average.dtos.AverageTemperature;
import br.inpe.climaespacial.swd.values.temperature.average.entities.AverageTemperatureEntity;
import br.inpe.climaespacial.swd.values.temperature.average.mappers.AverageTemperatureMapper;

@Dependent
public class DefaultAverageTemperatureRepository implements AverageTemperatureRepository {
	
	private static final int MAX_NUMBER_OF_DAYS = 3;
	
	@Inject
	private AverageTemperatureMapper AverageTemperatureMapper;
	
	@Inject
	private EntityManager entityManager;

	@Inject
	private IntervalValidator intervalValidator;

	@Override
	public List<AverageTemperature> list(ZonedDateTime initialDateTime, ZonedDateTime finalDateTime) {
		validate(initialDateTime, finalDateTime);
		
		TypedQuery<AverageTemperatureEntity> tq = entityManager.createQuery("SELECT NEW br.inpe.climaespacial.swd.values.AverageTemperature.entities.AverageTemperatureEntity(me.timeTag, me.AverageTemperature) "
			+ "FROM MagEntity me "
			+ "WHERE "
			+ "me.timeTag >= :initialDateTime and "
			+ "me.timeTag <= :finalDateTime", AverageTemperatureEntity.class);
		
		tq.setParameter("initialDateTime", initialDateTime);
		tq.setParameter("finalDateTime", finalDateTime);
		
		List<AverageTemperatureEntity> bel = tq.getResultList();
		
		return AverageTemperatureMapper.map(bel);
	}

	private void validate(ZonedDateTime initialDateTime, ZonedDateTime finalDateTime) {
		if(initialDateTime == null) {
			throw new RuntimeException("Parametro \"initialDateTime\" null");
		}
		
		if(finalDateTime == null) {
			throw new RuntimeException("Parametro \"finalDateTime\" null");
		}
		
		intervalValidator.validate(initialDateTime, finalDateTime, MAX_NUMBER_OF_DAYS);
	}

}
