package br.inpe.climaespacial.swd.indexes.v.repositories;

import br.inpe.climaespacial.swd.indexes.v.mappers.VIndexEntityMapper;
import br.inpe.climaespacial.swd.indexes.v.entities.VIndexEntity;
import br.inpe.climaespacial.swd.indexes.v.dtos.VIndex;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.persistence.EntityManager;

@Dependent
public class DefaultVIndexWriterRepository implements VIndexWriterRepository {

    @Inject
    private EntityManager entityManager;
    
    @Inject 
    private VIndexEntityMapper vIndexEntityMapper;
	
    @Override
    public void save(VIndex vIndex) {
    	if(vIndex == null) {
    		throw new RuntimeException("Parâmetro \"vIndex\" null.");
    	}
    	
    	VIndexEntity vie = vIndexEntityMapper.map(vIndex);
    	
        entityManager.persist(vie);

        entityManager.flush();
    	
    }
    
}
