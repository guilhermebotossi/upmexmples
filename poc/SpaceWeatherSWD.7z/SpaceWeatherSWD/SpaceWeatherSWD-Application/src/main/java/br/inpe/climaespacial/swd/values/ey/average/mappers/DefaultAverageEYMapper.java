package br.inpe.climaespacial.swd.values.ey.average.mappers;

import java.util.List;

import javax.enterprise.context.Dependent;
import javax.inject.Inject;

import br.inpe.climaespacial.swd.commons.factories.ListFactory;
import br.inpe.climaespacial.swd.values.ey.average.dtos.AverageEY;
import br.inpe.climaespacial.swd.values.ey.average.entities.AverageEYEntity;
import br.inpe.climaespacial.swd.values.ey.average.factories.AverageEYFactory;

@Dependent
public class DefaultAverageEYMapper implements AverageEYMapper {
	
	@Inject
	private ListFactory<AverageEY> averageEYListFactory;
	
	@Inject
	private AverageEYFactory averageEYFactory;

	@Override
	public List<AverageEY> map(List<AverageEYEntity> averageEYEntityList) {
		if(averageEYEntityList == null) {
			throw new RuntimeException("Parâmetro \"averageEYEntityList\" null.");
		}
		
		List<AverageEY> averageEYl = averageEYListFactory.create();
		
		averageEYEntityList.forEach(averageEYe ->  averageEYl.add(convertToAverageEY(averageEYe)));
		return averageEYl;
	}

	private AverageEY convertToAverageEY(AverageEYEntity averageEYe) {
		return averageEYFactory.create(averageEYe.getTimeTag(), averageEYe.getAverageEY());
	}

}
