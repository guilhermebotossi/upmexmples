package br.inpe.climaespacial.swd.values.mappers;

import java.util.List;

import javax.enterprise.context.Dependent;

import br.inpe.climaespacial.swd.values.bt.dtos.BT;
import br.inpe.climaespacial.swd.values.dtos.Value1Average;
import br.inpe.climaespacial.swd.values.dtos.Value2;
import br.inpe.climaespacial.swd.values.dtos.Value2Average;
import br.inpe.climaespacial.swd.values.dtos.Value3;
import br.inpe.climaespacial.swd.values.dtos.Value3Average;
import br.inpe.climaespacial.swd.values.dtos.Value4;
import br.inpe.climaespacial.swd.values.dtos.Value4Average;
import br.inpe.climaespacial.swd.values.dtos.Value5;
import br.inpe.climaespacial.swd.values.dtos.Value5Average;
import br.inpe.climaespacial.swd.values.dtos.Value6;
import br.inpe.climaespacial.swd.values.dtos.Value6Average;
import br.inpe.climaespacial.swd.values.dtos.Value7;
import br.inpe.climaespacial.swd.values.dtos.Value7Average;
import br.inpe.climaespacial.swd.values.dtos.Value8;
import br.inpe.climaespacial.swd.values.dtos.Value8Average;
import br.inpe.climaespacial.swd.values.dtos.Value9;
import br.inpe.climaespacial.swd.values.dtos.Value9Average;
import br.inpe.climaespacial.swd.values.dtos.ValueEntry;

@Dependent
public class DefaultValuesEntryMapper implements ValuesEntryMapper {

	@Override
	public List<ValueEntry> mapValue1(List<BT> v1l) {
		throw new RuntimeException("Not Yet Implemented");
	}

	@Override
	public List<ValueEntry> mapValue1Average(List<Value1Average> v1al) {
		throw new RuntimeException("Not Yet Implemented");
	}

	@Override
	public List<ValueEntry> mapValue2(List<Value2> v2l) {
		throw new RuntimeException("Not Yet Implemented");
	}

	@Override
	public List<ValueEntry> mapValue2Average(List<Value2Average> v2al) {
		throw new RuntimeException("Not Yet Implemented");
	}

	@Override
	public List<ValueEntry> mapValue3(List<Value3> v3l) {
		throw new RuntimeException("Not Yet Implemented");
	}

	@Override
	public List<ValueEntry> mapValue3Average(List<Value3Average> v3al) {
		throw new RuntimeException("Not Yet Implemented");
	}

	@Override
	public List<ValueEntry> mapValue4(List<Value4> v4l) {
		throw new RuntimeException("Not Yet Implemented");
	}

	@Override
	public List<ValueEntry> mapValue4Average(List<Value4Average> v4al) {
		throw new RuntimeException("Not Yet Implemented");
	}

	@Override
	public List<ValueEntry> mapValue5(List<Value5> v5l) {
		throw new RuntimeException("Not Yet Implemented");
	}

	@Override
	public List<ValueEntry> mapValue5Average(List<Value5Average> v5al) {
		throw new RuntimeException("Not Yet Implemented");
	}

	@Override
	public List<ValueEntry> mapValue6(List<Value6> v6l) {
		return null;
	}

	@Override
	public List<ValueEntry> mapValue6Average(List<Value6Average> v6al) {
		throw new RuntimeException("Not Yet Implemented");
	}

	@Override
	public List<ValueEntry> mapValue7(List<Value7> v7l) {
		throw new RuntimeException("Not Yet Implemented");
	}

	@Override
	public List<ValueEntry> mapValue7Average(List<Value7Average> v7al) {
		throw new RuntimeException("Not Yet Implemented");
	}

	@Override
	public List<ValueEntry> mapValue8(List<Value8> v8l) {
		throw new RuntimeException("Not Yet Implemented");
	}

	@Override
	public List<ValueEntry> mapValue8Average(List<Value8Average> v8al) {
		throw new RuntimeException("Not Yet Implemented");
	}

	@Override
	public List<ValueEntry> mapValue9(List<Value9> v9l) {
		throw new RuntimeException("Not Yet Implemented");
	}

	@Override
	public List<ValueEntry> mapValue9Average(List<Value9Average> v9al) {
		throw new RuntimeException("Not Yet Implemented");
	}

}
