
package br.inpe.climaespacial.swd.acquisition.home;

import br.inpe.climaespacial.swd.indexes.RangeDate;

import java.time.ZonedDateTime;

public interface IndexesService {
    
    IndexData getIndexData(ZonedDateTime farthestFromNow, ZonedDateTime nearestFromNow);
    
    RangeDate getRangeDate();
    
}
