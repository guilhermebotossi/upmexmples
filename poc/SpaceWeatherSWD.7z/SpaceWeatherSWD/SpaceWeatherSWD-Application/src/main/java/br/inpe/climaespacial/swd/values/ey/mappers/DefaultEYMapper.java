package br.inpe.climaespacial.swd.values.ey.mappers;

import java.util.List;

import javax.enterprise.context.Dependent;
import javax.inject.Inject;

import br.inpe.climaespacial.swd.commons.factories.ListFactory;
import br.inpe.climaespacial.swd.values.ey.dtos.EY;
import br.inpe.climaespacial.swd.values.ey.entities.EYEntity;
import br.inpe.climaespacial.swd.values.ey.factories.EYFactory;

@Dependent
public class DefaultEYMapper implements EYMapper {
	
	@Inject
	private ListFactory<EY> eyListFactory;
	
	@Inject
	private EYFactory eyFactory;

	@Override
	public List<EY> map(List<EYEntity> eyEntityList) {
		if(eyEntityList == null) {
			throw new RuntimeException("Parâmetro \"eyEntityList\" null.");
		}
		
		List<EY> eyl = eyListFactory.create();
		
		eyEntityList.forEach(eye ->  eyl.add(convertToEY(eye)));
		return eyl;
	}

	private EY convertToEY(EYEntity eye) {
		return eyFactory.create(eye.getTimeTag(), eye.getEY());
	}

}
