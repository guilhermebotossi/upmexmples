package br.inpe.climaespacial.swd.indexes.v.services;

import br.inpe.climaespacial.swd.indexes.v.dtos.VIndex;
import br.inpe.climaespacial.swd.average.dtos.HourlyAverage;
import java.util.List;

public interface VIndexCalculator {
    
    VIndex calculate(List<HourlyAverage> hourlyAverage);
    
}
