package br.inpe.climaespacial.swd.indexes.z.factories;

import javax.enterprise.context.Dependent;

import br.inpe.climaespacial.swd.commons.factories.DefaultFactory;
import br.inpe.climaespacial.swd.indexes.z.dtos.ZIndex;

@Dependent
public class DefaultZIndexFactory extends DefaultFactory<ZIndex> implements ZIndexFactory {

	public DefaultZIndexFactory() {
		super(ZIndex.class);
	}
	
}