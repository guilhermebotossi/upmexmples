package br.inpe.climaespacial.swd.values.ey.average.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.inpe.climaespacial.swd.acquisition.home.IntervalValidator;
import br.inpe.climaespacial.swd.values.ey.average.dtos.AverageEY;
import br.inpe.climaespacial.swd.values.ey.average.entities.AverageEYEntity;
import br.inpe.climaespacial.swd.values.ey.average.mappers.AverageEYMapper;

@Dependent
public class DefaultAverageEYRepository implements AverageEYRepository {
	
	private static final int MAX_NUMBER_OF_DAYS = 3;
	
	@Inject
	private AverageEYMapper averageEYMapper;
	
	@Inject
	private EntityManager entityManager;

	@Inject
	private IntervalValidator intervalValidator;

	@Override
	public List<AverageEY> list(ZonedDateTime initialDateTime, ZonedDateTime finalDateTime) {
		validate(initialDateTime, finalDateTime);
		
		TypedQuery<AverageEYEntity> tq = entityManager.createQuery("SELECT NEW br.inpe.climaespacial.swd.values.averageEY.entities.AverageEYEntity(me.timeTag, me.averageEY) "
			+ "FROM MagEntity me "
			+ "WHERE "
			+ "me.timeTag >= :initialDateTime and "
			+ "me.timeTag <= :finalDateTime", AverageEYEntity.class);
		
		tq.setParameter("initialDateTime", initialDateTime);
		tq.setParameter("finalDateTime", finalDateTime);
		
		List<AverageEYEntity> bel = tq.getResultList();
		
		return averageEYMapper.map(bel);
	}

	private void validate(ZonedDateTime initialDateTime, ZonedDateTime finalDateTime) {
		if(initialDateTime == null) {
			throw new RuntimeException("Parametro \"initialDateTime\" null");
		}
		
		if(finalDateTime == null) {
			throw new RuntimeException("Parametro \"finalDateTime\" null");
		}
		
		intervalValidator.validate(initialDateTime, finalDateTime, MAX_NUMBER_OF_DAYS);
	}

}
