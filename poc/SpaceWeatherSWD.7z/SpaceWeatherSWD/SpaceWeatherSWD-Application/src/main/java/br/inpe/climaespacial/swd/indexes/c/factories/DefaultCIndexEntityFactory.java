package br.inpe.climaespacial.swd.indexes.c.factories;

import br.inpe.climaespacial.swd.commons.factories.DefaultEntityFactory;
import br.inpe.climaespacial.swd.indexes.c.entities.CIndexEntity;
import javax.enterprise.context.Dependent;

@Dependent
public class DefaultCIndexEntityFactory extends DefaultEntityFactory<CIndexEntity> implements CIndexEntityFactory {

	public DefaultCIndexEntityFactory() {
		super(CIndexEntity.class);
	}
	
}