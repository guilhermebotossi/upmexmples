package br.inpe.climaespacial.swd.indexes.z.services;

import br.inpe.climaespacial.swd.average.dtos.HourlyAverage;
import br.inpe.climaespacial.swd.indexes.z.dtos.ZIndex;
import static java.lang.Math.abs;
import static java.lang.Math.floor;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;
import javax.enterprise.context.Dependent;

@Dependent
public class DefaultZIndexCalculator implements ZIndexCalculator {

    @Override
    public ZIndex calculate(List<HourlyAverage> hourlyAverageList) {
        if (hourlyAverageList == null || hourlyAverageList.isEmpty()) {
            throw new RuntimeException("Parametro \"hourlyAverageList\" null/empty.");
        }

        Optional<HourlyAverage> hao = hourlyAverageList.stream().filter(ha -> ha.getTimeTag() == null).findAny();

        if (hao.isPresent()) {
            throw new RuntimeException("Propriedade \"hourlyAverage.timeTag\" null.");
        }

        Double bz = getBzAverage(hourlyAverageList);
        ZIndex zi = new ZIndex();
        zi.setTimeTag(getLastTimeTag(hourlyAverageList));

        zi.setPreValue(bz);

        if (bz != null) {
            Double absBz = Math.abs(bz);
            int[] izmin = {0, -4, -7, -10, -15, -20, -40};
            for (int i = 0; i < izmin.length - 1; i++) {
                if (bz >= 0.0) {
                    zi.setPostValue(0.0);
                    break;
                } else if (absBz >= abs(izmin[i]) && absBz < abs(izmin[i + 1])) {
                    double indexZ = i + (absBz - abs(izmin[i])) / (abs(izmin[i + 1]) - abs(izmin[i]));
                    indexZ = floor(indexZ * 100) / 100;
                    if (indexZ < 0.0) {
                        indexZ = 0.0;
                    } else if (indexZ > 6) {
                        indexZ = 6.0;
                    }
                    zi.setPostValue(indexZ);
                    break;
                }
            }
        }

        return zi;
    }

    private ZonedDateTime getLastTimeTag(List<HourlyAverage> hourlyAverageList) {
        int size = hourlyAverageList.size();

        return hourlyAverageList.get(size - 1).getTimeTag();
    }

    private Double getBzAverage(List<HourlyAverage> hourlyAverageList) {
        OptionalDouble od = hourlyAverageList.stream().filter(ha -> ha.getBzGsm() != null).mapToDouble(ha -> ha.getBzGsm()).average();
        return od.isPresent() ? od.getAsDouble() : null;
    }
}
