package br.inpe.climaespacial.swd.indexes.c.repositories;

import br.inpe.climaespacial.swd.indexes.c.mappers.CIndexEntityMapper;
import br.inpe.climaespacial.swd.indexes.c.entities.CIndexEntity;
import br.inpe.climaespacial.swd.indexes.c.dtos.CIndex;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.persistence.EntityManager;

@Dependent
public class DefaultCIndexWriterRepository implements CIndexWriterRepository {

    @Inject
    private EntityManager entityManager;
    
    @Inject 
    private CIndexEntityMapper cIndexEntityMapper;
	
    @Override
    public void save(CIndex cIndex) {
    	if(cIndex == null) {
    		throw new RuntimeException("Parâmetro \"cIndex\" null.");
    	}
    	
    	CIndexEntity cie = cIndexEntityMapper.map(cIndex);
    	
        entityManager.persist(cie);

        entityManager.flush();
    	
    }
    
}
