package br.inpe.climaespacial.swd.values.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import br.inpe.climaespacial.swd.values.dtos.Value7;

public interface Value7Repository {

	List<Value7> list(ZonedDateTime idt, ZonedDateTime fdt);

}
