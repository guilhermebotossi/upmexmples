package br.inpe.climaespacial.swd.values.ey.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import br.inpe.climaespacial.swd.values.ey.dtos.EY;

public interface EYRepository {

	List<EY> list(ZonedDateTime initialDateTime, ZonedDateTime finalDateTime);

}
