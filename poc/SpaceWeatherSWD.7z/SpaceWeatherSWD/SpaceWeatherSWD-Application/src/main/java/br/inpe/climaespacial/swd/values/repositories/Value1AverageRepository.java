package br.inpe.climaespacial.swd.values.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import br.inpe.climaespacial.swd.values.dtos.Value1Average;

public interface Value1AverageRepository {

	List<Value1Average> list(ZonedDateTime idt, ZonedDateTime fdt);

}
