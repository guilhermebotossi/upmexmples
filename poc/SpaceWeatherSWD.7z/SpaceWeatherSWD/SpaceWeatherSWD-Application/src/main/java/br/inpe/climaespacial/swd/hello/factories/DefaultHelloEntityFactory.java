package br.inpe.climaespacial.swd.hello.factories;

import javax.enterprise.context.Dependent;

import br.inpe.climaespacial.swd.commons.factories.DefaultEntityFactory;
import br.inpe.climaespacial.swd.hello.entities.HelloEntity;

@Dependent
public class DefaultHelloEntityFactory extends DefaultEntityFactory<HelloEntity> implements HelloEntityFactory {

	public DefaultHelloEntityFactory() {
		super(HelloEntity.class);
	}

}
