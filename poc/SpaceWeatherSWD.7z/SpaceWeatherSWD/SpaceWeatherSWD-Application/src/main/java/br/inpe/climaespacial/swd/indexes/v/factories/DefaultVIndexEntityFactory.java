package br.inpe.climaespacial.swd.indexes.v.factories;

import br.inpe.climaespacial.swd.indexes.v.entities.VIndexEntity;
import javax.enterprise.context.Dependent;

import br.inpe.climaespacial.swd.commons.factories.DefaultEntityFactory;

@Dependent
public class DefaultVIndexEntityFactory extends DefaultEntityFactory<VIndexEntity> implements VIndexEntityFactory {

	public DefaultVIndexEntityFactory() {
		super(VIndexEntity.class);
	}
	
}