package br.inpe.climaespacial.swd.values.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import br.inpe.climaespacial.swd.values.dtos.Value6Average;

public interface Value6AverageRepository {

	List<Value6Average> list(ZonedDateTime idt, ZonedDateTime fdt);

}
