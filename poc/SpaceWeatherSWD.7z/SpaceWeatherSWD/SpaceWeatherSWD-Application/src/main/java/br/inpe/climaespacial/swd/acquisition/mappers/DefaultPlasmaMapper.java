package br.inpe.climaespacial.swd.acquisition.mappers;

import br.inpe.climaespacial.swd.acquisition.dtos.Plasma;
import br.inpe.climaespacial.swd.acquisition.factories.PlasmaFactory;
import br.inpe.climaespacial.swd.commons.mappers.DateTimeMapper;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

@Dependent
public class DefaultPlasmaMapper implements PlasmaMapper {
	
	@Inject
	private DateTimeMapper dateTimeMapper;
        
        @Inject
        private PlasmaFactory plasmaFactory;
	
	public List<Plasma> map(String content) {
		check(content);
		return mapAll(content);
	}
	
	private void check(String content) {
		if (content == null || content.isEmpty()) {
			throw new RuntimeException("Parâmetro \"content\" null/empty.");
		}
	}

	private List<Plasma> mapAll(String content) {

		// TODO - Change to factory call.
		List<Plasma> pl = new ArrayList<>();

		JSONArray jarray = parseStringToJson(content);

		for (int i = 1; i < jarray.size(); i++) {
			pl.add(createMapper((JSONArray) jarray.get(i)));
		}

		return pl;
	}

	private JSONArray parseStringToJson(String content) {
		try {
			// TODO - Change to factory call.
			JSONParser parser = new JSONParser();
			return (JSONArray) parser.parse(content);
		} catch (ParseException e) {
			throw new RuntimeException("Parametro \"content\" formato invalido");
		}
	}

	private Plasma createMapper(JSONArray json) {
		Plasma p = plasmaFactory.create();

		ZonedDateTime zdt = dateTimeMapper.map(json.get(0).toString());

		p.setTimeTag(zdt);
		p.setDensity(getWrappedDoubleValue(json.get(1)));
		p.setSpeed(getWrappedDoubleValue(json.get(2)));
		p.setTemperature(getWrappedDoubleValue(json.get(3)));
		return p;
	}
	
	private double getDoubleValue(Object obj) {
		return Double.parseDouble(((String) obj));
	}
	
	private Double getWrappedDoubleValue(Object obj) {
		return obj != null ? getDoubleValue(obj) : null;
	}
}
