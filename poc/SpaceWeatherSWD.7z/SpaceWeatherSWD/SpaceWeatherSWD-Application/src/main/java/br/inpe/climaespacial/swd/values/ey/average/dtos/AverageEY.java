package br.inpe.climaespacial.swd.values.ey.average.dtos;

import java.time.ZonedDateTime;

import javax.enterprise.context.Dependent;

@Dependent
public class AverageEY {
	
	private ZonedDateTime timeTag;
	private Double averageEY;

	public ZonedDateTime getTimeTag() {
		return timeTag;
	}

	public void setTimeTag(ZonedDateTime timeTag) {
		this.timeTag = timeTag;
	}

	public Double getAverageEY() {
		return averageEY;
	}

	public void setAverageEY(Double averageEY) {
		this.averageEY = averageEY;
	}

}
