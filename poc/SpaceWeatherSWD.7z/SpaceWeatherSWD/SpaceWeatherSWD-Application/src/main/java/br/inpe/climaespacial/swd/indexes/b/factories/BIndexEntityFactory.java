package br.inpe.climaespacial.swd.indexes.b.factories;

import br.inpe.climaespacial.swd.commons.factories.EntityFactory;
import br.inpe.climaespacial.swd.indexes.b.entities.BIndexEntity;

public interface BIndexEntityFactory extends EntityFactory<BIndexEntity> {

}
