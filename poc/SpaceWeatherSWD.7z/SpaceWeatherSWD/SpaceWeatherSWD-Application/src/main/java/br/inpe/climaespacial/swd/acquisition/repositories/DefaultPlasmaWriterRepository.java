package br.inpe.climaespacial.swd.acquisition.repositories;

import java.util.List;

import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.inpe.climaespacial.swd.acquisition.dtos.Plasma;
import br.inpe.climaespacial.swd.acquisition.entities.PlasmaEntity;
import br.inpe.climaespacial.swd.acquisition.mappers.PlasmaEntityMapper;

@Dependent
public class DefaultPlasmaWriterRepository implements PlasmaWriterRepository {

	@Inject
	private PlasmaEntityMapper plasmaEntityMapper;

	@Inject
	private EntityManager entityManager;

	private Boolean hasDataToPersist;

	@Override
	public void save(List<Plasma> plasmaList) {

		if (plasmaList == null) {
			throw new RuntimeException("Parâmetro \"plasmaList\" null.");
		}

		hasDataToPersist = false;

		List<PlasmaEntity> pel = plasmaEntityMapper.map(plasmaList);

		pel.forEach(pe -> {
			persist(pe);
		});

		if (hasDataToPersist) {
			entityManager.flush();
			entityManager.clear();
		}
	}

	private void persist(PlasmaEntity pe) {
		TypedQuery<Boolean> tq = entityManager.createQuery(
				"SELECT CASE WHEN(COUNT(*) > 0) THEN true ELSE false END FROM PlasmaEntity pe WHERE pe.timeTag = :timeTag",
				Boolean.class);
		tq.setParameter("timeTag", pe.getTimeTag());

		if (!tq.getSingleResult()) {
			entityManager.persist(pe);
			hasDataToPersist = true;
		}
	}
}
