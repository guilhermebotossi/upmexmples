package br.inpe.climaespacial.swd.indexes.c.factories;

import br.inpe.climaespacial.swd.indexes.c.dtos.CIndex;
import br.inpe.climaespacial.swd.commons.factories.Factory;

public interface CIndexFactory  extends Factory<CIndex>{

}
