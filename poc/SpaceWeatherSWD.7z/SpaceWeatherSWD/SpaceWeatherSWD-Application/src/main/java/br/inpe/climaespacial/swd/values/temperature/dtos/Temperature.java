package br.inpe.climaespacial.swd.values.temperature.dtos;

import java.time.ZonedDateTime;

import javax.enterprise.context.Dependent;

@Dependent
public class Temperature {
	
	private ZonedDateTime timeTag;
	private Double temperature;

	public ZonedDateTime getTimeTag() {
		return timeTag;
	}

	public void setTimeTag(ZonedDateTime timeTag) {
		this.timeTag = timeTag;
	}

	public Double getTemperature() {
		return temperature;
	}

	public void setTemperature(Double temperature) {
		this.temperature = temperature;
	}

}
