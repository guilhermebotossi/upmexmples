package br.inpe.climaespacial.swd.acquisition.repositories;

import java.util.List;

import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.inpe.climaespacial.swd.acquisition.dtos.Mag;
import br.inpe.climaespacial.swd.acquisition.entities.MagEntity;
import br.inpe.climaespacial.swd.acquisition.mappers.MagEntityMapper;

@Dependent
public class DefaultMagWriterRepository implements MagWriterRepository {

	@Inject
	private MagEntityMapper magEntityMapper;

	@Inject
	private EntityManager entityManager;

	private Boolean hasDataToPersist;

	@Override
	public void save(List<Mag> magList) {

		if (magList == null) {
			throw new RuntimeException("Parâmetro \"magList\" null.");
		}
		
		hasDataToPersist = false;

		List<MagEntity> mel = magEntityMapper.map(magList);

		mel.forEach(me -> {
			persist(me);
		});

		if (hasDataToPersist) {
			entityManager.flush();
			entityManager.clear();
		}
	}

	private void persist(MagEntity me) {
		TypedQuery<Boolean> tq = entityManager.createQuery(
				"SELECT CASE WHEN(COUNT(*) > 0) THEN true ELSE false END FROM MagEntity me WHERE me.timeTag = :timeTag",
				Boolean.class);
		tq.setParameter("timeTag", me.getTimeTag());

		if (!tq.getSingleResult()) {
			entityManager.persist(me);
			hasDataToPersist = true;
		}
	}
}
