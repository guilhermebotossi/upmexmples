package br.inpe.climaespacial.swd.indexes.z.repositories;

import br.inpe.climaespacial.swd.indexes.z.entities.ZIndexEntity;
import br.inpe.climaespacial.swd.indexes.z.mappers.ZIndexEntityMapper;
import br.inpe.climaespacial.swd.indexes.z.dtos.ZIndex;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.persistence.EntityManager;

@Dependent
public class DefaultZIndexWriterRepository implements ZIndexWriterRepository {

    @Inject
    private EntityManager entityManager;
    
    @Inject 
    private ZIndexEntityMapper zIndexEntityMapper;
	
    @Override
    public void save(ZIndex zIndex) {
    	if(zIndex == null) {
    		throw new RuntimeException("Parâmetro \"zIndex\" null.");
    	}
    	
    	ZIndexEntity zie = zIndexEntityMapper.map(zIndex);
    	
        entityManager.persist(zie);

        entityManager.flush();
    	
    }
    
}
