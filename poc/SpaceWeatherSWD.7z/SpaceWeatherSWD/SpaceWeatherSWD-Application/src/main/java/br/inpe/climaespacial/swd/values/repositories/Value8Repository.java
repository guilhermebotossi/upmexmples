package br.inpe.climaespacial.swd.values.repositories;

import java.time.ZonedDateTime;
import java.util.List;

import br.inpe.climaespacial.swd.values.dtos.Value8;

public interface Value8Repository {

	List<Value8> list(ZonedDateTime idt, ZonedDateTime fdt);

}
