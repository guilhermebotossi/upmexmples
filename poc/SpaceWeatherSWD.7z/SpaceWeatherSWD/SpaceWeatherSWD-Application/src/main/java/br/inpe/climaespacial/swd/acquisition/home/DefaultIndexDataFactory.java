
package br.inpe.climaespacial.swd.acquisition.home;

import br.inpe.climaespacial.swd.commons.factories.Factory;
import java.util.List;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;

@Dependent
public class DefaultIndexDataFactory implements IndexDataFactory {
    
    @Inject
    private Factory<IndexData> indexDataFactory;
        
    @Override
    public IndexData create(List<IndexEntry> bIndexEntryList, List<IndexEntry> cIndexEntryList, List<IndexEntry> vIndexEntryList, List<IndexEntry> zIndexEntryList) {
        IndexData id = indexDataFactory.create();
        id.setbEntrys(bIndexEntryList);
        id.setcEntrys(cIndexEntryList);
        id.setvEntrys(vIndexEntryList);
        id.setzEntrys(zIndexEntryList);
        return id;        
    }
    
}
