package br.inpe.climaespacial.swd.indexes;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import javax.enterprise.context.Dependent;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

@Dependent
public class DefaultIndexesReaderRepository implements IndexesReaderRepository {
    
    @Inject
    private EntityManager entityManager;
    
    @Override
    public ZonedDateTime lastIndexesDate() {
        String sql
                = "SELECT NEW list(MAX(b.timeTag), MAX(c.timeTag), MAX(v.timeTag), MAX(z.timeTag)) FROM BIndexEntity b, CIndexEntity c, VIndexEntity v, ZIndexEntity z";
        
        TypedQuery<List> tq = entityManager.createQuery(sql, List.class);
        @SuppressWarnings("unchecked")
        List<ZonedDateTime> zdtl = tq.getSingleResult();
        
        Optional<ZonedDateTime> zdt = zdtl.stream().filter(z -> z != null).max((zdt1, zdt2) -> zdt1.compareTo(zdt2));
        
        return !zdt.isPresent() ? null : zdt.get();
    }
    
}
