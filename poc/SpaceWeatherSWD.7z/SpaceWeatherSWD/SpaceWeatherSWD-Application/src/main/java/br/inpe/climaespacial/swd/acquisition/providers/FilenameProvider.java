package br.inpe.climaespacial.swd.acquisition.providers;

public interface FilenameProvider {

	String getFilename();

}
