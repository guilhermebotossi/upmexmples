package br.inpe.climaespacial.swd.acquisition.factories;

import br.inpe.climaespacial.swd.acquisition.entities.MagEntity;
import br.inpe.climaespacial.swd.commons.factories.EntityFactory;

public interface MagEntityFactory extends EntityFactory<MagEntity> {

}
