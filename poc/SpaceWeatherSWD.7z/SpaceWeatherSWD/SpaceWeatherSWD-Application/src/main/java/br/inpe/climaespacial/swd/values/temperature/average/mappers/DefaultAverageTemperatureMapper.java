package br.inpe.climaespacial.swd.values.temperature.average.mappers;

import java.util.List;

import javax.enterprise.context.Dependent;
import javax.inject.Inject;

import br.inpe.climaespacial.swd.commons.factories.ListFactory;
import br.inpe.climaespacial.swd.values.temperature.average.dtos.AverageTemperature;
import br.inpe.climaespacial.swd.values.temperature.average.entities.AverageTemperatureEntity;
import br.inpe.climaespacial.swd.values.temperature.average.factories.AverageTemperatureFactory;

@Dependent
public class DefaultAverageTemperatureMapper implements AverageTemperatureMapper {
	
	@Inject
	private ListFactory<AverageTemperature> AverageTemperatureListFactory;
	
	@Inject
	private AverageTemperatureFactory AverageTemperatureFactory;

	@Override
	public List<AverageTemperature> map(List<AverageTemperatureEntity> AverageTemperatureEntityList) {
		if(AverageTemperatureEntityList == null) {
			throw new RuntimeException("Parâmetro \"AverageTemperatureEntityList\" null.");
		}
		
		List<AverageTemperature> AverageTemperaturel = AverageTemperatureListFactory.create();
		
		AverageTemperatureEntityList.forEach(AverageTemperaturee ->  AverageTemperaturel.add(convertToAverageTemperature(AverageTemperaturee)));
		return AverageTemperaturel;
	}

	private AverageTemperature convertToAverageTemperature(AverageTemperatureEntity AverageTemperaturee) {
		return AverageTemperatureFactory.create(AverageTemperaturee.getTimeTag(), AverageTemperaturee.getAverageTemperature());
	}

}
