package br.inpe.climaespacial.swd.indexes.v.repositories;

import br.inpe.climaespacial.swd.indexes.v.mappers.VIndexMapper;
import br.inpe.climaespacial.swd.indexes.v.entities.VIndexEntity;
import br.inpe.climaespacial.swd.indexes.v.dtos.VIndex;
import java.time.ZonedDateTime;
import java.util.List;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

@Dependent
public class DefaultVIndexReaderRepository implements VIndexReaderRepository {

    private static final String QUERY = "SELECT MAX(vie.timeTag) FROM VIndexEntity vie";
    
    private static final String QUERY_LIST = "SELECT vie FROM VIndexEntity vie WHERE vie.timeTag BETWEEN :farthestFromNow AND :nearestFromNow ORDER BY vie.timeTag";

    @Inject
    private EntityManager entityManager;
    
    @Inject
    private VIndexMapper vIndexMapper;

    @Override
    public ZonedDateTime getNextHourToBeCalculated() {
        TypedQuery<ZonedDateTime> tq = entityManager.createQuery(QUERY, ZonedDateTime.class);
        ZonedDateTime zdt = tq.getResultList().get(0);
        return zdt == null ? null : zdt.plusHours(1);
    }
    
    @Override
    public List<VIndex> listByPeriod(ZonedDateTime farthestFromNow, ZonedDateTime nearestFromNow) {
        TypedQuery<VIndexEntity> tq = entityManager.createQuery(QUERY_LIST, VIndexEntity.class);
        tq.setParameter("farthestFromNow", farthestFromNow);
        tq.setParameter("nearestFromNow", nearestFromNow);
        List<VIndexEntity> viel = tq.getResultList();        
        return vIndexMapper.map(viel);
    }

}
