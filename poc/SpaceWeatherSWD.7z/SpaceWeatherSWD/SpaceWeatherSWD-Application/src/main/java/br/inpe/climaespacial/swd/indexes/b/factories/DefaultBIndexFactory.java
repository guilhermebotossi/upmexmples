package br.inpe.climaespacial.swd.indexes.b.factories;

import br.inpe.climaespacial.swd.commons.factories.DefaultFactory;
import br.inpe.climaespacial.swd.indexes.b.dtos.BIndex;
import javax.enterprise.context.Dependent;

@Dependent
public class DefaultBIndexFactory extends DefaultFactory<BIndex> implements BIndexFactory {

	public DefaultBIndexFactory() {
		super(BIndex.class);
	}
	
}